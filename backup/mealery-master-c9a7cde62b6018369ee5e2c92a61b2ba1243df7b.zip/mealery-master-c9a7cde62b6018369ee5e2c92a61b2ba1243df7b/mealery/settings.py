
class LoggerConfig(object):
    config = dict(
        version = 1,
        formatters = {
            'standard': {
                'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
            },
        },
        handlers = {
            'default': {
                'level': 'INFO',
                'formatter': 'standard',
                'class': 'logging.StreamHandler',
            },
        },
        loggers = {
            '': {
                'handlers': ['default'],
                'level': 'INFO',
                'propagate': True
            },
        }
    )


class MysqlConfig(object):
    # mysql setting
    HOST = '127.0.0.1'
    PORT = 63
    USER = 'root'
    PASS = ''
    DATABASE = 'aem_stats'

    # mysql maintainance setting
    WORK_DIR = '/data2/mysql_backup'
    INCREASE_DAYS = 1
    BACKUP_DAYS = 30
    CLEANUP_DAYS = 60

    TABLES = [
        'xndctinfo_summary',
        'xsceneinfo_summary',
        'pingback_summary',
    ]


class MongoConfig(object):
    # mongo database setting
    HOST = '127.0.0.1'
    PORT = 27017
    USER = 'root'
    PASS = ''

    # mongo maintainance setting
    WORK_DIR = '/data2/mongo_backup'
    INCREASE_DAYS = 1
    BACKUP_DAYS = 15
    CLEANUP_DAYS = 30

    DATABASES = [
        'aem_ndctinfo',
        'aem_sceneinfo'
        'aem_pingback',
    ]
