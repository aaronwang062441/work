
import numpy
import pandas

from mealery import app, logger

class UniOutlierAlgorithm(object):
    """Outlier detection algorithms for unitary variable

    This is a collections of algorithms for outlier detection,
    all algorithms are based on unitary variable, an article
    can be referred:
        > http://www.tuicool.com/articles/qiA3Mr
    """
    @staticmethod
    def standard(dataframe, threshold=.95):
        """Outlier detection based on Standard Deviation

        @param dataframe: pandas dataframe
        @param threshold: threshold to filter outliers
        @return: dataframe with abnormal data
        """
        pass

    @staticmethod
    def zscore(dataframe, threshold=3.5):
        """Outlier detection based on Zscore

        @param dataframe: pandas dataframe
        @param threshold: threshold to filter outliers
        @return: dataframe with outliers
        """
        pass

    @staticmethod
    def zscore_mad(dataframe, threshold=3.5):
        """Outlier detection based on MAD Zscore

        @param dataframe: pandas dataframe
        @param threshold: threshold to filter outliers
        @return: dataframe with outliers
        """
        pass

    @staticmethod
    def kmean(dataframe, threshold=.9):
        """Outlier detection based on KMEAN clustering

        @param dataframe: pandas dataframe
        @param threshold: threshold to filter outliers
        @return: dataframe with outliers
        """
        pass

class MulOutlierAlgorithm(object):
    pass

class OutlierDetecting(object):
    def __init__(self):
        pass

    def detect(self, dataframe):
        pass


@app.task
def alert(*args, **kwargs):
    logger.info('args=%s' % str(args))
    import time
    time.sleep(2)
    return args[0]


if __name__ == "__main__":
    pass
