#!/usr/bin/env python
# encoding: utf-8

import sys
from optparse import OptionParser
from maintain import MongoMaintain


if __name__ == "__main__":
    parser = OptionParser('%prog [options]')
    parser.remove_option('-h')
    parser.add_option('--help', action='help', help='show this help message')
    parser.add_option('-h', '--host', action='store', dest='host', default='localhost', help='mongo host to connect to')
    parser.add_option('-p', '--port', action='store', dest='port', type='int', default=27017, help='server port')
    parser.add_option('-o', '--outdir', action='store', dest='outdir', default='.', help='directory to work on')
    parser.add_option('-d', '--database', action='store', dest='dbname', help='datebase to use')

    parser.add_option('-b', action='store_true', dest='backup', help='perform to back up')
    parser.add_option('--backup-days', action='store', type='int', dest='backup_days', default=10, help='days ago to back up')

    parser.add_option('-c', action='store_true', dest='cleanup', help='perform to clean up')
    parser.add_option('--cleanup-days', action='store', type='int', dest='cleanup_days', default=30, help='days ago to clean up')

    parser.add_option('-r', action='store_true', dest='increase', help='perform to increase up')
    parser.add_option('--increase-days', action='store', type='int', dest='increase_days', default=1, help='days ago to increase')
    parser.add_option('--create-index', action='store', dest='create_index', default=None, help='create indexes when increasing')
    parser.add_option('--create-prikey', action='store', dest='create_prikey', default=None, help='crete primary key when increasing')

    opts, args = parser.parse_args()

    if not opts.dbname:
        parser.error('please specify database and collection')
        sys.exit(-2)

    m = MongoMaintain(opts.host, opts.port)
    m.workdir = opts.outdir

    if opts.cleanup:
        m.cleanup(opts.dbname, opts.cleanup_days)
    if opts.backup:
        m.backup(opts.dbname, opts.backup_days)
    if opts.increase:
        m.increase(opts.dbname, opts.create_prikey, opts.create_index, opts.increase_days)
