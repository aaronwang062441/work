from __future__ import absolute_import
from mealery.celery import app, logger
from mealery.mongoadmin.maintain import MongoMaintain

@app.task(ignore_result=True)
def maintain(host, port, username, password, dbname, **kwargs):
    """Interface of module and celery task entry"""
    logger.info('%s' % locals())

    instance = MongoMaintain(host, port)
    instance.workdir = kwargs.get('workdir', '.')
    instance.cleanup(dbname, kwargs.get('cleanup_days', 30))
    instance.backup(dbname, kwargs.get('backup_days', 10))
    instance.increase(dbname,
        primary_key=kwargs.get('primary_key', None),
        indexes=kwargs.get('index_keys', None),
        fwd=kwargs.get('increase_days', 1),
    )

    return True
