"""Mongo maintainance

Provides MongoDB maintainance like increasing, backup, cleanup
"""

import os
import re

from datetime import date, timedelta
from pymongo import MongoClient

from db_utils import mongodump


class MongoMaintain(object):
    """Mongo maintainance

    To be supposed that collections on specified database in MongoDB
    are named with the same prefix with database name plus the suffix
    with date format '%Y%m%d', such as database name aem_ndctinfo with
    collections naming 'aem_ndctinfo_20170101'.
    This class provides operations to be performed on MongoDB database,
    including increasing some new subsequent collections for ready, backing
    up some outdated collections to data files, and cleaning up some
    outdated data files

    Usage:
        >>> instance = MongoMaintain('localhost', 27017, 'root', '')
        >>> instance.workdir = '.'
        >>> # create a new collection for tomorrow
        >>> instance.increase('aem_ndctinfo', 1)
        >>> # backup all outdated collections prior to 10 days
        >>> instance.backup('aem_ndctinfo', 10)
    """
    def __init__(self, host, port):
        """Initialize an maintannace instance

        @param host: remote host of MongoDB
        @param port: remote port of MongoDB
        """
        self._workdir = None

        self.host = host
        self.port = port

    @property
    def workdir(self):
        """Getter of workdir"""
        if self._workdir is None:
            raise Exception('working directory not set')

        return self._workdir

    @workdir.setter
    def workdir(self, workdir):
        """Setter of workdir"""
        if self._workdir is not None:
            raise Exception('working directory alreay set')

        workdir = os.path.abspath(workdir)
        if not os.path.exists(workdir):
            os.makedirs(workdir)

        self._workdir = workdir

    def create_indexes(self, collection, indexes):
        """Create indexes for specified collection

        Create indexes in the specified collection, the index string format is
        supposed to be like '<idx1>;<idx2>;<idx3>:1,<idx4>:1', which were splitted
        by ';' and combined index joined by ',', orderred with ':'

        @param collection: collection object to perfrom
        @param indexes: index strings
        """
        if isinstance(indexes, basestring):
            indexes = indexes.split(';')

        for idx in indexes:
            if ':' in idx:
                idx = map(lambda x: tuple((x.split(':')[0], int(x.split(':')[1]))), idx.split(','))
            try:
                collection.create_index(idx)
            except Exception as e:
                print str(e)

    def create_primary_key(self, admin, dbname, colname, key):
        """Create primary key for specified collection

        @param admin:
        @param full_colname:
        @param key:
        """
        try:
            admin.command('enablesharding', dbname)
            full_colname = '%s.%s' % (dbname, colname)
            admin.command('shardcollection', full_colname, key={key: 1, '_id': 1})
        except Exception as e:
            print str(e)

    def increase(self, dbname, primary_key=None, indexes=None, fwd=1):
        """Increase new collections which may be used in the future

        Create some new subsequent collections to be ready for future use,
        the subsequent collections should be following by the present day
        in the specified database, if today were 2017-01-01, the subsequent
        one will be named with 'aem_20170102' in database 'aem'

        @param dbname: database name to perform
        @param fwd: following days to perform
        """
        client = MongoClient(self.host, self.port)
        database = client[dbname]

        today = date.today()
        for i in xrange(fwd):
            date_new = today + timedelta(days=i + 1)
            colname_new = '%s_%s' % (dbname, date_new.strftime('%Y%m%d'))
            if colname_new not in database.collection_names():
                print 'creating collection %s.%s...' % (dbname, colname_new)
                collect = database.create_collection(colname_new)
                if primary_key:
                    full_colname = '%s.%s' % (dbname, colname_new)
                    print 'creating primary key: %s' % primary_key
                    self.create_primary_key(client.admin, dbname, colname_new, primary_key)
                if indexes:
                    print 'creating indexes: %s' % indexes
                    self.create_indexes(collect, indexes)

        client.close()

    def backup(self, dbname, ago=10):
        """Backup collections which were out of date

        Dump some outdated collections to data files, and drop them from
        MongoDB database to clean database storing, the outdated time
        would be indicated by 'ago', which always counted by day

        @params dbname: database name to be perform
        @params ago: days to be marked as out-of-date
        """
        client = MongoClient(self.host, self.port)
        database = client[dbname]

        date_ago = date.today() - timedelta(days=ago)
        for colname in database.collection_names():
            m = re.match(r'%s_(\d{8})' % dbname, colname)
            if m:
                d = m.group(1)
                date_tag = date(int(d[0:4]), int(d[4:6]), int(d[6:8]))
                if date_tag < date_ago:
                    print 'dumping collection %s.%s...' % (dbname, colname)
                    mongodump(dbname, colname, self.workdir, self.host, self.port)
                    print 'droping collection %s.%s...' % (dbname, colname)
                    try:
                        database.drop_collection(colname)
                    except Exception as e:
                        print str(e)

        client.close()

    def cleanup(self, dbname, ago=30):
        """Clean up backup files which were out of date

        Clean up some outdated data files to reduce the disk space

        @param dbname: database name to be perform
        @param ago: days to be marked as out-of-date
        """
        date_ago = date.today() - timedelta(days=ago)
        locate = os.path.join(self.workdir, dbname)
        for fname in os.listdir(locate):
            m = re.match(r'%s_(\d{8})\.[^0-9]*' % dbname, fname)
            if m:
                d = m.group(1)
                date_tag = date(int(d[0:4]), int(d[4:6]), int(d[6:8]))
                if date_tag < date_ago:
                    print 'removing backup file %s...' % fname
                    os.remove(os.path.join(locate, fname))

