# encoding: utf-8
from __future__ import absolute_import

from kombu import Queue
from datetime import timedelta
from celery.schedules import crontab
from mealery.settings import MysqlConfig, MongoConfig

BROKER_URL = 'amqp://guest@127.0.0.1:5672//'
CELERY_RESULT_BACKEND = 'amqp://guest@127.0.0.1:5672//'

CELERY_TIMEZONE = 'Asia/Shanghai'

CELERY_IMPORTS = (
    'mealery.mysqladmin.tasks',
    'mealery.mongoadmin.tasks',
)

CELERY_QUEUE = (
    Queue('default', routing_key='task.#'),
    Queue('database', routing_key='db.#'),
    Queue('web', routing_key='web.#'),
)

CELERY_ROUTES = {
    'mealery.mysqladmin.tasks.maintain': {
        'queue': 'database',
        'routing_key': 'db.mysql',
    },
    'mealery.mongoadmin.tasks.maintain': {
        'queue': 'database',
        'routing_key': 'db.mongo',
    },
}

CELERYBEAT_SCHEDULE = {
    'maintain-mysql-table-%s' % MysqlConfig.TABLES[0]: {
        'task': 'mealery.mysqladmin.tasks.maintain',
        'schedule': crontab(minute=0, hour=1),
        'args': (MysqlConfig.HOST, MysqlConfig.PORT, MysqlConfig.USER, MysqlConfig.PASS, MysqlConfig.DATABASE, MysqlConfig.TABLES[0]),
        'kwargs': {
            'workdir': MysqlConfig.WORK_DIR,
            'cleanup_days': MysqlConfig.CLEANUP_DAYS,
            'backup_days': MysqlConfig.BACKUP_DAYS,
            'increase_days': MysqlConfig.INCREASE_DAYS,
        }
    },
    'maintain-mysql-table-%s' % MysqlConfig.TABLES[1]: {
        'task': 'mealery.mysqladmin.tasks.maintain',
        'schedule': crontab(minute=0, hour=1),
        'args': (MysqlConfig.HOST, MysqlConfig.PORT, MysqlConfig.USER, MysqlConfig.PASS, MysqlConfig.DATABASE, MysqlConfig.TABLES[1]),
        'kwargs': {
            'workdir': MysqlConfig.WORK_DIR,
            'cleanup_days': MysqlConfig.CLEANUP_DAYS,
            'backup_days': MysqlConfig.BACKUP_DAYS,
            'increase_days': MysqlConfig.INCREASE_DAYS,
        }
    },
    'maintain-mysql-table-%s' % MysqlConfig.TABLES[2]: {
        'task': 'mealery.mysqladmin.tasks.maintain',
        'schedule': crontab(minute=0, hour=1),
        'args': (MysqlConfig.HOST, MysqlConfig.PORT, MysqlConfig.USER, MysqlConfig.PASS, MysqlConfig.DATABASE, MysqlConfig.TABLES[2]),
        'kwargs': {
            'workdir': MysqlConfig.WORK_DIR,
            'cleanup_days': MysqlConfig.CLEANUP_DAYS,
            'backup_days': MysqlConfig.BACKUP_DAYS,
            'increase_days': MysqlConfig.INCREASE_DAYS,
        }
    },
    'maintain-mongo-database-%s' % MongoConfig.DATABASES[0]: {
        'task': 'mealery.mongoadmin.tasks.maintain',
        'schedule': crontab(minute=0, hour=2),
        'args': (MongoConfig.HOST, MongoConfig.PORT, MongoConfig.USER, MongoConfig.PASS, MongoConfig.DATABASES[0]),
        'kwargs': {
            'workdir': MongoConfig.WORK_DIR,
            'cleanup_days': MongoConfig.CLEANUP_DAYS,
            'backup_days': MongoConfig.BACKUP_DAYS,
            'increase_days': MongoConfig.INCREASE_DAYS,
            'primary_key': 'actime',
            'index_keys': 'uid;ip;isp;prvn:1,city:1'
        }
    },
    'maintain-mongo-database-%s' % MongoConfig.DATABASES[1]: {
        'task': 'mealery.mongoadmin.tasks.maintain',
        'schedule': crontab(minute=0, hour=2),
        'args': (MongoConfig.HOST, MongoConfig.PORT, MongoConfig.USER, MongoConfig.PASS, MongoConfig.DATABASES[1]),
        'kwargs': {
            'workdir': MongoConfig.WORK_DIR,
            'cleanup_days': MongoConfig.CLEANUP_DAYS,
            'backup_days': MongoConfig.BACKUP_DAYS,
            'increase_days': MongoConfig.INCREASE_DAYS,
            'primary_key': 'actime',
            'index_keys': 'uid;ip;isp;prvn:1,city:1'
        }
    },
    'maintain-mongo-database-%s' % MongoConfig.DATABASES[2]: {
        'task': 'mealery.mongoadmin.tasks.maintain',
        'schedule': crontab(minute=0, hour=2),
        'args': (MongoConfig.HOST, MongoConfig.PORT, MongoConfig.USER, MongoConfig.PASS, MongoConfig.DATABASES[2]),
        'kwargs': {
            'workdir': MongoConfig.WORK_DIR,
            'cleanup_days': MongoConfig.CLEANUP_DAYS,
            'backup_days': MongoConfig.BACKUP_DAYS,
            'increase_days': MongoConfig.INCREASE_DAYS,
            'primary_key': 'actime',
            'index_keys': 'isp;prvn:1,city:1'
        }
    },
}
