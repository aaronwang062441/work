"""
"""

import sys
import json
import logging

from datetime import datetime
from kafka import KafkaConsumer
from pymongo import MongoClient


def jsondecode(s):
    """Decoder for json string"""
    try:
        return json.loads(s.decode('utf-8'))
    except:
        return None


class MongoConsumer(object):
    """Consumer class to transparent kafka message to mongo database

    Usage::
      >>>
      >>>
    """
    def __init__(self, host, port, kafka, group, topic):
        """Constructor"""
        self.host = host
        self.port = port
        self.kafka = kafka
        self.group = group
        self.topic = topic
        self.mongodb = None
        self.consumer = None

    def __del__(self):
        """Destructor"""
        if self.consumer:
            self.consumer.close()
        if self.mongodb:
            self.mongodb.close()

    def create_mongodb(self):
        """Create mongo client instance"""
        try:
            self.mongodb = MongoClient(self.host, self.port)
            self.database = self.mongodb[self.topic]

        except Exception as e:
            logging.error('create mongo client failed: %s', e)
            raise

    def create_consumer(self):
        """Creaet kafka consumer instance"""
        try:
            self.consumer = KafkaConsumer(
                self.topic,
                group_id=self.group,
                bootstrap_servers=self.kafka,
                value_deserializer=jsondecode
            )

        except Exception as e:
            logging.error('create kafka consumre failed: %s', e)
            raise

    def run(self, post_field):
        """Consume kafka message to store into mongo database

          @param post_field: indicate user post field
        """
        if not self.mongodb:
            self.create_mongodb()

        if not self.consumer:
            self.create_consumer()

        for msg in self.consumer:
            if msg.value is None:
                continue

            if post_field not in msg.value:
                continue

            try:
                if isinstance(msg.value['actime'], basestring):
                    msg.value['actime'] = datetime.strptime(msg.value['actime'], '%Y-%m-%d %H:%M:%S')

                if isinstance(msg.value[post_field], basestring):
                    msg.value[post_field] = json.loads(msg.value[post_field])

                colname = '%s_%s' % (self.topic, msg.value['actime'].strftime('%Y%m%d'))
                self.database[colname].insert_one(msg.value)

            except (ValueError, TypeError, KeyError) as e:
                logging.error('load json failed: %s', e)

            except Exception as e:
                logging.error('perform consuming failed: %s', e)
