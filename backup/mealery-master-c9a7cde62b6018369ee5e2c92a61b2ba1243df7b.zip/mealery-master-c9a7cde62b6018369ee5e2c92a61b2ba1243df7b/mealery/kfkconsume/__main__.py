#!/usr/bin/env python
# encoding: utf-8

import sys
from optparse import OptionParser
from consume import MongoConsumer

parser = OptionParser('%prog [options]')
parser.remove_option('-h')
parser.add_option('--help', action='help', help='show this help message')
parser.add_option('-h', '--host', action='store', dest='host', help='mongo host to connect to')
parser.add_option('-p', '--port', action='store', dest='port', help='server port')
parser.add_option('-k', '--kafka', action='store', dest='kafka', help='kafka bootstrap servers')
parser.add_option('-g', '--group', action='store', dest='group', help='kafka consume group')
parser.add_option('-t', '--topic', action='store', dest='topic', help='kafka consume topic')
parser.add_option('-d', '--field', action='store', dest='field', help='user post field')

opts, args = parser.parse_args()

if not opts.topic:
    parser.print_help()
    sys.exit(-2)

if not opts.host:
    opts.host = '127.0.0.1'

if not opts.port:
    opts.port = 27017
else:
    opts.port = int(opts.port)

if not opts.kafka:
    opts.kafka = '127.0.0.1:9092'
opts.kafka = opts.kafka.split(',')

if not opts.group:
    opts.group = 'test-group'

if not opts.field:
    opts.field = 'stuckinfo'

consumer = MongoConsumer(opts.host, opts.port, opts.kafka, opts.group, opts.topic)
consumer.run(opts.field)

