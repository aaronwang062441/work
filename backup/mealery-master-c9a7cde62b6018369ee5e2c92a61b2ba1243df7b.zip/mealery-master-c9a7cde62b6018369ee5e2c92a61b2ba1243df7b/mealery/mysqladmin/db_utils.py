"""Utilities for database maintainance

This module provides the Utilities for Wrapping database maintaining
command, like mongodump, mongorestore, mysqldump, mysqlimport, etc
"""
from os_utils import system, call, which


def mongodump(dbname, colname, outdir='.', host='localhost', port=27017):
    """Wrapper for mongodump command

    Export the content of a running server into .bson files
    See http://docs.mongodb.org/manual/reference/program/mongodump/ for more information.

    @param dbname: database name to perform
    @param colname: collection name to perform
    @param outdir: output directory
    @param host: mongdb host to connect to
    @param port: server port
    @return: return code of command
    """
    if not dbname or not colname:
        return None

    executable = which('mongodump')
    if not executable:
        return None

    cmdln = [
        executable,
        '-h', host, '--port', port,
        '-d', dbname, '-c', colname,
        '-o', outdir
    ]
    rc, out = call(cmdln)
    return rc

def mongorestore(dbname, colname, datadir='.', host='localhost', port=27017):
    """Wrapper for mongorestore command

    Restore backups generated with mongodump to a running server.
    See http://docs.mongdb.org/manual/reference/program/mongorestore/ for more information.

    @param dbname: database name to perform
    @param colname: collection name to perform
    @param datadir: data directory to be restored
    @param host: mongdb host to connect to
    @param port: server port
    @return: return code of command
    """
    if not dbname or not colname:
        return None

    executable = which('mongorestore')
    if not executable:
        return None

    cmdln = [
        executable,
        '-h', host, '--port', port,
        '-d', dbname, '-c', colname,
        datadir
    ]
    rc, out = call(cmdln)
    return rc

def mongoexport(dbname, colname, outdir='.', host='localhost', port=27017):
    """Wrapper for mongoexport command

    Export data from MOngoDB in CSV or JSON format
    See http://docs.mongdb.org/manual/reference/program/mongoexport/ for more information.

    @param dbname: database name to perform
    @param colname: collection name to perform
    @param outdir: output directory
    @param host: mongdb host to connect to
    @param port: server port
    @return: return code of command
    """
    if not dbname or not colname:
        return None

    executable = which('mongoexport')
    if not executable:
        return None

    cmdln = [
        executable,
        '-h', host, '--port', port,
        '-d', dbname, '-c', colname,
        '-o', outdir

    ]
    rc, out = call(cmdln)
    return rc

def mongoimport(dbname, colname, datapath, host='localhost', port=27017):
    """Wrapper for mongoimport command

    Import CSV, TSV or JSON data into MongoDB.
    See http://docs.mongdb.org/manual/reference/program/mongoimport/ for more information.

    @param dbname: database name to perform
    @param colname: collection name to perform
    @param datapath: data file to be imported
    @param host: mongdb host to connect to
    @param port: server port
    @return: return code of command
    """
    if not dbname or not colname:
        return None

    executable = which('mongoimport')
    if not executable:
        return None

    cmdln = [
        executable,
        '-h', host, '--port', port,
        '-d', dbname, '-c', colname,
        datapath
    ]
    rc, out = call(cmdln)
    return rc

def mysqldump(dbname, tblname, dumpfile='test.sql', host='localhost', port=3306,
              username='root', password='', where='', extra_opts=''):
    """Wrapper for mysqldump command

    Dumping structure and contents of MySQL databases and tables.

    @param dbname: database name to perform
    @param tblname: table name to perform
    @param outdir: output directory
    @param host: mysqldb host to connect to
    @param port: port number to use
    @param username: user for login
    @param password: password to use when connecting
    @param where: dump only selected records
    @param extra_opts: extra options for mysqldump
    @return: return code for command
    """
    if not dbname or not tblname:
        return None

    executable = which('mysqldump')
    if not executable:
        return None

    cmdln = [
        executable,
        '-h', str(host), '-P', str(port),
        '-u', str(username), '-p{}'.format(password),
        str(dbname),
        str(tblname)
    ]
    if where:
        cmdln.extend(['-w', '"{}"'.format(where)])
    if extra_opts:
        cmdln.extend(extra_opts.split())
    rc = system(' '.join(cmdln) + "| gzip > {}".format(dumpfile))
    return rc

def mysqlimport(dbname, dumpfile, host='localhost', port=3306,
                username='root', password='', extra_opts=''):
    """Wrapper for mysqlimport command

    Loads tables from text files in various formats.

    @param dbname: database name to perform
    @param dumpfile: text files to be imported
    @param host: mysqldb host to connect to
    @param port: port number to use
    @param username: user for login
    @param password: password to use when connecting
    @param extra_opts: extra options for mysqldump
    @return: return code for command
    """
    if not dbname or not txtfile:
        return None

    executable = which('mysqlimport')
    if not executable:
        return None

    cmdln= [
        executable,
        '-h', str(host), '-P', str(port),
        '-u', str(username), '-p{}'.format(password),
        str(dbname),
        str(txtfile)
    ]
    if extra_opts:
        cmdln.extend(extra_opts.split())
    rc, out = call(cmdln)
    return rc
