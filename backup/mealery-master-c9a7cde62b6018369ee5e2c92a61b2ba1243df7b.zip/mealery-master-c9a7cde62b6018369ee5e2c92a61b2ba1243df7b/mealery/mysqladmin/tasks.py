"""MySQL maintainance

Provides MySQL maintainance like increasing, backup, cleanup
"""
from __future__ import absolute_import
from mealery.celery import app, logger
from mealery.mysqladmin.maintain import MysqlMaintain

@app.task(ignore_result=True)
def maintain(host, port, username, password, dbname, tblname, *args, **kwargs):
    """Interface of celery task entry"""
    logger.info('%s' % locals())

    instance = MysqlMaintain(host, port, username, password, dbname)
    instance.workdir = kwargs.get('workdir', '.')
    instance.cleanup(tblname, kwargs.get('cleanup_days', 30))
    instance.backup(tblname, kwargs.get('backup_days', 10))
    instance.increase(tblname, kwargs.get('increase_days', 1))

    return True


