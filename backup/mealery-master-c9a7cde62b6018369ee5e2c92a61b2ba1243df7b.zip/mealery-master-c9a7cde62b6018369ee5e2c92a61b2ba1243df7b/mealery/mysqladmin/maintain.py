"""MySQL maintainance

Provides MySQL maintainance like increasing, backup, cleanup
"""
import os
import re

from datetime import datetime, timedelta
from torndb import Connection

from db_utils import mysqldump


class MysqlMaintain(object):
    """Mysql maintainance

    This class provides operations performed on mysql database,
    includes increase partition, backup partition into outfile,
    and drop data out of time.

    Usage:
       >>> instance = Mysqlmaintain(host, port, username, passwd, dbname)
       >>> instance.set_workdir('.')
       # create a new partition for tomorrow
       >>> instance.create(tblname, 1)
       # backup 10 days before partitions into outfile
       >>> instance.backup(tblname, 10)
       # cleanup outfile before 30 days
       >>> instance.cleanup(tblname, 30)
    """
    def __init__(self, host, port, username, password, dbname):
        """Initialize a mysql maintenance instance

        @param host: remote host of mysql
        @param port: remote port of mysql
        @param username: remote username of mysql
        @param password: remote password of mysql
        @param dbname: mysql database name
        """
        self._workdir = None
        self._database = None

        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.dbname = dbname

    def __del__(self):
        self.close_database()

    @property
    def workdir(self):
        """Getter of workdir"""
        if self._workdir is None:
            raise Exception('working directory not set')

        return self._workdir

    @workdir.setter
    def workdir(self, workdir):
        """Setter of workdir"""
        if self._workdir is not None:
            raise Exception('working directory already set')

        workdir = os.path.abspath(workdir)
        if not os.path.exists(workdir):
            os.makedirs(workdir)

        self._workdir = workdir

    def close_database(self):
        if getattr(self, "_database", None) is not None:
            self._database.close()
            self._database = None

    def connect_database(self):
        """Connect to MySQL"""
        self.close_database()
        self._database = Connection(
            host='%s:%s' % (self.host, self.port),
            database=self.dbname,
            user=self.username,
            password=self.password
        )

    def _ensure_connected(self):
        if self._database is None:
            self.connect_database()

    def show_tables(self):
        """Get tables of dbname"""
        self._ensure_connected()

        sql = "SHOW TABLES"
        return map(lambda x: x.get("Tables_in_%s" % self.dbname), self._database.query(sql))

    def show_partitions(self, tblname):
        self._ensure_connected()

        sql = "SELECT PARTITION_NAME FROM INFORMATION_SCHEMA.PARTITIONS WHERE TABLE_SCHEMA='{0}' AND TABLE_NAME = '{1}'"
        sql = sql.format(self.dbname, tblname)
        return filter(None, map(lambda x: x.get('PARTITION_NAME'), self._database.query(sql)))

    def increase(self, tblname, fwd=1):
        """Create new partitions which may be used in the future

        Create some partitions for future use, for example we create the partition named P20170609,
        it is created for 2017-06-09 and 2017-06-09's data will be saved into this partition.

        Usage:
            # just create partition for tomorrow
            >>> create('test', 1)
            # create partition for tomorrow and the day after tomorrow
            >>> create('test', 1)

        @param tblname: table to create new partition(s)
        @param fwd: forward days
        """
        self._ensure_connected()

        # Get partitions
        partitions = self.show_partitions(tblname)
        if not partitions:
            print ("Table %s.%s does not support partition" % (self.dbname, tblname))
            return False

        # Format sql string
        if 'PFUTURE' in partitions:
            sql_fmt = "ALTER TABLE {table} REORGANIZE PARTITION PFUTURE INTO (\
                PARTITION {part} VALUES LESS THAN (TO_DAYS('{day}'+1)),\
                PARTITION PFUTURE VALUES LESS THAN MAXVALUE)"
        else:
            sql_fmt = "ALTER TABLE {table} ADD PARTITION (\
                PARTITION {part} VALUES LESS THAN (TO_DAYS('{day}'+1)))"

        # Get datetime and format mysql partition name
        dates_to_create = map(lambda x: datetime.today() + timedelta(days=x+1), xrange(fwd))

        # Create partition
        for dt in dates_to_create:
            part = 'P{0}'.format(dt.strftime('%Y%m%d'))

            if part in partitions:
                continue


            sql = sql_fmt.format(table=tblname, part=part, day=dt.strftime("%Y%m%d"))

            try:
                self._database.execute(sql)
            except Exception:
                print "Table %s create partition %s error!" % (tblname, part)

        return True

    def backup(self, tblname, ago=10):
        """Backup partitions which were out of date into outfile

        Usage:
            # backup 10 days before partitions into outfile
            >>> backup('test', 10)


        @params tblname: table to back up partition(s)
        @params ago: clean up data ago days before
        """
        self._ensure_connected()

        # Get partitions
        partitions = self.show_partitions(tblname)
        if not partitions:
            print ("Table %s does not support partition" % tblname)
            return False

        dt_ago = datetime.today() - timedelta(days=ago)
        sql_fmt = "ALTER TABLE {table} DROP PARTITION {part}"
        outdir = os.path.join(self.workdir, self.dbname, tblname)

        for part in partitions:
            if part == 'PFUTURE':
                continue

            dt = datetime.strptime(part[1:], '%Y%m%d')
            if dt < dt_ago:
                dumpfile = os.path.join(outdir, '{0}_{1}.sql.gz'.format(tblname, part[1:]))
                rc = mysqldump(
                    self.dbname, tblname, dumpfile=dumpfile,
                    host=self.host, port=self.port,
                    username=self.username,
                    password=self.password,
                    where='TO_DAYS(time)=TO_DAYS({})'.format(part[1:])
                )

                try:
                    self._database.execute(sql_fmt.format(table=tblname, part=part))
                except Exception:
                    print "Table %s partition %s backup exception!" % (tblname, part)

        return True

    def cleanup(self, tblname, ago=30):
        """Clean up backup files which are out of date

        Usage:
            # cleanup files 30 days before
            >>> cleanup('test', 30)

        @param tblname: table to clean up
        @param ago: clean up data ago days before
        """
        dt_ago = datetime.today() - timedelta(days=ago)
        outdir = os.path.join(self.workdir, self.dbname, tblname)
        for fname in os.listdir(outdir):
            m = re.match('%s_(\d{8}).*' % tblname, fname)
            if m:
                dt = datetime.strptime(m.group(1), "%Y%m%d")
                if dt < dt_ago:
                    print "Removing data file %s" % fname
                    os.remove(os.path.join(outdir, fname))
