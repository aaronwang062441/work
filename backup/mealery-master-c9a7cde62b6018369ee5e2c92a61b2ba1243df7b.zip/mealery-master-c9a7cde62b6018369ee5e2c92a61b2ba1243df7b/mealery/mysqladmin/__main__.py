#!/usr/bin/env python
# encoding: utf-8
import sys
from optparse import OptionParser
from maintain import MysqlMaintain


if __name__ == "__main__":
    parser = OptionParser('%prog [options]')
    parser.remove_option('-h')
    parser.add_option('-?', '--help', action='help', help='show this help message')
    parser.add_option('-h', '--host', action='store', dest='host', default='localhost', help='mysql host to connect to')
    parser.add_option('-P', '--port', action='store', type='int', dest='port', default=3306, help='mysql server port')
    parser.add_option('-u', '--user', action='store', dest='username', default='root', help='mysql username')
    parser.add_option('-p', '--password', action='store', dest='password', default='', help='mysql password')
    parser.add_option('-o', '--workdir', action='store', dest='workdir', default='.', help='directory to work on')
    parser.add_option('-d', '--database', action='store', dest='dbname', help='datebase to operate')
    parser.add_option('-t', '--table', action='store', dest='tblname', help='table to operate')

    parser.add_option('-b', action='store_true', dest='backup', help='perform to back up')
    parser.add_option('--backup-days', action='store', type='int', dest='backup_days', default=10, help='days ago to back up')

    parser.add_option('-c', action='store_true', dest='cleanup', help='perform to clean up')
    parser.add_option('--cleanup-days', action='store', type='int', dest='cleanup_days', default=30, help='days ago to clean up')

    parser.add_option('-r', action='store_true', dest='increase', help='perform to increase up')
    parser.add_option('--increase-days', action='store', type='int', dest='increase_days', default=1, help='days to increase up')

    opts, args = parser.parse_args()

    if not opts.dbname or not opts.tblname:
        parser.error('please specify database and table')
        sys.exit(-2)

    m = MysqlMaintain(opts.host, opts.port, opts.username, opts.password, opts.dbname)
    m.workdir = opts.workdir

    import pdb;pdb.set_trace()
    if opts.cleanup:
        m.cleanup(opts.tblname, opts.cleanup_days)
    if opts.backup:
        m.backup(opts.tblname, opts.backup_days)
    if opts.increase:
        m.increase(opts.tblname, opts.increase_days)
