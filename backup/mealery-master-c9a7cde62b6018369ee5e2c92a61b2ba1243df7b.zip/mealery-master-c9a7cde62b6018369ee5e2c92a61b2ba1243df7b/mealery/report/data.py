
class DataSource(object):
    pass

class MysqlDataSource(DataSource):
    pass
