
def send_mail(subject, message, from_email, recipient_list,
              auth_user=None, auth_password=None, html_message=None):
    pass


class EmailMessage(object):
    def __init__(self, subject='', body='', from_email=None, to=None, bcc=None,
                 attachments=None, headers=None, cc=None, reply_to=None):
        pass

    def message(self):
        pass

    def recipients(self):
        pass

    def send(self):
        pass

    def attach(self):
        pass

    def attach_file(self):
        pass
