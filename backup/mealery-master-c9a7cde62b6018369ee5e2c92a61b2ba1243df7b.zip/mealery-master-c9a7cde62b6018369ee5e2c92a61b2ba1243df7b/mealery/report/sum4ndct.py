
class IndexReport(Object):
    def __init__(self):
        self._html = None
        self._fig_pie = None
        self._fig_count = None

    @property
    def html(self):
        if self._html:
            return self._html
        pass

    @property
    def fig_pie(self):
        if self._fig_pie:
            return self._fig_pie
        pass

    @property
    def fig_count(self):
        if self._fig_count:
            return self._fig_count
        pass

    def plot_pie_fig(self, data):
        pass

    def plot_count_fig(self, data):
        pass
