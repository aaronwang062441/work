
import sys
from optparse import OptionParser
from sum4ndct import IndexReport
from mail import send_mail

parser = OptionParser('%prog [options]')

opts, args = parser.parse_args()

if opts.ndct:
    report = IndexReport()
    send_mail()

