"""Utilities for OS

This module provides the Utilities for easy use of OS functions,
like executing a command, find executable, etc
"""
import os
from subprocess import Popen, PIPE

def call(cmdln):
    """Execute a command from command line

    A string would be split into list to enable Popen executing the command
    by forking a new subprocess rather than executing it by forking a new
    shell.

    @param cmdln: a command present by a list or a string
    @return: a tuple of return code of process and output of the comamnd
    """
    if not isinstance(cmdln, list):
        cmdln = cmdln.split()

    p = Popen(cmdln, shell=False, stdout=PIPE, stderr=PIPE)
    out, err = p.communicate()
    return (p.returncode, out + err)

def which(exe, path=None):
    """Tries to find 'exe' in the directories listed in 'path'.

    A string listing directories seprated by 'os.pathsep'; defaults to
    os.environ['PATH']. Returns the complete filename or None if not found.

    @param exe:
    @param path: paths to find, default to PATH environment variable
    @return: the complete filename or None if not found
    """
    if path is None:
        path = os.environ['PATH']
    paths = path.split(os.pathsep)

    if not os.path.isfile(exe):
        for p in paths:
            f = os.path.join(p, exe)
            if os.path.isfile(f):
                return f
        return None
    else:
        return exe

