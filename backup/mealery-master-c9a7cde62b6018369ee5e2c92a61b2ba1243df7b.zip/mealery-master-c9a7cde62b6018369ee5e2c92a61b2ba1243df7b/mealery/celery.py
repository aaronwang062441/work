# encoding: utf-8

from __future__ import absolute_import
from celery.utils.log import get_task_logger
from celery import Celery

logger = get_task_logger(__name__)

app = Celery('mealery')
app.config_from_object('mealery.celeryconfig')
