# mealery后台任务系统

mealery = aem (-> mea) + celery

mealery是基于celery构建AEM系统的后台任务管理和执行子系统， 这些后台任务一般都是和基础服务
相关的任务，如数据库维护、数据预警、报表生成、发送 邮件等。

## 安装

## 使用说明


