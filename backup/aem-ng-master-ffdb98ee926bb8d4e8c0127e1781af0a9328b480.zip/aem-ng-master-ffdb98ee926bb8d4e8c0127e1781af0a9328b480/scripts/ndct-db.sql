/*
Host           : sh.netdoctor.w.qiyi.db:8498
Database       : netdoctor
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ndct_ndctinfo
-- ----------------------------
DROP TABLE IF EXISTS `ndct_client`;
CREATE TABLE `ndct_client` (
  `num` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) DEFAULT NULL,
  `access_time` datetime NOT NULL,
  `version` varchar(16) DEFAULT NULL,
  `platform` int(11) DEFAULT NULL,
  `ip` varchar(48) DEFAULT NULL,
  `zone` varchar(128) DEFAULT NULL,
  `stuckinfo` text,
  `ndata1` int(11) DEFAULT NULL,
  `ndata2` int(11) DEFAULT NULL,
  `sdata3` varchar(128) DEFAULT NULL,
  `sdata4` text,
  PRIMARY KEY (`num`,`access_time`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

-- ----------------------------
-- Table structure for ndct_pumainfo
-- ----------------------------
DROP TABLE IF EXISTS `ndct_coreinfo`;
CREATE TABLE `ndct_coreinfo` (
  `num` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL,
  `access_time` datetime NOT NULL,
  `version` varchar(16) DEFAULT NULL,
  `platform` int(11) DEFAULT NULL,
  `ip` varchar(48) DEFAULT NULL,
  `zone` varchar(128) DEFAULT NULL,
  `coreinfo` text,
  `ndata1` int(11) DEFAULT NULL,
  `ndata2` int(11) DEFAULT NULL,
  `sdata3` varchar(256) DEFAULT NULL,
  `sdata4` text,
  PRIMARY KEY (`num`,`access_time`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

-- ----------------------------
-- Table structure for ndct_hcdninfo
-- ----------------------------
DROP TABLE IF EXISTS `ndct_hcdninfo`;
CREATE TABLE `ndct_hcdninfo` (
  `num` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL,
  `access_time` datetime NOT NULL,
  `version` varchar(16) DEFAULT NULL,
  `platform` int(11) DEFAULT NULL,
  `ip` varchar(48) DEFAULT NULL,
  `zone` varchar(128) DEFAULT NULL,
  `hcdninfo` text,
  `ndata1` int(11) DEFAULT NULL,
  `ndata2` int(11) DEFAULT NULL,
  `sdata3` varchar(256) DEFAULT NULL,
  `sdata4` text,
  PRIMARY KEY (`num`,`access_time`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

-- ----------------------------
-- Table structure for ndct_pingback
-- ----------------------------
DROP TABLE IF EXISTS `ndct_pingback`;
CREATE TABLE `ndct_pingback` (
  `num` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL,
  `access_time` datetime NOT NULL,
  `version` varchar(16) DEFAULT NULL,
  `platform` int(11) DEFAULT NULL,
  `pback_type` int(11) DEFAULT NULL,
  `ip` varchar(48) DEFAULT NULL,
  `zone` varchar(128) DEFAULT NULL,
  `pingback` text,
  `ndata1` int(11) DEFAULT NULL,
  `ndata2` int(11) DEFAULT NULL,
  `sdata3` varchar(256) DEFAULT NULL,
  `sdata4` text,
  PRIMARY KEY (`num`,`access_time`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

-- ------------------------------
-- Table structure for ndct_probe
-- ------------------------------
DROP TABLE IF EXISTS `ndct_probe`;
CREATE TABLE `ndct_probe` (
  `num` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL,
  `policy` varchar(128) DEFAULT NULL,
  `period` varchar(64) DEFAULT NULL,
  `reqs` int(5) unsigned NOT NULL,
  `gap` int(5) unsigned NOT NULL,
  `dlurl` varchar(512) DEFAULT NULL,
  `cmd` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

