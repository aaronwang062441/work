package.path = '/opt/soft/aem/lualib/?.lua;;'
package.cpath = '/opt/soft/aem//lualib/?.so;;'

local cjson = require("cjson")

--[[
-- Global variable
--]]

--
-- USE_PERF = true
--

wrk = wrk or {
    scheme  = "http",
    host    = "localhost",
    port    = "http",
    method  = "GET",
    path    = "/",
    haeders = {},
    body    = nil,
}

--[[
-- Utilities
--]]

function table.clone(org)
    -- return {table.unpack(rog)}
    return org
end

local function expand_chars(charset)
    charset = charset or 'a-z'
    local chars = {}
    local ch = ''
    local i = 1
    while i <= #charset do
        ch = string.sub(charset, i, i)
        if ch == '-' and i > 1 and i < #charset then
            ch = string.sub(charset, i-1, i-1)
            local beg = string.byte(ch)
            ch = string.sub(charset, i+1, i+1)
            local lst = string.byte(ch)
            if beg <= lst then
                beg = beg + 1
                while beg <= lst do
                    table.insert(chars, string.char(beg))
                    beg = beg + 1
                end
            else
                beg = beg - 1
                while beg >= lst do
                    table.insert(chars, string.char(beg))
                    beg = beg - 1
                end
            end
            i = i + 1
        else
            table.insert(chars, ch)
        end
        i = i + 1
    end
    return chars
end

function fake_bool()
    return math.random(1, 2) - 1
end

function fake_int(lower, upper)
    lower = lower or 0
    upper = upper or math.huge
    return math.random(lower, upper)
end

function fake_str(length, charset)
    length = length or 1
    charset = charset or "a-zA-Z"

    local chars = expand_chars(charset)
    local str = ''
    while length > 0 do
        str = str..chars[math.random(1, #chars)]
        length = length - 1
    end
    return str
end

function fake_uuid(length)
    return fake_str(length, "0-9a-fA-F")
end

function fake_status(codes)
    codes = codes or {200, 302}
    return codes[math.random(1, #codes)]
end

function fake_ip()
    local list = {0, 0, 0, 0}
    for i, v in ipairs(list) do
        list[i] = math.random(1, 255)
    end
    return tostring(table.concat(list, '.'))
end

function fake_version(vers)
    vers = vers or {'1.0.5', '1.0.6', '1.0.7', '1.0.8'}
    return vers[math.random(1, #vers)]
end

function fake_url(path, opts)
    opts = opts or {}
    local args = {}
    for k, v in pairs(opts) do
        table.insert(args, k.."="..v)
    end
    return path..'?'..table.concat(args, '&')
end

function fake_json(opts)
    opts = opts or {}
    return cjson.encode(opts)
end

math.randomseed(os.time())

--[[
-- Request related
--]]

local function create_url(path)
    local opts = {
        uid    = fake_uuid(16),
        ver    = fake_version(),
        plat   = fake_int(0, 4),
    }
    return fake_url(path, opts)
end

local function create_headers(headers)
    local copy_headers = table.clone(headers)
    copy_headers['X-Real-IP'] = fake_ip()
    return copy_headers
end

local function create_body()
    local template = {
        play_result =  {
            timeout   = fake_bool(),
            version   = fake_version(),
            vip_res   = fake_bool(),
            vip_user  = fake_bool(),
            vid       = fake_uuid(32),
            tvid      = fake_str(9, '0-9'),
            bid       = "",
            aid       = fake_str(9, '0-9'),
            cid       = fake_str(1, '0-9'),
            file_tpye = "F4V",
            rate      = fake_int(0, 100),
            timepoint = fake_int(0, 90000),
            auth_succ = fake_bool(),
            step      = fake_int(1, 25),
            network_duration = fake_int(0, 6000),
            vip_duration     = fake_int(0, 6000),
            get_key_succ     = fake_bool(),
            access_vrs = {
                url         = fake_url('http://cache.video.qiyi.com/vps', {tvid='516086500'}),
                code        = fake_status(),
                duration    = fake_int(0, 3000),
                ip          = fake_ip(),
                return_data = ""
            },
            access_pdata = {
                url         = fake_url('http://data.video.qiyi.com/videos/v0/5a2e10415682611e8ee2d50c4a1accaa.f4v'),
                ip          = fake_ip(),
                code        = fake_status(),
                duration    = fake_int(0, 6000),
                return_data = "",
            },
            access_vip = {
                url         = "",
                ip          = "",
                duration    = 0,
                return_data = "",
            },
            cache_status = {
                host          = fake_ip(),
                url           = fake_url('http://'..fake_ip()..'/videos'),
                code          = fake_status(),
                duration      = fake_int(0, 6000),
                conn_duration = fake_int(0, 6000),
                avg_speed     = fake_int(0, 10000),
                max_speed     = fake_int(0, 10000),
                state         = fake_int(0, 10),
                ping = {
                    req_cnt   = 0,
                    lost_cnt  = 0,
                    lost_rate = 0,
                    avg_rtt   = 0,
                    max_rtt   = 0,
                    min_rtt   = 0,
                    dst       = ""
                },
                tracert = {
                    dst       =  "",
                    hop_list  = {}
                }
            },
            dns = {
                dns_rtt       = fake_int(0, 100),
                list          = {fake_ip(), fake_ip()}
            }
        }
    }
    return cjson.encode(template)
end

local function create_request(wrk)
    return wrk.format(
        wrk.method,
        create_url(wrk.path),
        create_headers(wrk.headers),
        create_body()
    )
end

if USE_PERF then
    wrk.method = 'POST'
    wrk.path = fake_url(wrk.path, opts)
end

--[[
-- Setup phase
--]]

local counter = 1
local threads = {}

function setup(thread)
    thread:set('id', counter)
    table.insert(threads, thread)
    counter = counter + 1
end

--[[
-- Running phase
--]]

function init(args)
    requests = 0
    responses = 0
end

function delay()
end

function request()
    requests = requests + 1

    if USE_PERF then
        return wrk.request()
    else
        return create_request(wrk)
    end
end

function response(status, headers, body)
    responses = responses + 1
end

--[[
-- Done phase
--]]

function done(summary, latency, requests)
    io.write("------------\n")
    for index, thread in ipairs(threads) do
        local id = thread:get('id')
        local requests = thread:get('requests')
        local responses = thread:get('responses')
        local msg = "thread %d made %d requests and got %d responses\n"
        io.write(string.format(msg, id, requests, responses))
    end

    io.write("------------\n")
    for _, p in pairs({50, 90, 99, 99.999}) do
        n = latency:percentile(p)
        io.write(string.format("%g%%, %d\n", p, n))
    end
end
