#!/bin/sh

host=
port=
database=
collection=

usage() {
    echo "usage: `basename $0` <options>"
    echo ""
    echo "  -h|--host [HOST]       ip address of mysql server (default: localhost)"
    echo "  -p|--port [PORT]       port of mysql server (default: 27017)"
    echo "  -d|--databases [DB]    database name to perform (required)"
    echo "  -c|--collection [COLL] collection name to perform (required)"

}

while [ -n "$1" ];
do
    case "$1" in
        -h|--host)
            host="$2"
            shift
            ;;
        -p|--port)
            port="$2"
            shift
            ;;
        -d|--database)
            database="$2"
            shift
            ;;
        -c|--collection)
            collection="$2"
            shift
            ;;
        *)
            usage
            exit
            ;;
    esac
    shift
done

if [ -z "$host" ]; then
    host="localhost"
fi
if [ -z "$port" ]; then
    port="27017"
fi
if [ -z "$database" ]; then
    echo "please specify database"
    exit
fi
if [ -z "$collection" ]; then
    echo "plaase specify collection"
    exit
fi

mongo $host:$port/$database <<EOF
/* 1 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "v.admaster.com.cn",
    "cmd" : {
        "type" : 2.0,
        "dns" : "v.admaster.com.cn"
    }
});

/* 2 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "viqiyi.admaster.com.cn",
    "cmd" : {
        "type" : 2.0,
        "dns" : "viqiyi.admaster.com.cn"
    }
});

/* 3 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "iqiyi.m.cn.miaozhen.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "iqiyi.m.cn.miaozhen.com"
    }
});

/* 4 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "www.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "www.iqiyi.com"
    }
});

/* 5 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "pdata.video.qiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "pdata.video.qiyi.com"
    }
});

/* 6 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "g.cn.miaozhen.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "g.cn.miaozhen.com"
    }
});

/* 7 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "api.cupid.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "api.cupid.iqiyi.com"
    }
});

/* 8 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "msg.71.am",
    "cmd" : {
        "type" : 2.0,
        "dns" : "msg.71.am"
    }
});

/* 9 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "tyaqy.m.cn.miaozhen.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "tyaqy.m.cn.miaozhen.com"
    }
});

/* 10 */
db.${collection}.insert({
    "type" : "2",
    "policy" : {},
    "period" : {},
    "reqs" : "3",
    "gap" : "2",
    "dlurl" : "sf.video.qiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "sf.video.qiyi.com"
    }
});

/* 11 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "t7z.cupid.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "t7z.cupid.iqiyi.com"
    }
});

/* 12 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "ty.viqiyi.admaster.com.cn",
    "cmd" : {
        "type" : 2.0,
        "dns" : "ty.viqiyi.admaster.com.cn"
    }
});

/* 13 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "vtyqy.admaster.com.cn",
    "cmd" : {
        "type" : 2.0,
        "dns" : "vtyqy.admaster.com.cn"
    }
});

/* 14 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "397c0.admaster.com.cn",
    "cmd" : {
        "type" : 2.0,
        "dns" : "397c0.admaster.com.cn"
    }
});

/* 15 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "v2a.qbt.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "v2a.qbt.iqiyi.com"
    }
});

/* 16 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "msg2.video.qiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "msg2.video.qiyi.com"
    }
});

/* 17 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "msg2.video.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "msg2.video.ptqy.gitv.tv"
    }
});

/* 18 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "msga.71.am",
    "cmd" : {
        "type" : 2.0,
        "dns" : "msga.71.am"
    }
});

/* 19 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "msga.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "msga.ptqy.gitv.tv"
    }
});

/* 20 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "flux.hcdn.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "flux.hcdn.ptqy.gitv.tv"
    }
});

/* 21 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "flux.hcdn.ppstream.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "flux.hcdn.ppstream.com"
    }
});

/* 22 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "flux.hcdn.qiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "flux.hcdn.qiyi.com"
    }
});

/* 23 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "msg2.cupid.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "msg2.cupid.iqiyi.com"
    }
});

/* 24 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "msga.cupid.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "msga.cupid.iqiyi.com"
    }
});

/* 25 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "iface.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "iface.iqiyi.com"
    }
});

/* 26 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "iface2.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "iface2.iqiyi.com"
    }
});

/* 27 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.video.qiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.video.qiyi.com"
    }
});

/* 28 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.video.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.video.iqiyi.com"
    }
});

/* 29 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.video.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.video.ptqy.gitv.tv"
    }
});

/* 30 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.video.c002.ottcn.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.video.c002.ottcn.com"
    }
});

/* 31 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "live.video.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "live.video.iqiyi.com"
    }
});

/* 32 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "live.video.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "live.video.ptqy.gitv.tv"
    }
});

/* 33 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "live.video.c002.ottcn.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "live.video.c002.ottcn.com"
    }
});

/* 34 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "drm.video.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "drm.video.iqiyi.com"
    }
});

/* 35 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "drm.video.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "drm.video.ptqy.gitv.tv"
    }
});

/* 36 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.m.qiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.m.qiyi.com"
    }
});

/* 37 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.m.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.m.iqiyi.com"
    }
});

/* 38 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.m.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.m.ptqy.gitv.tv"
    }
});

/* 39 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "cache.m.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "cache.m.c002.ottcn.com"
    }
});

/* 40 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "itv.video.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "itv.video.iqiyi.com"
    }
});

/* 41 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "itv.video.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "itv.video.ptqy.gitv.tv"
    }
});

/* 42 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "itv.video.c002.ottcn.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "itv.video.c002.ottcn.com"
    }
});

/* 43 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "mixer.video.iqiyi.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "mixer.video.iqiyi.com"
    }
});

/* 44 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "mixer.video.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "mixer.video.ptqy.gitv.tv"
    }
});

/* 45 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "mixer.video.ptqy.gitv.tv",
    "cmd" : {
        "type" : 2.0,
        "dns" : "mixer.video.c002.ottcn.com"
    }
});

/* 46 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "meelivepush.fmscachepush.ourdvs.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "meelivepush.fmscachepush.ourdvs.com"
    }
});

/* 47 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "bilibili.fmscachepush.ourdvs.com",
    "cmd" : {
        "type" : 2.0,
        "dns" : "bilibili.fmscachepush.ourdvs.com"
    }
});

/* 48 */
db.${collection}.insert({
    "type" : 2.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "ali-push.v.momocdn.com.w.alikunlun.net",
    "cmd" : {
        "type" : 2.0,
        "dns" : "ali-push.v.momocdn.com.w.alikunlun.net"
    }
});

/* 49 */
db.${collection}.insert({
    "type" : 1.0,
    "policy" : {},
    "period" : {},
    "reqs" : 10.0,
    "gap" : 2.0,
    "dlurl" : "http://msg.video.qiyi.com/vodpb.gif?t=check&rec=msglostrate",
    "cmd" : {
        "type" : 1.0,
        "detection" : "http://msg.video.qiyi.com/vodpb.gif?t=check&rec=msglostrate"
    }
});

/* 50 */
db.${collection}.insert({
    "type" : 3.0,
    "policy" : {},
    "period" : {},
    "reqs" : 1.0,
    "gap" : 15.0,
    "dlurl" : "http://pcclient.download.youku.com/youkuclient/youkuclient_setup_7.1.7.3031_a.exe",
    "cmd" : {
        "type" : 3.0,
        "dload" : "http://pcclient.download.youku.com/youkuclient/youkuclient_setup_7.0.9.11106.exe|76395c723bae163ab4e5b8e0f7766027|0|1048575"
    }
});

/* 51 */
db.${collection}.insert({
    "type" : 3.0,
    "policy" : {},
    "period" : {},
    "reqs" : 1.0,
    "gap" : 15.0,
    "dlurl" : "http://download-10055601.cos.myqcloud.com/RTMPAndroidSDK1.7.1.1171.zip",
    "cmd" : {
        "type" : 3.0,
        "dload" : "http://download-10055601.cos.myqcloud.com/RTMPAndroidSDK1.7.1.1171.zip|7a58ef22bcfe0b7a0de94d1c18a0dd5e|0|1048575"
    }
});

/* 52 */
db.${collection}.insert({
    "type" : 3.0,
    "policy" : {},
    "period" : {},
    "reqs" : 1.0,
    "gap" : 15.0,
    "dlurl" : "http://pdata.video.qiyi.com/videos/v0/20150311/qycs0001.f4v?pv=0.2",
    "cmd" : {
        "type" : 3.0,
        "dload" : "http://pdata.video.qiyi.com/videos/v0/20150311/qycs0001.f4v?pv=0.2|d03f8f5e212c1e6d6f7ab5496abbf8e0|0|1048575"
    }
});
EOF
