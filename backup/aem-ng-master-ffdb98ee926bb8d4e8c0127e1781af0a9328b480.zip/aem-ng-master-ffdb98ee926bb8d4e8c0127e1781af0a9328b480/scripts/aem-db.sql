/*
Host           : sh.netdoctor.w.qiyi.db:8498
Database       : netdoctor
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for aem_ndctinfo
-- ----------------------------
DROP TABLE IF EXISTS `aem_ndctinfo`;
CREATE TABLE `aem_ndctinfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) NOT NULL,
  `actime` varchar(64) DEFAULT NULL,
  `ver` varchar(64) DEFAULT NULL,
  `plat` int(11) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `zone` varchar(256) DEFAULT NULL,
  `isp`  varchar(16) DEFAULT NULL,
  `prvn` varchar(8) DEFAULT NULL,
  `city` varchar(8) DEFAULT NULL,
  `stuckinfo` text,
  PRIMARY KEY (`id`),
  KEY `ip_id` (`ip`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for aem_pumainfo
-- ----------------------------
DROP TABLE IF EXISTS `aem_pumainfo`;
CREATE TABLE `aem_pumainfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) NOT NULL,
  `actime` varchar(64) DEFAULT NULL,
  `ver` varchar(64) DEFAULT NULL,
  `plat` int(11) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `zone` varchar(256) DEFAULT NULL,
  `isp`  varchar(16) DEFAULT NULL,
  `prvn` varchar(8) DEFAULT NULL,
  `city` varchar(8) DEFAULT NULL,
  `stuckinfo` text,
  PRIMARY KEY (`id`),
  KEY `ip_id` (`ip`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for aem_hcdninfo
-- ----------------------------
DROP TABLE IF EXISTS `aem_hcdninfo`;
CREATE TABLE `aem_hcdninfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) NOT NULL,
  `actime` varchar(64) DEFAULT NULL,
  `ver` varchar(64) DEFAULT NULL,
  `plat` int(11) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `zone` varchar(256) DEFAULT NULL,
  `isp`  varchar(16) DEFAULT NULL,
  `prvn` varchar(8) DEFAULT NULL,
  `city` varchar(8) DEFAULT NULL,
  `stuckinfo` text,
  PRIMARY KEY (`id`)
  KEY `ip_id` (`ip`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for aem_pingback
-- ----------------------------
DROP TABLE IF EXISTS `aem_pingback`;
CREATE TABLE `aem_pingback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) NOT NULL,
  `actime` varchar(64) DEFAULT NULL,
  `ver` varchar(128) DEFAULT NULL,
  `plat` int(11) DEFAULT NULL,
  `pbtype` int(11) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `zone` varchar(256) DEFAULT NULL,
  `isp`  varchar(16) DEFAULT NULL,
  `prvn` varchar(8) DEFAULT NULL,
  `city` varchar(8) DEFAULT NULL,
  `pingback` text,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ------------------------------
-- Table structure for aem_probe
-- ------------------------------
DROP TABLE IF EXISTS `aem_probe`;
CREATE TABLE `aem_probe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL,
  `policy` varchar(128) DEFAULT NULL,
  `period` varchar(64) DEFAULT NULL,
  `reqs` int(5) unsigned NOT NULL,
  `gap` int(5) unsigned NOT NULL,
  `dlurl` varchar(512) DEFAULT NULL,
  `cmd` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

