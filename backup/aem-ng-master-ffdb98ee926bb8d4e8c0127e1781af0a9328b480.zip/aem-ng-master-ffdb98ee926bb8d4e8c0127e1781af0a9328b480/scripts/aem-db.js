
conn = new Mongo();
db = conn.getDB("netdoctor");
// db.auth()

db.aem_ndctinfo.drop();
db.createCollection("aem_ndctinfo");
db.aem_ndctinfo.createIndex({"uid": 1});
db.aem_ndctinfo.createIndex({"ip": 1});
db.aem_ndctinfo.createIndex({"isp": 1});
db.aem_ndctinfo.createIndex({"prvn": 1, "city": 1});

db.createCollection("aem_pumainfo");
db.aem_pumainfo.createIndex({"uid": 1});
db.aem_pumainfo.createIndex({"ip": 1});
db.aem_pumainfo.createIndex({"isp": 1});
db.aem_pumainfo.createIndex({"prvn": 1, "city": 1});

db.createCollection("aem_hcdninfo");
db.aem_hcdninfo.createIndex({"uid": 1});
db.aem_hcdninfo.createIndex({"ip": 1});
db.aem_hcdninfo.createIndex({"isp": 1});
db.aem_hcdninfo.createIndex({"prvn": 1, "city": 1});

db.createCollection("aem_pingback");
db.aem_pingback.createIndex({"uid": 1});
db.aem_pingback.createIndex({"ip": 1});
db.aem_pingback.createIndex({"isp": 1});
db.aem_pingback.createIndex({"prvn": 1, "city": 1});

db.getSiblingDB("admin");
db.runCommand({"enablesharding": "netdoctor"});
db.runCommand({"shardcollection": "netdoctor.aem_ndctinfo", "key": {"actime": 1, "_id": 1}});
db.runCommand({"shardcollection": "netdoctor.aem_pumainfo", "key": {"actime": 1, "_id": 1}});
db.runCommand({"shardcollection": "netdoctor.aem_hcdninfo", "key": {"actime": 1, "_id": 1}});
db.runCommand({"shardcollection": "netdoctor.aem_pingback", "key": {"actime": 1, "_id": 1}});

