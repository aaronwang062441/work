#!/usr/bin/env lua

WRK = 'wrk'

function getopt(arg, optstr)
    local err = nil
    local opts = {}
    local args = {}

    local options = {}
    for ch, ac in string.gmatch(optstr, "(%w)(:?)") do
        options[ch] = #ac
    end

    local i = 1
    while i <= #arg do
        if string.sub(arg[i], 1, 1) == '-' then
            local val = arg[i]
            local j = 2
            while j <= #val do
                local opt = string.sub(val, j, j)
                if not options[opt] then
                    err = "invalid option: "..val
                    return nil, nil, err
                end
                if options[opt] > 0 then
                    if j < #val then
                        opts[opt] = string.sub(val, j+1)
                        j = #val
                    elseif i < #arg then
                        opts[opt] = arg[i + 1]
                        i = i + 1
                    else
                        err = "missing arguments: "..val
                        return nil, nil, err
                    end
                elseif options[opt] == 0 then
                    opts[opt] = true
                else
                    err = "unknown option: "..val
                    return nil, nil, err
                end
                j = j + 1
            end
        else
            table.insert(args, arg[i])
        end
        i = i + 1
    end
    return opts, args, err
end

function warn(msg)
    print(string.char(27)..'[31m'..tostring(msg)..string.char(27)..'[0m')
end

function info(msg)
    print(string.char(27)..'[32m'..tostring(msg)..string.char(27)..'[0m')
end

function join(...)
    local vars = {}
    for _, v in ipairs{...} do
        table.insert(vars, v)
    end
    return table.concat(vars, '/')
end

function split(str, sep)
    local str = str..sep
    local ptn = "([^"..sep.."]+)"..sep
    return string.gmatch(str, ptn)
end

function urljoin()
end

function urlsplit()
end

function exists(fpath)
    if type(fpath) ~= 'string' then
        return false
    end
    return os.rename(fpath, fpath) or false
end

function which(proc)
    local path = os.getenv("PATH")
    for p in split(path, ':') do
        if exists(join(p, proc)) then
            return true
        end
    end
    return false
end

function escape(str)
    return string.gsub(str, '&', '\\&')
end

function exec(cmd)
    if type(arg) == 'table' then
        cmd = table.concat(cmd, ' ')
    end
    local file = assert(io.popen(escape(cmd)..' 2>&1', 'r'))
    local out = file:read('*all')
    local ret = file:close()
    return ret, out
end

function exec2(cmd)
    if type(cmd) == 'table' then
        cmd = table.concat(cmd, ' ')
    end
    local tmp = os.tmpname()
    local ret = os.execute(cmd..' 1>'..tmp..' '..'2>'..tmp)
    -- FIXME: need to sleep serveral seconds until finished
    local file = assert(io.open(tmp, 'r'))
    local out = file:read('*all')
    file:close()
    os.remove(tmp)
    return ret == 0, out
end

function wrk(opts, args)
    if not which(WRK) then
        warn("please install "..WRK.." first...")
        return
    end
    local cmd = {WRK}
    if opts.c then
        table.insert(cmd, '-c'..opts.c)
    end
    if opts.d then
        table.insert(cmd, '-d'..opts.d)
    end
    if opts.t then
        table.insert(cmd, '-t'..opts.t)
    end
    if opts.s then
        table.insert(cmd, '-s post.lua')
    end
    if #args > 0 then
        table.insert(cmd, args[1])
    end
    local ret, out = exec(cmd)
    if ret then
        info(out)
    else
        warn(out)
    end
end

function usage(proc)
    print([[
Usage: ]]..tostring(proc)..[[ <options> <url>
  Options:
    -h,       Display this help message
    -c,  <N>  Connections to keep open
    -d,  <T>  Duration of test
    -t,  <N>  Number of threads to use
    -n,  <N>  Times to repeat
    -s,       Use Lua script file post.lua

  Numeric arguments may include a SI unit (1k, 1M, 1G)
  Time arguments may include a time unit (2s, 2m, 2h)
    ]])
end

function main()
    local opts, args, err = getopt(arg, "c:d:t:n:sh")
    if not opts or err then
        warn(err or "unknown error")
        usage(arg[0])
    elseif opts.h then
        usage(arg[0])
    elseif #args == 0 then
        usage(arg[0])
    elseif #args > 1 then
        warn("missing arguments")
        usage(arg[0])
    else
        for i = 1, opts.n do
            wrk(opts, args)
        end
    end
end

do
    main(arg)
end
