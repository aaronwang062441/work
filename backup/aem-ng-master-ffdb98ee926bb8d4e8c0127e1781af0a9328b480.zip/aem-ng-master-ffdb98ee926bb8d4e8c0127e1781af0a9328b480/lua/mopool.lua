--------------------------------------------------------------------------------
-- Connection pool for mongo database
-- Description: a connection pool wrapper module for simply accessing mongo database
-- @module mopool
-- @author Chen Gui <chengui@qiyi.com>
-- @license @see LICENSE
-- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local mongo = require("resty.mongol")
local objid = require("resty.mongol.object_id")

local setmetatable = setmetatable
local tostring = tostring

-- module table and metatble
local _M = {_VERSION = '0.01'}
local mt = {__index = _M}

function _M.connect(self)
    local conn = mongo:new()
    if not conn then
        return nil, "failed to create mongo instance"
    end

    conn:set_timeout(self.socket_timeout)
    local ok, err = conn:connect(self.host, self.port)
    if not ok then
        return nil, "failed to connect mongo database"
    end
    return conn, nil
end

function _M.newdb(self, conn)
    local db = conn:new_db_handle(self.database)
    if not db then
        return nil, "failed to get mongo database handle"
    end

    -- local ok, err = db:auth(self.user, self.password)
    -- if not ok then
    --     return false, "failed to authenicate mongo"
    -- end

    return db, nil
end

function _M.set_keepalive(self, conn)
    return conn:set_keepalive(self.keepalive_timeout, self.keepalive_poolsize)
end

function _M.find_one(self, collect, query, returnfields)
    local conn, err = self:connect()
    if not conn then
        return nil, err
    end

    local db, err = self:newdb(conn)
    if not db then
        return nil, err
    end

    local col = db:get_col(collect)
    if not col then
        return nil, "failed to get collection '"..self.database.."."..(collect or "nil").."'"
    end

    local res = col:find_one(query, returnfields)
    if not res then
        return nil, "failed to query, "..(query or "nil")..", "..(returnfields or "nil")
    end

    res['id'] = tostring(res['_id'])
    res['_id'] = nil
    return res, nil
end

function _M.find(self, collect, query, returnfields, num_each_query)
    local conn, err = self:connect()
    if not conn then
        return nil, err
    end

    local db, err = self:newdb(conn)
    if not db then
        return nil, err
    end

    local col = db:get_col(collect)
    if not col then
        return nil, "failed to get collection '"..self.database.."."..(collect or "nil").."'"
    end

    local cursor = col:find(query, returnfields, num_each_query)
    if not cursor then
        return nil, "failed to query, "..(query or "nil")..", "..(returnfields or "nil")
    end

    local res = {}
    for k, v in cursor:pairs() do
         if v['_id'] then
             v['id'] = tostring(v['_id'])
             v['_id'] = nil
         end
         res[k] = v
    end

    return res, nil
end

function _M.insert(self, collect, docs)
    if not next(docs) then
        return nil, "empty docs"
    end

    if #docs == 0 then
        docs = {docs}
    end

    local conn, err = self:connect()
    if not conn then
        return nil, err
    end

    local db, err = self:newdb(conn)
    if not db then
        return nil, err
    end

    local col = db:get_col(collect)
    if not col then
        return nil, "failed to get collection '"..self.database.."."..(collect or "nil").."'"
    end

    local n, err = col:insert(docs, nil, true)
    self:set_keepalive(conn)
    if not n or n ~= 0 then
        return nil, "failed to insert into '"..self.database.."."..(collect or "nil").."', "..(err or "nil")
    end

    return n, nil
end

function _M.update(self, collect, selector, updator)
    local conn, err = self:connect()
    if not conn then
        return nil, err
    end

    local db, err = self:newdb(conn)
    if not db then
        return nil, err
    end

    local col = db:get_col(collect)
    if not col then
        return nil, "failed to get collection '"..self.database.."."..(collect or "nil").."'"
    end

    local n, err = col:update(selector, updator, nil, nil, true)
    if not n then
        return nil, "failed to update '"..self.databases.."."..(collect or "nil").."', "..(err or "nil")
    end

    return n, nil
end

function _M.delete(self, collect, selector)
    local conn, err = self:connect()
    if not conn then
        return nil, err
    end

    local db, err = self:newdb(conn)
    if not db then
        return nil, err
    end

    local col = db:get_col(collect)
    if not col then
        return nil, "failed to get collection '"..self.database.."."..(collect or "nil").."'"
    end

    local n, err = col:delete(selector)
    if not n then
        return nil, "failed to update '"..self.databases.."."..(collect or "nil").."', "..(err or "nil")
    end

    return n, nil
end

function _M.new(self, opts)
    opts = opts or {}
    local self_dict = {
        host = opts.host or "127.0.0.1",
        port = opts.port or 27017,
        user = opts.user or "root",
        password = opts.password or "",
        database = opts.database or "ndct",

        socket_timeout = opts.socket_timeout or 2000,
        keepalive_timeout = opts.keepalive_timeout or 10000,
        keepalive_poolsize = opts.keepalive_poolsize or 1000,
    }
    return setmetatable(self_dict, mt)
end

_M.objid = objid

return _M
