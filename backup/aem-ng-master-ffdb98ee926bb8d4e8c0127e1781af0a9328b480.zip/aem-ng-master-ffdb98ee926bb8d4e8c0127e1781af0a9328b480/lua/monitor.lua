--------------------------------------------------------------------------------
---- Monitor utilities
---- Description: utility routines for monitoring gateway status
---- @module monitor
---- @author Chen Gui <chengui@qiyi.com>
---- @author Wang Minghui <wangminghui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local io_open = io.open
local os_execute = os.execute
local t_concat = table.concat
local s_gfind = string.gfind
local s_match = string.match
local s_find = string.find
local m_ceil = math.ceil

local tonumber = tonumber
local ipairs = ipairs
local pairs = pairs

local _M = {_VERSION = '0.02'}

---- Sleep microseconds by using 'usleep' command
-- @param useconds: microseconds to sleep
-- @return: nil
local function usleep(useconds)
    useconds = useconds or 1000
    os_execute('usleep '..tonumber(useconds))
end

---- Calculate memory usage status
-- Equation: used = total - free - buffers - cached
-- @return table: include total/used, use megabytes as unit
local function mem_status()
    local total = 0
    local used = 0
    local file = io_open('/proc/meminfo', 'r')
    for line in file:lines() do
        local key, val = s_match(line, '(%a+):%s*(%d+)%s*kB')
        if not key then
            --
        elseif key == 'MemTotal' then
            total = val
        elseif key == 'MemFree' then
            used = total - val
        elseif key == 'Buffers' or key == 'Cached' then
            used = used - val
        end
    end

    -- convert kilobytes to megabytes
    local ret = {
        total = total,
        used = used,
    }

    return ret
end

---- Count cpu processors
-- @return int: number of cpu processors
local function cpu_count()
    local file = io_open('/proc/cpuinfo', 'r')
    local content = file:read('*a')
    file:close()
    local cnt = 0
    for s in s_gfind(content, "processor%s*:%s*%d+") do
        cnt = cnt + 1
    end
    return cnt
end

---- Calculate cpu usage status and cpu amount
-- Equation: (idle2 - idle1) / (total2 - total1)
-- @param delay: delay microseconds to calculate
-- @return int: ceil value of cpu usage
local function cpu_status(delay)
    delay = delay or 200000

    local file = io_open('/proc/stat', 'r')
    local content = file:read('*a')
    file:close()
    local pattern = "cpu%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)"
    local _, _, _1, _2, _3, idle1, _5, _6, _7, _8, _9 = s_find(content, pattern)
    local total1 = _1 + _2 + _3 + idle1 + _5 + _6 + _7 + _8 + _9

    usleep(delay)

    local file = io_open('/proc/stat', 'r')
    local content = file:read('*a')
    file:close()
    local pattern = "cpu%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)"
    local _, _, _1, _2, _3, idle2, _5, _6, _7, _8, _9 = s_find(content, pattern)
    local total2 = _1 + _2 + _3 + idle2 + _5 + _6 + _7 + _8 + _9

    local rate_cpu = 0
    if total1 ~= total2 then
        rate_cpu = m_ceil(100 - 100 * (idle2 - idle1) / (total2 - total1))
    end

    local ret = {
        percentage = rate_cpu,
        processors = cpu_count(),
    }
    return ret
end

---- Calculate network usage status
-- Equation: ([received|transmited|traffic]2 - [received|transmited|traffic]1) / time
-- @param delay: delay microseconds to calculate
-- @return int: ceil value of net usage
local function net_status(delay)
    delay = delay or 500000

    local file = io_open('/proc/net/dev', 'r')
    local content = file:read('*a')
    file:close()
    local pattern = "eth0:%s*(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)"
    local _, _, recv1, _, _, _, _, _, _, _, transmit1 = s_find(content, pattern)
    local total1 = recv1 + transmit1

    usleep(delay)

    local file = io_open('/proc/net/dev', 'r')
    local content = file:read('*a')
    file:close()
    local pattern = "eth0:%s*(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)%s+(%d+)"
    local _, _, recv2, _, _, _, _, _, _, _, transmit2 = s_find(content, pattern)
    local total2 = recv2 + transmit2

    -- convert microseconds to useconds
    delay = delay / 1000000
    local ret = {
        received = recv2,
        transmited = transmit2,
        rate_received = m_ceil((recv2 - recv1) / delay),
        rate_transmited = m_ceil((transmit2 - transmit1) / delay),
        rate_traffic = m_ceil((total2 - total1) / delay),
    }

    return ret
end

---- Calculate uptime info
-- @return table: uptime - server running time, rate_idle - rate of idling
local function uptime()
    local file = io_open('/proc/uptime', 'r')
    local content = file:read('*a')
    file:close()
    local pattern = "([0-9.]+)%s+([0-9.]+)"
    local _, _, _1, _2 = s_find(content, pattern)

    local ret = {
        uptime = _1,
        rate_idle = _2 / (_1 * cpu_count()),
    }
    return ret
end

---- Calculate load average status
-- Equation: read from loadavg file
-- @return table: includes avg value in the past 1, 5 and 15 minutes
local function load_average()
    local file = io_open('/proc/loadavg', 'r')
    local content = file:read('*a')
    file:close()
    local pattern = "([0-9.]+)%s+([0-9.]+)%s+([0-9.]+)%s+(%d+)/(%d+)%s+(%d+)"
    local _, _, _1, _2, _3, _4, _5, _6 = s_find(content, pattern)

    local ret = {
        one = _1 or 0,
        five = _2 or 0,
        fifteen = _3 or 0,
        running_process = _4 or 0,
        total_process = _5 or 0,
    }
    return ret
end

-- TODO: Calculate self process memory usage
local function self_mem()
end

-- TODO: Calculate self process cpu usage
local function self_cpu()
end

---- Form cpu status table
-- @return table: cpu usage, use cpu:percentage as key
function _M.cpu()
    local ret = {}
    local usage = cpu_status()
    ret[_M.key({'cpu', 'percentage'})] = usage.percentage
    ret[_M.key({'cpu', 'processors'})] = usage.processors
    return ret
end

---- Form memory status table
-- @return table: mem usage, use mem:total, mem:used, mem:percentage as key
function _M.memory()
    local ret = {}
    local usage = mem_status()
    ret[_M.key({'mem', 'total'})] = usage.total
    ret[_M.key({'mem', 'used'})] = usage.used
    ret[_M.key({'mem', 'percentage'})] = m_ceil(100 * usage.used / usage.total)
    return ret
end

---- Form network status table
-- @return table: network usage, use net:percentage as key
function _M.network()
    local ret = {}
    local usage = net_status()
    ret[_M.key({'net', 'received'})] = usage.received
    ret[_M.key({'net', 'transmited'})] = usage.transmited
    ret[_M.key({'net', 'rate', 'received'})] = usage.rate_received
    ret[_M.key({'net', 'rate', 'transmited'})] = usage.rate_transmited
    ret[_M.key({'net', 'rate', 'traffic'})] = usage.rate_traffic
    return ret
end

---- Form load average status table
-- @return table: loadavg value in one, five, and fifteen minutes
function _M.loadavg()
    local ret = {}
    local load_avg = load_average()
    ret[_M.key({'load', 'rate', '1min'})] = load_avg.one
    ret[_M.key({'load', 'rate', '5min'})] = load_avg.five
    ret[_M.key({'load', 'rate', '15min'})] = load_avg.fifteen
    ret[_M.key({'load', 'process', 'running'})] = load_avg.running_process
    ret[_M.key({'load', 'process', 'total'})] = load_avg.total_process
    local load_uptime = uptime()
    ret[_M.key({'load', 'uptime'})] = load_uptime.uptime
    ret[_M.key({'load', 'rate', 'idle'})] = load_uptime.rate_idle
    return ret
end

---- Generate table key with group and keys
-- @param key_table: a given table with group (first value in table) and keys
-- @return string: generic key used in monitor module
function _M.key(key_table)
    return t_concat(key_table, ':')
end

---- Increase specified key by count
-- @param dict: shared dict to add the new value
-- @param key: key to increase
-- @param count: the extent to increase
-- @return string: new value after updated for key
function _M.incr(dict, key, count)
    local newval, err = dict:incr(key, count)
    if err then
        dict:set(key, count)
        newval = count
    end
    return newval
end

---- Empty specified dict
-- @param dict: shared dict to be flushed
-- @return: nil
function _M.empty(dict)
    dict:flush_all()
    dict:flush_expired()
end

---- Get monitoring status by specified group
-- @param dict: shared dict from nginx
-- @param grp: group to find, such as "get_cmd"
-- @return table/int: values of specified group, 0 by default
function _M.get_group(dict, grp)
    local response = {}
    if grp then
        for idx, key in pairs(dict:get_keys()) do
            if s_find(key, grp) ~= nil then
                response[key] = dict:get(key)
            end
        end
    end
    return response or 0
end

---- Fetch monitoring status for specified group
-- @param dict: shared dict from nginx
-- @param grp: define as first part in monitor key separated by ':'
-- @return table: values of specified group
function _M.status(dict, grp)
    local response = {}
    if not grp then
        --
    elseif grp == "all" then
        for idx, key in pairs(dict:get_keys()) do
            response[key] = dict:get(key)
        end
        local usage_cpu = _M.cpu()
        for key, val in pairs(usage_cpu) do
            response[key] = val
        end
        local usage_mem = _M.memory()
        for key, val in pairs(usage_mem) do
            response[key] = val
        end
        local usage_net = _M.network()
        for key, val in pairs(usage_net) do
            response[key] = val
        end
        local load_avg = _M.loadavg()
        for key, val in pairs(load_avg) do
            response[key] = val
        end
    elseif grp == "req" then
        for idx, key in pairs(dict:get_keys()) do
            response[key] = dict:get(key)
        end
    elseif grp == "cpu" then
        local usage_cpu = _M.cpu()
        for key, val in pairs(usage_cpu) do
            response[key] = val
        end
    elseif grp == "mem" then
        local usage_mem = _M.memory()
        for key, val in pairs(usage_mem) do
            response[key] = val
        end
    elseif grp == "net" then
        local usage_net = _M.network()
        for key, val in pairs(usage_net) do
            response[key] = val
        end
    elseif grp == "load" then
        local load_avg = _M.loadavg()
        for key, val in pairs(load_avg) do
            response[key] = val
        end
    else
        response = _M.get_group(dict, grp)
    end
    return response
end

---- Get request times by specified key
-- @param dict: shared dict from nginx
-- @param key: key to fetch
-- @return table: value of specified key, 0 by default
function _M.get_key(dict, key)
    local response = {}
    if key == "all" then
        for idx, key in pairs(dict:get_keys()) do
            response[key] = dict:get(key)
        end
    else
        response[key] = dict:get(key) or 0
    end
    return response
end

---- Update specified key to a given value
-- @param dict: shared dict from nginx
-- @param key: key to update
-- @param value: value to update
-- @return: set value to key
function _M.update(dict, key, value)
    dict:set(key, value)
end

---- Category http status code by prefix integer
-- @param status: http code status
-- @return string: category for status, by first number in status digits
function _M.get_status_code(status)
    if not status then
        return "xxx"
    elseif status:sub(1, 1) == '1' then
        return "1xx"
    elseif status:sub(1, 1) == '2' then
        return "2xx"
    elseif status:sub(1, 1) == '3' then
        return "3xx"
    elseif status:sub(1, 1) == '4' then
        return "4xx"
    elseif status:sub(1, 1) == '5' then
        return "5xx"
    else
        return "xxx"
    end
end

return _M
