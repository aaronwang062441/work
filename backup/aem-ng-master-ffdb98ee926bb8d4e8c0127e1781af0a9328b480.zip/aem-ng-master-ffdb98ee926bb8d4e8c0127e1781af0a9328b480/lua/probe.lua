--------------------------------------------------------------------------------
-- Probe api wrapper to manage commands
-- Description: Manage probe queue and hash table by
--   providing redis wrapper api. queue:<index> indicates
--   running queue with dispatch time as queue priority,
--   and mhash presents a hash table to store all
--   static commands
-- @module probe
-- @author Chen Gui <chengui@qiyi.com>
-- @license @see LICENSE
-- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local cjson = require("cjson")
local rdpool = require("rdpool")

local setmetatable = setmetatable
local tostring = tostring
local tonumber = tonumber
local string = string
local ipairs = ipairs
local pairs = pairs
local pcall = pcall
local type = type
local os = os
local is_exiting = ngx.worker.exiting
local worker_count = ngx.worker.count
local worker_pid = ngx.worker.pid
local timer_at = ngx.timer.at
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR

local ok, new_tab = pcall(require, "new_tab")
if not ok or type(new_tab) ~= "function" then
    new_tab = function (narr, nrec) return {} end
end

local _M = {_VERSION='0.02'}
local mt = {__index = _M}

local _instance

local pcolumns = {
    ['id']     = 'int',
    ['type']   = 'int',
    ['policy'] = 'table',
    ['period'] = 'table',
    ['reqs']   = 'int',
    ['gap']    = 'int',
    ['dlurl']  = 'string',
    ['cmd']    = 'table',
    ['cnt']    = 'int',
}

---- Return default value
-- @param typ: data type
-- @return value: default assigning value
local function default(typ)
    local defvals = {
        ['int']    = 0,
        ['string'] = "",
        ['table']  = {},
    }
    return defvals[typ]
end

---- Get recent probes pool, simple style
-- @param self: module table
-- @return table: array of (id: priority)
function _M.top(self)
    return self.queue
end

---- Increase running score to reduce priority
-- @param self: module table
-- @param idx: probe index in queue
-- @param iscore: score to be increased
function _M.incr(self, idx, iscore)
    self.queue_add[idx] = iscore
    self.queue_cnt = self.queue_cnt - 1
    self.queue[idx] = nil
end

---- Push probe back to running queue to reduce priority
-- @param self: module table
-- @param idx: probe index in queue
-- @param score: score to be set prioirty
function _M.push(self, idx, score)
    self.queue_add[idx] = score
    self.queue_cnt = self.queue_cnt - 1
    self.queue[idx] = nil
end

---- Pop probe up from running queue to remove it
-- @param self: module table
-- @param idx: probe index in queue
function _M.pop(self, idx)
    self.queue_del[idx] = self.queue[idx]
    self.queue_cnt = self.queue_cnt - 1
    self.queue[idx] = nil
end

---- Increase running count of probe, if count greater than
---- the given value, it should be reduced priority
-- @param self: module table
-- @param idx: probe index in hash
-- @param cnt: increase count, default is 1
function _M.incritem(self, idx, cnt)
    self.mhash[idx]['cnt'] = self.mhash[idx]['cnt'] + 1
end

---- Clear/reset running count of probe to 0
-- @param self: module table
-- @param idx: probe index in hash
function _M.clritem(self, idx)
    self.mhash[idx]['cnt'] = 0
end

---- Get probe in hash table by the given index
-- @param self: module table
-- @param idx: probe index in hash
-- @return table: probe result, nil if not existed
function _M.getitem(self, idx)
    return self.mhash[idx]
end

---- Set probe in hash table with (key, val)
-- @param self: module table
-- @param idx: probe index in hash
-- @param probe: table with key-value pairs to be set
-- @return boolean, error: exist or not, error if nil
function _M.setitem(self, idx, probe)
    self.mhash[idx] = self.mhash[idx] or {}
    for col, typ in pairs(pcolumns) do
        self.mhash[idx][key] = probe[key] or default(typ)
    end
end

---- Delete probe in hash table
-- @param self: module table
-- @param idx: probe index in hash
function _M.delitem(self, idx)
    self:pop(idx)
    self.mhash[idx] = nil
end

---- Refresh status of queue and hash to load from database
-- @param self: module table
-- @param docs: probe result loaded from database
function _M.refresh(self, docs)
    self.mhash = {}
    local ok, err = self.redis:del(self.rdqueue)
    if not ok or err then
        ngx_log(ngx_ERR, "redis delete key err: ", err)
    end
    local workercount = worker_count()
    local timecount = tonumber(string.sub(self.rdqueue, 7)) or 0
    timecount = timecount % workercount
    self.redis:init_pipeline()
    for idx=1, #(docs) do
        idx = 1 + (idx + timecount) % #(docs)
        local val = docs[idx]
        self.mhash[val['id']] = val
        self.mhash[val['id']]['cnt'] = 0
        self.mhash[val['id']]['gap'] = val['gap']
        self.redis:zadd(self.rdqueue, os.time() + timecount, val['id'])
    end
    local res, err = self.redis:commit_pipeline()
    if not res then
        ngx_log(ngx_ERR, "redis commit_pipeline err: ", err)
    end
end

---- Lock for reloading probes
local function _reload_lock(self)
    if not self.reloading then
        self.reloading = true
        return true
    end
    return false
end

---- Unlock for reloading probes
local function _reload_unlock(self)
    self.reloading = false
end

local _reload_queue

---- Reload probes from redis prioirty queue after updating running queue status to redis
-- @param premature: premature
-- @param self: module table
local function _reload(premature, self)
    -- The previous reload did not finish
    if not _reload_lock(self) then
        return
    end

    if self.queue_cnt > 0 then
        _reload_unlock(self)
        return
    end

    -- Update running queue status to redis
    -- self.redis:init_pipeline()
    for idx, score in pairs(self.queue_add) do
        self.redis:zincrby(self.rdqueue, score, idx)
    end
    self.queue_add = {}
    for idx, score in pairs(self.queue_del) do
        self.redis:zrem(self.rdqueue, idx)
    end
    self.queue_del = {}
    -- local res, err = self.redis:commit_pipeline()

    -- Reload running queue from redis priority queue
    local res, err = self.redis:zrangebyscore(self.rdqueue, 0, os.time(), "WITHSCORES", "LIMIT", 0, self.rdlimit)
    if res then
        for k = 1, #res, 2 do
            self.queue[res[k]] = tonumber(res[k+1]) or os.time()
        end
        self.queue_cnt = #res / 2
    elseif err then
        ngx_log(ngx_ERR, "redis zrangebyscore err: ", err)
    end

    _reload_unlock(self)
end

---- Post reload task to asynchronous operation
-- @param self: module table
_reload_queue = function (self)
    local ok, err = timer_at(0, _reload, self)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer at _reload_queue, err: ", err)
    end
end

---- Setup timer for refreshing running queue in every 'time' seconds
-- @param premature: premature
-- @param self: module table
-- @param interval: timer interval
local _timer_reload
_timer_reload = function (premature, self, time)

    _reload_queue(self)

    if premature then
        return
    end

    local ok, err = timer_at(time, _timer_reload, self, time)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer at _timer_reload, err: ", err)
    end
end

---- Initialize probe module
-- @param self: module table
-- @param opts: options to be set
-- @return metatable
function _M.new(self, opts)
    opts = opts or {}
    if _instance then
        return _instance
    end

    local rdopts = opts.rdopts or {
        host = '127.0.0.1',
        port = 6379,
        user = 'netdoctor',
        password = '',
        dbindex  = 0,
    }
    local redis = rdpool.new(rdopts)
    local rdlimit = opts.pbopts and opts.pbopts.limit or 5
    local rdqueue = opts.pbopts and opts.pbopts.queue or 'queue:'..worker_pid()
    _instance = setmetatable({
        rdqueue = rdqueue,
        rdlimit = rdlimit,
        redis = redis,
        queue_cnt = 0,
        queue_del = {},
        queue_add = {},
        queue = {},
        mhash = {},
    }, mt)

    _timer_reload(nil, _instance, (opts.reload_time or 1000)/1000)

    return _instance
end

return _M
