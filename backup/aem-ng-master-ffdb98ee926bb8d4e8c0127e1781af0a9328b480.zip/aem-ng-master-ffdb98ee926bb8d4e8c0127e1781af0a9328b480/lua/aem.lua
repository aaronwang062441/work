--------------------------------------------------------------------------------
---- Gateway routines and router
---- Description: Collect users' stuckinfo and dispatch probes to users
---- @module aem
---- @author Chen Gui <chengui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local producer = require("resty.kafka.producer")
local cjson    = require("cjson")
local config   = require("config")
local iputil   = require("iputil")
local storage  = require("storage")
local dispatch = require("dispatch")
local monitor  = require("monitor")
local guard    = require("guard")

local tostring = tostring
local tonumber = tonumber
local string = string
local table = table
local pcall = pcall
local pairs = pairs
local type = type
local os = os
local ngx_HTTP_SERVICE_UNAVAILABLE = ngx.HTTP_SERVICE_UNAVAILABLE
local ngx_HTTP_NOT_ALLOWED = ngx.HTTP_NOT_ALLOWED
local ngx_HTTP_NOT_FOUND = ngx.HTTP_NOT_FOUND
local ngx_HTTP_OK = ngx.HTTP_OK
local ngx_match = ngx.re.match
local ngx_header = ngx.header
local ngx_print = ngx.print
local ngx_exit = ngx.exit
local ngx_req = ngx.req
local ngx_var = ngx.var
local ngx_say = ngx.say
local ngx_eof = ngx.eof
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR
local stats = ngx.shared.stat_dict
local guards = ngx.shared.guard_dict

local conf = config:new()
local iplib = iputil:new(conf.iplib)

---- Alias of os.date
-- @return : current time
local function datetime()
    return os.date("%Y-%m-%d %H:%M:%S", os.time())
end

---- Get ip address of client
-- @return : ip address
local function clientip()
    local ip = ngx_req.get_headers()["X-Real-IP"]
    if ip == nil then
        ip = ngx_req.get_headers()["x_forwarded_for"]
    end
    if ip == nil then
        ip = ngx_var.remote_addr
    end
    return ip
end

---- Prevent cc (Challenge Collapsar) attack, means less than 100 reqs in 5 min by default
-- @return : true if condition satisfied
local function shield(args)
    local opts = {
        dict = guards,
    }
    local guard = guard:new(opts)
    if guard:limit_req(args["uid"]) then
        return true
    end
    return false
end

---- Send messge to Kafka
-- @param topic: kafka topic
-- @param key: kafka partition key
-- @param message: message to be sent
-- @return int, error: offset of message, nil if error
local function kfksend(topic, key, message)
    if not conf.kafka or not conf.kafka.enabled then
        return true
    end

    local broker_list = conf.kafka.hosts or {{host="127.0.0.1", port=9092}}
    local p = producer:new(broker_list, {producer_type="async"})
    if not p then
        return nil, "failed to create kafka producer"
    end
    return p:send(topic, key, message)
end

---- Save into database
-- @param collect:
-- @param args:
-- @param columns:
local function dbsave(collect, args)
    if not conf.database or not conf.database.enabled then
        return true
    end

    local opts = {
        mongo = conf.database.mongo,
        mysql = conf.database.mysql,
        compat = true,
    }
    local s = storage:new(opts)
    if not s then
        return nil, "failed to create storage"
    end
    return s:save(collect, args)
end

---- Collect NetDoctor-SDK stuckinfo, send it to kafka, and store to database
-- @return
local function send_stuck_info(match)
    -- Validate all arguments
    local ngx_args = ngx_req.get_uri_args()
    if ngx_args["uid"] == nil or not ngx_match(ngx_args["uid"], "^[A-Za-z0-9_. ]+$", "oj") then
        return
    end
    if ngx_args["plat"] == nil or not ngx_match(ngx_args["plat"], "^[0-9_]+$", "oj") then
        return
    end
    if ngx_args["ver"] == nil or not ngx_match(ngx_args["ver"], "^[0-9.]+$", "oj") then
        return
    end
    if shield(ngx_args) == true then
        return ngx_HTTP_SERVICE_UNAVAILABLE
    end
    monitor.incr(stats, monitor.key({match, 'request', 'valid'}), 1)

    -- Get ip address of remote client
    local ip = ngx_var.remote_addr

    -- Read http PUT data
    ngx_req.read_body()
    local body = ngx_req.get_body_data()

    -- Close remote socket stream to save user response time
    ngx_header['Content-Length'] = "0"
    ngx_say(ngx_HTTP_OK)
    ngx_eof()

    -- Fetch geo info by specified ip
    local ok, geo, err = iplib:ip_zones_find(ip)
    if not ok then
        ngx_log(ngx_ERR, "failed to get geo info: ", err)
    end

    local args = {
        ['uid']       = ngx_args.uid,
        ['actime']    = datetime(),
        ['ver']       = ngx_args.ver,
        ['plat']      = ngx_args.plat,
        ['ip']        = ip,
        ['zone']      = geo[2].."-"..geo[3].."-"..geo[1],
        ['isp']       = geo[1],
        ['prvn']      = geo[2],
        ['city']      = geo[3],
        ['stuckinfo'] = body or '{}',
    }
    local collect = "aem_ndctinfo"

    -- Send message to kafka brokers
    local message = cjson.encode(args)
    local ok, err = kfksend(collect, nil, message)
    if not ok then
        ngx_log(ngx_ERR, "failed to send message: ", err)
    end

    -- Insert stuck info to database
    local ok, err = dbsave(collect, args)
    if not ok then
        ngx_log(ngx_ERR, "failed to insert into database", err)
    end
end

---- Collect Puma-SDK stuckinfo, send it to kafka, and store to database
-- @return
local function send_puma_info(match)
    return ngx_HTTP_OK
end

---- Collect HCDN-SDK stuckinfo, send it to kafka, and store to database
-- @return
local function send_hcdn_info(match)
    return ngx_HTTP_OK
end

---- Collect PUMA/HCDN scene info, send it to kafka, and store to database
-- @return
local function send_scene_info(match)
    -- Validate all arguments
    local ngx_args = ngx_req.get_uri_args()
    if ngx_args["uid"] == nil or not ngx_match(ngx_args["uid"], "^[A-Za-z0-9_. ]+$", "oj") then
        return
    end
    if ngx_args["plat"] == nil or not ngx_match(ngx_args["plat"], "^[0-9_]+$", "oj") then
        return
    end
    if ngx_args["ver"] == nil or not ngx_match(ngx_args["ver"], "^[0-9.]+$", "oj") then
        return
    end
    if ngx_args["from"] == nil or not ngx_match(ngx_args["from"], "^[a-z]+$", "oj") then
        return
    end
    if ngx_args["timestamp"] == nil or not ngx_match(ngx_args["timestamp"], "^[0-9]+$", "oj") then
        return
    end
    if shield(ngx_args) == true then
        return ngx_HTTP_SERVICE_UNAVAILABLE
    end
    monitor.incr(stats, monitor.key({match, 'request', 'valid'}), 1)

    -- Get ip address of remote client
    local ip = ngx_var.remote_addr

    -- Read http PUT data
    ngx_req.read_body()
    local body = ngx_req.get_body_data()

    -- Close remote socket stream to save user response time
    ngx_header['Content-Length'] = "0"
    ngx_say(ngx_HTTP_OK)
    ngx_eof()

    -- Fetch geo info by specified ip
    local ok, geo, err = iplib:ip_zones_find(ip)
    if not ok then
        ngx_log(ngx_ERR, "failed to get geo info: ", err)
    end

    local args = {
        ['uid']       = ngx_args.uid,
        ['actime']    = datetime(),
        ['ver']       = ngx_args.ver,
        ['plat']      = ngx_args.plat,
        ['timestamp'] = ngx_args.timestamp,
        ['from']      = ngx_args.from,
        ['ip']        = ip,
        ['zone']      = geo[2].."-"..geo[3].."-"..geo[1],
        ['isp']       = geo[1],
        ['prvn']      = geo[2],
        ['city']      = geo[3],
        ['sceneinfo'] = body or '{}',
    }
    local collect = "aem_sceneinfo"

    -- Send message to kafka brokers
    local message = cjson.encode(args)
    local ok, err = kfksend(collect, nil, message)
    if not ok then
        ngx_log(ngx_ERR, "failed to send message: ", err)
    end

    -- Insert stuck info to database
    local ok, err = dbsave(collect, args)
    if not ok then
        ngx_log(ngx_ERR, "failed to insert into database", err)
    end
end

---- Collect probe pingback info, send it to kafka, and store to database
-- @return
local function send_pingback(match)
    -- Validate all arguments
    local ngx_args = ngx_req.get_uri_args()
    if ngx_args["uid"] == nil or not ngx_match(ngx_args["uid"], "^[A-Za-z0-9_. ]+$", "oj") then
        return
    end
    if ngx_args["plat"] == nil or not ngx_match(ngx_args["plat"], "^[0-9_]+$", "oj") then
        return
    end
    if ngx_args["ver"] == nil or not ngx_match(ngx_args["ver"], "^[0-9.]+$", "oj") then
        return
    end
    if ngx_args["type"] == nil or not ngx_match(ngx_args["type"], "^[0-9]+$", "oj") then
        return
    end
    if shield(ngx_args) == true then
        return ngx_HTTP_SERVICE_UNAVAILABLE
    end
    monitor.incr(stats, monitor.key({match, 'request', 'valid'}), 1)

    -- Get ip address of remote client
    local ip = ngx_var.remote_addr

    -- Read http PUT data
    ngx_req.read_body()
    local body = ngx_req.get_body_data()

    -- Close remote socket stream to save user response time
    ngx_header['Content-Length'] = "0"
    ngx_say(ngx_HTTP_OK)
    ngx_eof()

    -- Fetch geo info by specified ip
    local ok, geo, err = iplib:ip_zones_find(ip)
    if not ok then
        ngx_log(ngx_ERR, "failed to get geo info: ", err)
    end

    local args = {
        ['uid']       = ngx_args.uid,
        ['actime']    = datetime(),
        ['ver']       = ngx_args.ver,
        ['plat']      = ngx_args.plat,
        ['ip']        = ip,
        ['zone']      = geo[2].."-"..geo[3].."-"..geo[1],
        ['isp']       = geo[1],
        ['prvn']      = geo[2],
        ['city']      = geo[3],
        ['pbtype']    = ngx_args.type,
        ['pingback']  = body or '{}',
    }
    local collect = "aem_pingback"

    -- Send message to kafka brokers
    local message = cjson.encode(args)
    local ok, err = kfksend(collect, nil, message)
    if not ok then
        ngx_log(ngx_ERR, "failed to send message: ", err)
    end

    -- Insert stuck info to database
    local ok, err = dbsave(collect, args)
    if not ok then
        ngx_log(ngx_ERR, "failed to insert into database", err)
    end
end

---- Collect probe just-in-time info, and store to database
-- @return
local function send_pingback(match)
    -- Validate all arguments
    local ngx_args = ngx_req.get_uri_args()
    if ngx_args["uid"] == nil or not ngx_match(ngx_args["uid"], "^[A-Za-z0-9_. ]+$", "oj") then
        return
    end
    if ngx_args["plat"] == nil or not ngx_match(ngx_args["plat"], "^[0-9_]+$", "oj") then
        return
    end
    if ngx_args["ver"] == nil or not ngx_match(ngx_args["ver"], "^[0-9.]+$", "oj") then
        return
    end
    if ngx_args["type"] == nil or not ngx_match(ngx_args["type"], "^[0-9]+$", "oj") then
        return
    end
    -- if shield(ngx_args) == true then
        -- return ngx_HTTP_SERVICE_UNAVAILABLE
    -- end
    -- monitor.incr(stats, monitor.key({match, 'request', 'valid'}), 1)

    -- Get ip address of remote client
    local ip = ngx_var.remote_addr

    -- Read http PUT data
    ngx_req.read_body()
    local body = ngx_req.get_body_data()

    -- Close remote socket stream to save user response time
    ngx_header['Content-Length'] = "0"
    ngx_say(ngx_HTTP_OK)
    ngx_eof()

    -- Fetch geo info by specified ip
    local ok, geo, err = iplib:ip_zones_find(ip)
    if not ok then
        ngx_log(ngx_ERR, "failed to get geo info: ", err)
    end

    local args = {
        ['uid']       = ngx_args.uid,
        ['actime']    = datetime(),
        ['ver']       = ngx_args.ver,
        ['plat']      = ngx_args.plat,
        ['ip']        = ip,
        ['zone']      = geo[2].."-"..geo[3].."-"..geo[1],
        ['isp']       = geo[1],
        ['prvn']      = geo[2],
        ['city']      = geo[3],
        ['pbtype']    = ngx_args.type,
        ['jitback']  = body or '{}',
    }
    local collect = "aem_jitback"

    -- Insert stuck info to database
    local ok, err = dbsave(collect, args)
    if not ok then
        ngx_log(ngx_ERR, "failed to insert into database", err)
    end
end
---- Collect idc test info, send it to rsyslog
-- @return
local function send_idc_result(match)
    return ngx_HTTP_OK
end

---- Dispatch probes to users
-- @return probe, status: print dispatched probe, return http status
local function get_cmd(match)
    local args = ngx_req.get_uri_args()
    -- Validate all arguments
    if args["uid"] == nil or not ngx_match(args["uid"], "^[A-Za-z0-9_. ]+$", "oj") then
        return
    end
    if args["plat"] == nil or not ngx_match(args["plat"], "^[0-9_]+$", "oj") then
        return
    end
    if args["ver"] == nil or not ngx_match(args["ver"], "^[0-9.]+$", "oj") then
        return
    end
    if args["api"] == nil or not ngx_match(args["api"], "^[0-9.]+$", "oj") then
        args["api"] = 1
    end
    if tonumber(args["plat"]) == 1 or tonumber(args["plat"]) == 2 then
        return
    end
    if shield(args) == true then
        return ngx_HTTP_SERVICE_UNAVAILABLE
    end
    monitor.incr(stats, monitor.key({match, 'request', 'valid'}), 1)

    -- Get ip address of remote client
    local ip = ngx_var.remote_addr

    -- Fetch geo info by specified ip
    local ok, geo, err = iplib:ip_zones_find(ip)
    if not ok then
        ngx_log(ngx_ERR, "failed to get geo info: ", err)
    end

    args["ip"] = ip
    args["zone"] = geo[2].."-"..geo[3]
    args["isp"] = geo[1]
    args["prvn"] = geo[2]
    args["city"] = geo[3]

    -- Dispatch available probes/commands
    local options = {
        pbopts = conf.probe,
        rdopts = conf.redis,
        defcmd = conf.defcmd,
    }
    local disp = dispatch:new(options)
    local keys, cmds = disp:dispatch(args)
    if keys and #keys > 0 then
        monitor.incr(stats, monitor.key({match, 'command', 'total'}), #keys)
        for _, val in ipairs(keys) do
            monitor.incr(stats, monitor.key({match, 'command', val}), 1)
        end
    end

    if not cmds then
        return ngx_HTTP_NOT_ALLOWED
    end

    ngx_header['Content-Length'] = tostring(#cmds)
    ngx_print(cmds)
    return ngx_HTTP_OK
end

local function get_cfg(match)
    local cloud = conf.cloud
    if cloud ~= nil then
        ngx_say(cloud)
    end
    return ngx_HTTP_OK
end

local function get_status(match)
    local args = ngx_req.get_uri_args()
    local response = {}

    if not args then
        return ngx_HTTP_NOT_ALLOWED
    elseif args['key'] ~= nil then
        response = monitor.get_key(stats, args['key'] or 'all')
    elseif args['group'] ~= nil then
        response = monitor.status(stats, args['group'])
    end

    ngx_say(cjson.encode(response))
    return ngx_HTTP_OK
end

---- Route entrance for Gateway
local routes = {
    ['send_jitback']    = send_jitback,
    ['send_pingback']   = send_pingback,
    ['send_stuckinfo']  = send_stuck_info,
    ['send_core_info']  = send_puma_info,
    ['send_hcdn_info']  = send_hcdn_info,
    ['send_scene_info'] = send_scene_info,
    ['send_idc_result'] = send_idc_result,
    ['get_cfg']         = get_cfg,
    ['get_cmd']         = get_cmd,
    ['get_status']      = get_status,
}

local BASE = '/'
ngx_header.content_type = 'text/html'

---- Parse routing
for pattern, view in pairs(routes) do
    local uri = '^' .. BASE .. pattern .. '$'
    local match = ngx_match(ngx_var.uri, uri, "oj")
    if match then
        monitor.incr(stats, monitor.key({pattern, 'request', 'total'}), 1)
        exit = view(pattern) or ngx_HTTP_OK
        ngx_exit(exit)
    end
end
-- not matched, return 404
ngx_exit(ngx_HTTP_NOT_FOUND)
