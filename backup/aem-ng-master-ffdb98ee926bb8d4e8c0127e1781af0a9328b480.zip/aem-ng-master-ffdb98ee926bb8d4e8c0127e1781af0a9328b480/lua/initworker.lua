--------------------------------------------------------------------------------
---- Initialize worker process
---- Description: perform initialization at worker process starting
---- @module initworker
---- @author Chen Gui <chengui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local config = require("config")
local probe = require("probe")

local timer_at = ngx.timer.at
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR

local lock_dict = ngx.shared.lock_dict
local conf = config:new()

local delay = conf.interval or 86400

local function _refresh(premature)
    local options = {
        pbopts = conf.probe,
        rdopts = conf.redis,
    }
    local pbmgr = probe:new(options)
    if not conf.probe.mongo then
        ngx_log(ngx_ERR, "failed to get database configure")
        return
    end

    local mopool = require("mopool")
    local mo = mopool:new(conf.probe.mongo)
    local res, err = mo:find(conf.probe.mongo.collection, {}, nil, 1000)
    if not res then
        ngx_log(ngx_ERR, "failed to fetch probes: ", err)
    else
        ngx_log(ngx_ERR, "loaded probes from mongo")
        pbmgr:refresh(res)
    end
end

local _timer_refresh
_timer_refresh = function (premature, time)
    local ok, err = timer_at(0, _refresh)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer: ", err)
    end

    if premature then
        return
    end

    local ok, err = timer_at(time, _timer_refresh, delay)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer: ", err)
    end
end

conf.probe = conf.probe or {}
local queue_prefix = conf.probe.queue or 'queue:'
local id = ngx.worker.id()
if id then
    local redis_queue = queue_prefix..id
    local succ, err, forcible = lock_dict:add(redis_queue, true)
    if succ and conf.probe then
        conf.probe.queue = redis_queue
    end
else
    local pid = ngx.worker.pid()
    local cnt = ngx.worker.count()
    for i = 1, cnt do
        local redis_queue = queue_prefix..(pid % cnt)
        local succ, err, forcible = lock_dict:add(redis_queue, true)
        if succ and conf.probe then
            conf.probe.queue = redis_queue
            break
        end
        pid = pid + 1
    end
end

local first_delay = (24 - tonumber(os.date("%H")) + 3) * 3600

_timer_refresh(nil, first_delay)
