--------------------------------------------------------------------------------
---- Storage for saving all user records
---- Description: Save users' stuckinfo to storage like databases
---- @module storage
---- @author Chen Gui <chengui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local cjson = require("cjson")
local mypool = require("mypool")
local mopool = require("mopool")
local batchbuffer = require("batchbuffer")

local setmetatable = setmetatable
local t_insert = table.insert
local t_concat = table.concat
local tostring = tostring
local tonumber = tonumber
local pairs = pairs
local pcall = pcall

local is_exiting = ngx.worker.exiting
local timer_at = ngx.timer.at
local ngx_quote = ngx.quote_sql_str
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR

local _M = {_VERSION = '0.01'}
local mt = {__index = _M}

local _instance

local table_names = {
    ['aem_ndctinfo']  = 'ndct_client',
    ['aem_hcdninfo']  = 'ndct_hcdninfo',
    ['aem_pumainfo']  = 'ndct_coreinfo',
    ['aem_pingback']  = 'ndct_pingback',
    ['aem_sceneinfo'] = 'ndct_sceneinfo',
}
local column_names = {
    ['aem_ndctinfo'] = {
        ['uid']       = 'uid',
        ['actime']    = 'access_time',
        ['ver']       = 'version',
        ['plat']      = 'platform',
        ['ip']        = 'ip',
        ['zone']      = 'zone',
        ['stuckinfo'] = 'stuckinfo',
    },
    ['aem_hcdninfo'] = {
        ['uid']       = 'uid',
        ['actime']    = 'access_time',
        ['ver']       = 'version',
        ['plat']      = 'platform',
        ['ip']        = 'ip',
        ['zone']      = 'zone',
        ['stuckinfo'] = 'hcdninfo',
    },
    ['aem_pumainfo'] = {
        ['uid']       = 'uid',
        ['actime']    = 'access_time',
        ['ver']       = 'version',
        ['plat']      = 'platform',
        ['ip']        = 'ip',
        ['zone']      = 'zone',
        ['stuckinfo'] = 'coreinfo',
    },
    ['aem_pingback'] = {
        ['uid']       = 'uid',
        ['actime']    = 'access_time',
        ['ver']       = 'version',
        ['plat']      = 'platform',
        ['pbtype']    = 'pback_type',
        ['ip']        = 'ip',
        ['zone']      = 'zone',
        ['pingback']  = 'pingback',
    },
    ['aem_sceneinfo'] = {
        ['uid']       = 'uid',
        ['actime']    = 'access_time',
        ['ver']       = 'version',
        ['plat']      = 'platform',
        ['ip']        = 'ip',
        ['zone']      = 'zone',
        ['sceneinfo'] = 'sceneinfo',
    },
}
local column_types = {
    ['aem_ndctinfo'] = {
        ['uid']       = 'string',
        ['actime']    = 'string',
        ['ver']       = 'string',
        ['plat']      = 'int',
        ['ip']        = 'string',
        ['zone']      = 'string',
        ['isp']       = 'string',
        ['prvn']      = 'string',
        ['city']      = 'string',
        ['stuckinfo'] = 'table',
    },
    ['aem_hcdninfo'] = {
        ['uid']       = 'string',
        ['actime']    = 'string',
        ['ver']       = 'string',
        ['plat']      = 'int',
        ['ip']        = 'string',
        ['zone']      = 'string',
        ['isp']       = 'string',
        ['prvn']      = 'string',
        ['city']      = 'string',
        ['stuckinfo'] = 'table',
    },
    ['aem_pumainfo'] = {
        ['uid']       = 'string',
        ['actime']    = 'string',
        ['ver']       = 'string',
        ['plat']      = 'int',
        ['ip']        = 'string',
        ['zone']      = 'string',
        ['isp']       = 'string',
        ['prvn']      = 'string',
        ['city']      = 'string',
        ['stuckinfo'] = 'table',
    },
    ['aem_pingback'] = {
        ['uid']       = 'string',
        ['actime']    = 'string',
        ['ver']       = 'string',
        ['plat']      = 'int',
        ['pbtype']    = 'int',
        ['ip']        = 'string',
        ['zone']      = 'string',
        ['isp']       = 'string',
        ['prvn']      = 'string',
        ['city']      = 'string',
        ['pingback']  = 'table',
    },
    ['aem_sceneinfo'] = {
        ['uid']       = 'string',
        ['actime']    = 'string',
        ['ver']       = 'string',
        ['plat']      = 'int',
        ['ip']        = 'string',
        ['zone']      = 'string',
        ['isp']       = 'string',
        ['prvn']      = 'string',
        ['city']      = 'string',
        ['sceneinfo'] = 'table',
    },
}

local pdecode = function (jstr)
    if jstr ~= nil then
        local ok, ret = pcall(cjson.decode, jstr)
        if ok and type(ret) == 'table' then
            return ret
        end
    end
    return {}
end

local function _my_batch_save(self, collect, docs)
    local coltype = column_types[collect]
    if self.compat then
        local tblname = table_names[collect]
        local colname = column_names[collect]
    else
        local tblname = collect
        local colname = coltype
    end

    local columns = {}
    for key, col in pairs(colname) do
        if self.compat then
            t_insert(columns, col)
        else
            t_insert(columns, key)
        end
    end

    local sql = [[
        INSERT INTO ]]..tblname..[[ (]]..t_concat(columns, ',')..[[) VALUES
    ]]

    local values = {}
    for _, doc in ipairs(docs) do
        local sqlstr = {}
        for key, _ in pairs(colname) do
            if doc[key] ~= nil then
                if coltype[key] == 'int' then
                    t_insert(sqlstr, doc[key])
                else
                    t_insert(sqlstr, ngx_quote(doc[key]))
                end
            end
        end
        t_insert(values, "("..t_concat(sqlstr, ',')..")")
    end

    sql = sql..[[ ]]..t_concat(values, ',')

    local options = self.mysql
    local my = mypool:new(options)
    return my:query(sql)
end

local function _mo_batch_save(self, collect, docs)
    local coltype = column_types[collect]

    local copies = {}
    for _, doc in ipairs(docs) do
        local copy = {}
        for key, val in pairs(doc) do
            if coltype[key] == 'table' then
                copy[key] = pdecode(val)
            elseif coltype[key] == 'int' then
                copy[key] = tonumber(val) or 0
            else
                copy[key] = val
            end
        end
        t_insert(copies, copy)
    end

    local options = self.mongo
    local mo = mopool:new(options)
    return mo:insert(collect, copies)
end

local function _batch_save(self, collect, batbuffer)
    local num = 0
    local savebuffer = {}
    while num <= self.batch_num do
        local doc, err = batbuffer:pop(collect)
        if not doc then
            break
        end

        t_insert(savebuffer, doc)
        num = num + 1
    end

    if num <= 0 then
        return false
    end

    if self.mysql.enabled then
        local ok, err = _my_batch_save(self, collect, savebuffer)
        if not ok then
            ngx_log(ngx_ERR, "failed to save to mysql, err: ", err)
        end
    end

    if self.mongo.enabled then
        local ok, err = _mo_batch_save(self, collect, savebuffer)
        if not ok then
            ngx_log(ngx_ERR, "failed to save to mongo, err: ", err)
        end
    end
    return true
end

local function _save_lock(self)
    if not self.saving then
        self.saving = true
        return true
    end
    return false
end

local function _save_unlock(self)
    self.saving = false
end

local _save_buffer

local function _save(premature, self)
    if not _save_lock(self) then
        return
    end

    local batbuffer = self.batbuffer
    local collects = batbuffer.collects

    for _, collect in ipairs(collects) do
        _batch_save(self, collect, batbuffer)
    end

    _save_unlock(self)

    if batbuffer:need_save() then
        _save_buffer(self)
    elseif is_exiting() and batbuffer:left_num() > 0 then
        _save_buffer(self)
    end

    return true
end

_save_buffer = function (self)
    local ok, err = timer_at(0, _save, self)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer at _save_buffer, err: ", err)
    end
end

local _timer_save
_timer_save = function (premature, self, time)
    _save_buffer(self)

    if premature then
        return
    end

    local ok, err = timer_at(time, _timer_save, self, time)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer at _timer_save, err: ", err)
    end
end

function _M.async_save(self, collect, doc)
    local batbuffer = self.batbuffer

    local ok, err = batbuffer:push(collect, doc)
    if not ok then
        ngx_log(ngx_ERR, "failed to save to batch buffer, err: ", err)
        return nil, err
    end

    if not self.saving and (batbuffer:need_save() or is_exiting()) then
        _save_buffer(self)
    end

    return true
end

local columns_strs = {}
local function get_columns_str(collect)
    if columns_strs[collect] ~= nil then
        return columns_strs[collect]
    end

    local colname = column_names[collect]

    local cols = {}
    for key, col in pairs(colname) do
        t_insert(cols, col)
    end
    return t_concat(cols, ",")
end

---- Execute insertion in mysql database
-- @param collect:
-- @param args:
-- @param columns:
-- @return :
local function _my_save(self, collect, doc)
    local coltype = column_types[collect]
    local tblname = collect
    local colname = coltype
    if self.compat then
        tblname = table_names[collect]
        colname = column_names[collect]
    end

    local colstr = {}
    local sqlstr = {}
    for key, _ in pairs(colname) do
        if self.compat then
            t_insert(colstr, colname[key])
        else
            t_insert(colstr, key)
        end

        if coltype[key] == 'int' then
            t_insert(sqlstr, doc[key])
        else
            t_insert(sqlstr, ngx_quote(doc[key]))
        end
    end

    local sql = [[
        INSERT INTO ]]..tblname..[[ (]]..t_concat(colstr, ",")..[[)
        VALUES (]]..t_concat(sqlstr, ",")..[[)
    ]]

    local options = self.mysql
    local my = mypool:new(options)
    return my:query(sql)
end

---- Execute insertion in mongo database
-- @param self:
-- @param collect:
-- @param doc:
-- @return :
local function _mo_save(self, collect, doc)
    local coltype = column_types[collect]

    local copy = {}
    for key, val in pairs(doc) do
        if coltype[key] == 'table' then
            copy[key] = pdecode(val)
        elseif coltype[key] == 'int' then
            copy[key] = tonumber(val) or 0
        end
    end

    local options = self.mongo
    local mo = mopool:new(options)
    return mo:insert(collect, doc)
end

function _M.sync_save(self, collect, doc)
    if self.mysql.enabled then
        local ok, err = _my_save(self, collect, doc)
        if not ok then
            ngx_log(ngx_ERR, "failed to save to mysql, err: ", err)
        end
    end
    if self.mongo.enabled then
        local ok, err = _mo_save(self, collect, doc)
        if not ok then
            ngx_log(ngx_ERR, "failed to save to mongo, err: ", err)
        end
    end
    return true
end
_M.save = _M.sync_save

function _M.new(self, opts)
    opts = opts or {}

    if opts.async and _instance then
        return _instance
    end

    local p = {
        mongo = opts.mongo or {},
        mysql = opts.mysql or {},
        async = opts.async or false,
        compat = opts.compat or false,
    }

    if opts.async then
        local collects = {'aem_ndctinfo', 'aem_hcdninfo', 'aem_pumainfo', 'aem_pingback', 'aem_sceneinfo'}
        p.batbuffer = butchbuffer:new(
            opts.collects or collects,
            opts.batch_num or 200,
            opts.batch_size or 50000
        )
        p.batch_num = opts.batch_num or 200
        _M.save = _M.async_save

        _instance = setmetatable(p, mt)
        _timer_save(nil, _instance, (opts.save_interval or 1000) / 1000)
    end

    return setmetatable(p, mt)
end

return _M
