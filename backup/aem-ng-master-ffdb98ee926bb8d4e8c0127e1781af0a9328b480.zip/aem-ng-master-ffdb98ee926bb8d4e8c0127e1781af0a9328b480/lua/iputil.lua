--------------------------------------------------------------------------------
---- IPlib utility
---- Description: A lua wrapper upon qiyi-iplib module utils_lua
---- @module iputil
---- @author Chen Gui <chengui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local utils = require("utils_lua")

local setmetatable = setmetatable
local string = string
local table = table
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR

local iplib_file = "/opt/soft/aem/etc/global_city_v1.0"
local iplib = nil

local _instance

local _M = {_VERSION = '0.01'}
local mt = {__index = _M}

---- Split string by the specified delimiter
-- @param str: string to be splitted
-- @param delimiter: specify delimiter
-- @return table: splitted substrings
local function split(str, delimiter)
    local result = {}
    local from  = 1
    local delim_from, delim_to = string.find(str, delimiter, from)
    while delim_from do
        table.insert(result, string.sub(str, from, delim_from-1))
        from  = delim_to + 1
        delim_from, delim_to = string.find(str, delimiter, from)
    end
    table.insert(result, string.sub(str, from))
    return result
end

---- Lookup the given ip in iplib
-- @param self: module table
-- @param ip: specify ip
-- @return boolean, table, error: table indicates (isp, province, city) array
function _M.ip_zones_find(self, ip)
    local zone = utils.ip_zones_find(self.iplib, ip)
    local ztab = split(zone, "|")
    for i=1,3 do
        ztab[i] = ztab[i] or "None"
    end
    return true, {ztab[1], ztab[2], ztab[3]}, nil
end

local function reload(premature, self)
    if premature then
        return
    end

    local httpc = http.new()

    local res, err = httpc.request_uri(self.uri, {
        headers = {["If-None-Match"] = self.etag}
    })

    if not res or err then
        ngx_log(ngx_ERR, "failed to request ", self.uri, ": ", err)
        return false
    end

    if res.status ~= 304 then
        local file = io.open(iplib_file, 'w')
        file:write(res.body)
        file:flush()
        file:close()
        ngx_log(ngx_ERR, "updated iplib from ", self.uri)
    end
end

local _timer_reload
_timer_reload = function (premature, self, time)
    local ok, err = time_at(0, _reload, self)
    if not ok then
        ngx_log(ngx_ERR, "failed to reload iplib in async mode, err: ", err)
    end

    if premature then
        return
    end

    local ok, err = timer_at(time, _timer_reload, self, time)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer at _timer_reload, err: ", err)
    end
end

---- Initialize iputil module
---- @param self: module table
---- @return metatable
function _M.new(self, opts)
    opts = opts or {}
    if _instance then
        return _instance
    end

    if iplib == nil then
        iplib = utils.ip_zones_load(iplib_file, 0)
        ngx_log(ngx_ERR, "loaded iplib file: ", iplib_file)
    end
    _instance = setmetatable({
        iplib = iplib,
        uri = opts.uri or "http://ipdb.qiyi.domain/download/latest/city",
        etag = opts.etag or "59804663-18121f6"
    }, mt)

    _timer_reload(nil, _instance, (opts.reload_time or 86400))

    return _instance
end

return _M
