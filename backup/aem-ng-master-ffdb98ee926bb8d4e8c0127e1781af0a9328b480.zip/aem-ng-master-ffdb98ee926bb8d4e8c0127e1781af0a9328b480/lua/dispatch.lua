--------------------------------------------------------------------------------
-- Probe dispatcher module
-- Description: dispatch probes which is supposed to be performed at
--   user/client side to fetch interface/dns/downlaod check result
-- @module dispatch
-- @author Chen Gui <chengui@qiyi.com>
-- @license @see LICENSE
-- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local cjson = require("cjson")
local probe = require("probe")

local setmetatable = setmetatable
local tonumber = tonumber
local string = string
local table = table
local ipairs = ipairs
local pairs = pairs
local pcall = pcall
local type = type
local os = os
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR

local ok, new_tab = pcall(require, "new_tab")
if not ok or type(new_tab) ~= "function" then
    new_tab = function (narr, nrec) return {} end
end

local _M = {_VERSION = '0.02'}
local mt = {__index = _M}

local cmdname = {'detection', 'dns', 'dload', [99]='pdata'}

---- Return json string for final dispatching result
-- @param self: module table
-- @param data: commands array indicates dispatching commands
-- @return json string
local function result(self, api, data)
    api = string.format("%.1f", api or 1)
    data = data or {}
    local defcmd = self.defcmd
    table.insert(data, 1, defcmd)
    local res = {
        version = api,
        data = data,
    }
    return cjson.encode(res)
end

---- Check if period is coming up or not
-- @param period: period table indicates what time should be dispatching
-- @return boolean indicates if time is coming up or not
local function is_upcoming(period)
    local now = os.time{
        year=1970, month=1, day=1, hour=os.date("*t").hour, min=os.date("*t").min, sec=os.date("*t").sec
    }
    if period['beg'] and now < period['beg'] then
        return true
    end
    return false
end

---- Check if period is expired or not
-- @param period: period table indicates what time should be dispatching
-- @return boolean: indicates if time is expired or not
local function is_expired(period)
    local now = os.time{
        year=1970, month=1, day=1, hour=os.date("*t").hour, min=os.date("*t").min, sec=os.date("*t").sec
    }
    if period['end'] and now > period['end'] then
        return true
    end
    return false
end

---- Check if it is matched with policy of the given probe or not
-- @param policy: indicates what conditions should be matched in dispatching
-- @param boolean: indicates if policy is matched or not
local function is_matched(policy, args)
    for k, v in pairs(policy) do
        if args[k] ~= v then
            return false
        end
    end
    return true
end

---- Closure used for commands array, mainly for appending new command to array
-- @param size: size of commands array supposed
-- @param ver: api version for commands interface
-- @return closure: perform actions on commands array
local function appender(size, api)
    local cmds = new_tab(size, 0)
    local ids = new_tab(size, 0)
    local api = api
    local cnt = 0

    ---- Append command to array. If ver greater than 2,
    ---- append it as queue; else collect commands by
    ---- command type, which is compitable with legacy
    ---- design used by current client
    -- @param cmd: command to be appended
    local function append(cmd, index)
        table.insert(ids, index)
        if api >= 2 then
            local copy = {}
            for k, v in pairs(cmd) do
                copy[k] = v
            end
            table.insert(cmds, copy)
            cnt = cnt + 1
        else
            if cnt == 0 then
                local copy = {}
                for k, v in pairs(cmd) do
                    copy[k] = v
                end
                table.insert(cmds, copy)
                cnt = cnt + 1
            elseif cmd['type'] == cmds[1]['type'] then
                name = cmdname[cmds[1]['type']]
                cmds[1][name] = cmds[1][name]..'|'..cmd[name]
                cnt = cnt + 1
            end
        end
    end

    -- Return key of every append command
    local function keys()
        return ids
    end
    -- Return count of appended commands
    local function getn()
        return cnt
    end

    -- Return commands array
    local function data()
        return cmds
    end

    -- Return closure
    return function (index)
        local dict = {
            getn = getn,
            data = data,
            append = append,
            keys = keys,
        }
        return dict[index]
    end
end

---- Dispatch routine to perform commands dispatching,
---- default command returned if failure
-- @param self: module table
-- @param args: parameters of accessing client
-- @return json string: indicates final return json
function _M.dispatch(self, args)
    local pool, err = self.pbmgr:top()
    if not pool then
        return nil, result(self)
    end

    local api = tonumber(args.api) or 1
    local cmds = appender(self.limit, api)
    for idx, score in pairs(pool) do
        local probe = self.pbmgr:getitem(idx)
        if probe then
            local policy = probe.policy
            local period = probe.period
            if cmds('getn')() >= self.limit then
                break
            end
            if probe.cnt > tonumber(probe.reqs) then
                self.pbmgr:clritem(idx)
                self.pbmgr:incr(idx, probe.gap)
            elseif is_expired(period) then
                self.pbmgr:pop(idx)
            elseif is_upcoming(period) then
                self.pbmgr:incr(idx, probe.gap)
            elseif is_matched(policy, args) then
                cmds('append')(probe.cmd, idx)
                self.pbmgr:incritem(idx)
            else
                ngx_log(ngx_ERR, "failed to dispatch probe: unmatched conditions")
            end
        end
    end

    return cmds('keys')(), result(self, api, cmds('data')())
end

---- Initialize dispatch module
-- @param self: module table
-- @param opts: options
-- @return metatable
function _M.new(self, opts)
    opts = opts or {}
    local pbmgr = probe:new({
        pbopts = opts.pbopts,
        rdopts = opts.rdopts,
    })
    local defcmd = opts.defcmd or {
        ['type']      = 0,
        ['auto_up']   = "1",
        ['platform']  = "0",
        ['dns_check'] = "0",
        ['version']   = "1.0.2.0618|1.0.2.0710",
    }
    local self_dict = {
        pbmgr = pbmgr,
        limit = opts.limit or 1,
        defcmd = defcmd or {},
    }
    return setmetatable(self_dict, mt)
end

return _M
