--------------------------------------------------------------------------------
-- Server status information
-- Description: Monitor server status
-- @module status
-- @author Chen Gui <chengui@qiyi.com>
-- @author Wang Minghui <wangminghui@qiyi.com>
-- @license @see LICENSE
-- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local cjson   = require("cjson")
local config  = require("config")

local t_insert = table.insert
local s_find  = string.find
local tostring = tostring
local pairs = pairs
local next = next

local ngx_capture = ngx.location.capture
local ngx_say = ngx.say
local ngx_req = ngx.req
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR
local ngx_HTTP_OK = ngx.HTTP_OK

local _M = {_VERSION = '0.02'}
if setfenv then
    setfenv(1, _M) -- for 5.1
else
    _ENV = _M      -- for 5.2
end

local conf = config:new()

function status(match)
    local args = ngx_req.get_uri_args()
    if not args or not next(args) then
        return cjson.encode({error="known arguments"})
    end
    if not args['ip'] then
        return cjson.encode({error="invalid arguments"})
    end
    local result = {}
    local req_args = {}
    local url = {}
    local res = {}
    local gateways = conf.gateways

    if args['ip'] == 'all' then
        for gate, flag in pairs(gateways) do
            local req_args = {
                key = 'all'
            }
            url = '/proxy/http/'..tostring(gate)..'/80/get_status'
            res = ngx_capture(url, {args=req_args})
            if not res or res.status ~= ngx_HTTP_OK then
                return cjson.encode({error="invalid or none response"})
            else
                for name, value in pairs(cjson.decode(res.body)) do
                    if result[name] ~= nil then
                        result[name] = result[name] + value
                    else
                        result[name] = value
                    end
                end
            end
        end
        result = cjson.encode(result)
    elseif gateways[args['ip']] then
        req_args = {
            group = args['group'] or 'all'
        }
        if args['key'] ~= nil then
            req_args = {
            key = args['key'] or 'all'
        }
        end
        url = '/proxy/http/'..tostring(args['ip'])..'/80/get_status'
        res = ngx_capture(url, {args=req_args})
        if not res or res.status ~= ngx_HTTP_OK then
            return cjson.encode({error="invalid or none response"})
        end
        result = res.body
    else
        return cjson.encode({error="incorrect ip address or server offline"})
    end

    return result
end

function gateways(match)
    local servers = conf.gateways
    local ret = {}
    for ip, stat in pairs(servers) do
        if stat then
            t_insert(ret, tostring(ip))
        end
    end
    return cjson.encode({gateways=ret})
end

function reload(match)
    ngx_log(ngx_ERR, "api.reload")
end

return _M

