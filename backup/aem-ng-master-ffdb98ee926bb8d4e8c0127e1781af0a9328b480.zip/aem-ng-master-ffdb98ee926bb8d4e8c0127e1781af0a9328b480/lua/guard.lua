--------------------------------------------------------------------------------
---- Guarder module
---- Description: Guard against cc attack and unexpected requests
---- @module guard
---- @author Chen Gui <chengui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local setmetatable = setmetatable
local concat = table.concat

local ngx_match = ngx.re.match

local _M = {_VERSION = '0.01'}
local mt = {__index = _M}

function _M.key(key_table)
    return concat(key_table, ':')
end

function _M.limit_req(self, key)
    local key = 'limit:'..key
    local dict = self.dict
    local maxreqs = self.maxreqs
    local exptime = self.exptime
    local req_times = dict:get(key)
    if req_times then
        dict:incr(key, 1)
    else
        dict:set(key, 1, exptime)
        req_times = 0
    end
    req_times = req_times + 1
    if req_times > maxreqs then
        return true
    end
    return false
end

function _M.in_white_list(self, key)
    local white_list = self.white_list
    if ngx_match(key, white_list) then
        return true
    end
    return false
end

function _M.in_black_list(self, key)
    local key = 'black:'..key
    local dict = self.dict
    if dict:get(key) then
        return true
    end
    return false
end

function _M.new(self, opts)
    opts = opts or {}
    local self_dict = {
        dict = opts.dict,
        white_list = opts.white_list,
        exptime = opts.exptime or 300,
        maxreqs = opts.maxreqs or 100,
    }
    return setmetatable(self_dict, mt)
end

return _M
