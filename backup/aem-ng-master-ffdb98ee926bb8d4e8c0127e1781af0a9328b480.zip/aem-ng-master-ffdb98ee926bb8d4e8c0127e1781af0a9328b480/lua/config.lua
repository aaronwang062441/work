--------------------------------------------------------------------------------
---- Configure module
---- Description: Load configuration from lua format config file
---- @module config
---- @author Chen Gui <chengui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local cjson = require("cjson")

local setmetatable = setmetatable
local assert = assert
local io = io
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR

local _M = {_VERSION = '0.02'}
local mt = {__index = _M}

local config_file = "/opt/soft/aem/etc/cfg.lua"
local config = nil

local _instance

---- Load from lua format config file
-- @param self: module table
-- @param fpath: config file path
-- @return boolean: true
function _M.load(self, fpath)
    if config == nil then
        local f = assert(loadfile(fpath))
        config = f()
        cloud = config.cloud
        config.cloud = cjson.encode(cloud)
    end
    return true
end

---- Reload config to support hot loading
-- @param self: module table
-- @param fpath: config file path
-- @return boolean: true
function _M.reload(self, fpath)
    if pcall(function(fp) assert(loadfile(fp)) end, fpath) then
        if config ~= nil then
            config = nil
        end
        self:load(fpath)
    else
        ngx_log(ngx_ERR, "failed to reload config file: ", fpath)
    end
    return true
end

local _timer_reload
_timer_reload = function (premature, self, time)
    self:reload(config_file)

    if premature then
        return
    end

    local ok, err = timer_at(time, _timer_reload, self, time)
    if not ok then
        ngx_log(ngx_ERR, "failed to create timer at config._timer_reload, err: ", err)
    end
end

---- Initial config module
-- @param self: module table
-- @return metatable:
function _M.new(self, opts)
    opts = opts or {}
    if _instance then
        return _instance
    end

    if config == nil then
        self:load(config_file)
        ngx_log(ngx_ERR, "loaded config file: ", config_file)
    end
    _instance = setmetatable(config, mt)

    _timer_reload(nil, _instance, (opts.reload_time or 3600))

    return _instance
end

return _M
