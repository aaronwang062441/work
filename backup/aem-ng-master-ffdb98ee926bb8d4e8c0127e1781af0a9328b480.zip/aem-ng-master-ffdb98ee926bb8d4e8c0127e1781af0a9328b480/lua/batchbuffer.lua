--------------------------------------------------------------------------------
---- Batched buffers for ringbuffer
---- Description: cache all users' posted stuckinfo for saving later
---- @module batchbuffer
---- @author Chen Gui <chengui@qiyi.com>
---- @license @see LICENSE
---- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local cjson = require("cjson")

local setmetatable = setmetatable
local ipairs = ipairs
local pairs = pairs
local pcall = pcall

local ngx_null = ngx.null

local ok, new_tab = pcall(require, "table.new")
if not ok then
    new_tab = function (narr, nrec) return {} end
end

local _M = {_VERSION = "0.01"}
local mt = {__index = _M}

function _M.pop(self, collect)
    local ringbuffer = self.buffers[collect]
    if not ringbuffer then
        return nil, "invalid buffer"
    end

    local num = ringbuffer.num
    if num <= 0 then
        return nil, "empty buffer"
    end

    ringbuffer.num = num - 1

    local start = ringbuffer.start
    local buffer = ringbuffer.buffer

    ringbuffer.start = (start + 1) % ringbuffer.size

    local doc = buffer[start]
    buffer[start] = ngx_null

    return doc
end

function _M.push(self, collect, doc)
    local ringbuffer = self.buffers[collect]
    if not ringbuffer then
        return nil, "invalid buffer"
    end

    local num = ringbuffer.num
    local size = ringbuffer.size

    if num >= size then
        return nil, "buffer overflow"
    end

    local index = (ringbuffer.start + num) % size

    ringbuffer.buffer[index] = doc
    ringbuffer.num = num + 1

    return true
end

function _M.left_num(self)
    local num = 0
    for _, ringbuffer in pairs(self.buffers) do
        num = num + ringbuffer.num
    end
    return num
end

function _M.need_save(self)
    local buffers = self.buffers
    for _, ringbuffer in pairs(buffers) do
        if ringbuffer.num >= self.batch_num then
            return true
        end
    end
    return false
end

function _M.new(self, collects, batch_num, batch_size)
    local buffers = {}
    local total_size = 0
    for _, col in ipairs(collects) do
        local ringbuffer = {
            buffer = new_tab(batch_size, 0),
            size = batch_size,
            start = 1,
            num = 0,
        }
        buffers[col] = ringbuffer
        total_size = total_size + batch_size
    end
    local meta = {
        buffers = buffers,
        collects = collects,
        batch_num = batch_num,
        batch_size = total_size,
    }
    return setmetatable(meta, mt)
end

return _M
