--------------------------------------------------------------------------------
-- Connection pool for mysql database
-- Description: a connection pool wrapper module for simply accessing mysql database
-- @module mypool
-- @author Chen Gui <chengui@qiyi.com>
-- @license @see LICENSE
-- @copyright iQIYI.com 2016
--------------------------------------------------------------------------------

local mysql = require("resty.mysql")

local setmetatable = setmetatable

-- module table and metatble
local _M = {_VERSION = '0.01'}
local mt = {__index = _M}

---- Connect mysql database
-- @param self: module table
-- @return tuple: (bool, string/table)
-- @usage local ok, db = self:connect()
function _M.connect(self)
    -- alloc database
    local db, err = mysql:new()
    if not db then
        return false, "mysql error: " .. (err or "nil")
    end

    -- connect database
    db:set_timeout(self.socket_timeout)
    local connopts = {
        host = self.host,
        port = self.port,
        user = self.user,
        password = self.password,
        database = self.database,
    }
    local ok, err, errno, sqlstate = db:connect(connopts)
    if not ok then
        return false, "mysql error: "..(err or "nil")..", errno: "..(errno or "nil")..", sqlstate: "..(sqlstate or "nil")
    end

    return true, db
end

---- Set keepalive parameter
-- @param self: module table
-- @param db: mysql db instance returned by connect
-- @usage self:set_keepalive(db)
function _M.set_keepalive(self, db)
    return db:set_keepalive(self.keepalive_timeout, self.keepalive_poolsize)
end

---- Perform sql statement query
-- @param self: module table
-- @param sql: sql statement to be performed
-- @return tuple: (bool, string/table, sqlstate)
-- @usage local ok, res, sqlstate = self:query("SELECT * FROM T_TEST")
function _M.query(self, sql)
    local ok, db = self:connect()
    if not ok then
        return nil, db
    end

    local res, err, errno, sqlstate = db:query(sql)
    self:set_keepalive(db)
    if not res then
        return nil, "mysql error: "..(err or "nil")..", errno: "..(errno or "nil")..", sqlstate: "..(sqlstate or "nil")
    end

    return res, nil
end

---- Perfrom sql statement execution, suck like 'insert', 'delete', 'update'
-- @param self: module table
-- @param sql: sql statement to be performed
-- @return integer: -1 indicts failed, positive number indicts affected rows in query
-- @usage local ret = self:execute("DELETE FROM T_TEST")
function _M.execute(self, sql)
    local ok, db = self:connect()
    if not ok then
        return -1
    end

    local res, err, errno, sqlstate = db:query(sql)
    self:set_keepalive(db)
    if not res then
        return -1
    end
    return res.affected_rows
end

---- Create a new connection pool instance
-- @param self: module table
-- @param opts: @{mod_options}
-- @return metatable: module table
-- @usage local pool = mypool:new()
function _M.new(self, opts)
    -- module options
    -- @field host connecting host ip
    -- @field port connecting host port
    -- @field user account username for mysql
    -- @field password account password for mysql
    -- @field database database name in mysql
    -- @field timeout timeout of connecting
    -- @field poolsize size of connection pool
    -- @field maxidletmo max idle timeout of keepalive
    -- @table mod_options
    opts = opts or {}
    local self_dict = {
        host = opts.host or "127.0.0.1",
        port = opts.port or 3306,
        user = opts.user or "root",
        password = opts.password or "",
        database = opts.database or "ndct",

        socket_timeout = opts.socket_timeout or 2000,
        keepalive_poolsize = opts.keepalive_poolsize or 500,
        keepalive_timeout = opts.keepalive_timeout or 10000,
    }
    return setmetatable(self_dict, mt)
end

return _M
