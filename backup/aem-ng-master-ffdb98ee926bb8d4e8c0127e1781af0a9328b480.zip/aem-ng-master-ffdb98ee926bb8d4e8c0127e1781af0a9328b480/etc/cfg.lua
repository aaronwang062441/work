return {
    interval = 86400,
    iplib = {
        uri = "http://ipdb.qiyi.domain/download/latest/city",
        etag = "59804663-18121f6"
    },
    defcmd = {
        type      = 0,
        auto_up   = "1",
        platform  = "0",
        dns_check = "0",
        version   = "1.0.2.0618|1.0.2.0710",
    },
    probe = {
        limit = 2,
        queue = "queue:",
        mhash = "probe:",
        mongo = {
            host = "127.0.0.1",
            port = 27017,
            user = "root",
            password = "",
            database = "aem_probe",
            collection = "probes"
        }
    },
    database = {
        enabled = false,
        mongo = {
            enabled = false,
            host = "127.0.0.1",
            port = 27017,
            user = "root",
            password = "",
            database = "netdoctor",
        },
        mysql = {
            enabled = false,
            host = "127.0.0.1",
            port = 3306,
            user = "root",
            password = "",
            database = "netdoctor",
        }
    },
    redis = {
        host = "127.0.0.1",
        port = 6379,
        user = "root",
        password = "",
        dbindex  = 0,
    },
    kafka = {
        enabled = false,
        hosts = {
            {
                host = "10.77.44.41",
                port = 9092,
            },
            {
                host = "10.77.44.219",
                port = 9092,
            },
        }
    },
    cloud = {
        c = {
            pi = 4 * 3600 * 1000,
            hr = 10 * 1024,
        },
        h = {
            ui = 24 * 3600 * 1000,
        },
        p = {
            hr = 1024,
            hd = 5 * 1024 * 1024,
        },
        d = {
            to = 7 * 1000,
            ui = 5 * 60 * 1000,
        },
        j = {
            er = 0,
            ui = 3600 * 1000,
        }
    }
}
