return {
    interval = 86400,
    defcmd = {
        type      = 0,
        auto_up   = "1",
        platform  = "0",
        dns_check = "0",
        version   = "1.0.2.0618|1.0.2.0710",
    },
    probe = {
        limit = 2,
        queue = "queue:",
        mhash = "probe:",
        mongo = {
            host = "aem-1.qiyi.mongo",
            port = 27017,
            user = "netdoctor",
            password = "iqiyi.123",
            database = "aem_probe",
            collection = "probes"
        },
    },
    database = {
        enabled = false,
        mongo = {
            enabled = false,
            host = "aem-1.qiyi.mongo",
            port = 27017,
            user = "netdoctor",
            password = "iqiyi.123",
            database = "netdoctor",
        },
        mysql = {
            enabled = false,
            host = "sjhl.netdoctor.w.qiyi.db",
            port = 8498,
            user = "netdoctor",
            password = "%ZjLUoTW",
            database = "netdoctor",
        },
    },
    redis = {
        host = "127.0.0.1",
        port = 6379,
        user = "root",
        password = "",
        dbindex  = 0,
    },
    kafka = {
        enabled = true,
        hosts = {
            {
                host = "hcdn-others-kafka-online001-bjdx.qiyi.virtual",
                port = 9092,
            },
            {
                host = "hcdn-others-kafka-online002-bjdx.qiyi.virtual",
                port = 9092,
            },
            {
                host = "hcdn-others-kafka-online003-bjdx.qiyi.virtual",
                port = 9092,
            },
        }
    },
}
