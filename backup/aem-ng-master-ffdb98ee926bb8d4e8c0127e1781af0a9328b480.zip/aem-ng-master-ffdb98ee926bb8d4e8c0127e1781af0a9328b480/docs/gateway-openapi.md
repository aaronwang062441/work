# AEM接口说明

<!-- vim-markdown-toc GFM -->
* [获取探测任务信息](#获取探测任务信息)
	* [接口描述](#接口描述)
	* [业务参数](#业务参数)
	* [返回参数](#返回参数)
	* [调用示例](#调用示例)
	* [响应示例](#响应示例)
* [获取服务器状态信息](#获取服务器状态信息)
	* [接口描述](#接口描述-1)
	* [业务参数](#业务参数-1)
	* [返回参数](#返回参数-1)
	* [调用示例](#调用示例-1)
	* [响应示例](#响应示例-1)
* [NetDoctor-SDK模拟故障数据投递](#netdoctor-sdk模拟故障数据投递)
	* [接口描述](#接口描述-2)
	* [业务参数](#业务参数-2)
	* [投递数据](#投递数据)
	* [返回参数](#返回参数-2)
	* [调用示例](#调用示例-2)
	* [响应示例](#响应示例-2)
* [NetDoctor-SDK现场故障数据投递](#netdoctor-sdk现场故障数据投递)
	* [接口描述](#接口描述-3)
	* [业务参数](#业务参数-3)
	* [投递数据](#投递数据-1)
	* [返回参数](#返回参数-3)
	* [调用示例](#调用示例-3)
	* [响应示例](#响应示例-3)
* [NetDoctor SDK探测结果投递](#netdoctor-sdk探测结果投递)
	* [接口描述](#接口描述-4)
	* [业务参数](#业务参数-4)
	* [投递数据](#投递数据-2)
	* [返回参数](#返回参数-4)
	* [调用示例](#调用示例-4)
	* [响应示例](#响应示例-4)
* [~~HCDN-SDK故障数据投递接口~~](#hcdn-sdk故障数据投递接口)
	* [接口描述](#接口描述-5)
	* [业务参数](#业务参数-5)
	* [投递数据](#投递数据-3)
	* [返回参数](#返回参数-5)
	* [调用示例](#调用示例-5)
	* [响应示例](#响应示例-5)
* [~~Puma-SDK故障数据投递~~](#puma-sdk故障数据投递)
	* [接口描述](#接口描述-6)
	* [业务参数](#业务参数-6)
	* [投递数据](#投递数据-4)
	* [返回参数](#返回参数-6)
	* [调用示例](#调用示例-6)
	* [响应示例](#响应示例-6)

<!-- vim-markdown-toc -->

## 获取探测任务信息

### 接口描述

| URL          | http://ndct-data.video.iqiyi.com/get_cmd |
|--------------+------------------------------------------|
| 功能描述     | 获取探测任务信息                         |
| 返回格式     | UTF8                                     |
| HTTP请求方式 | GET                                      |
| 当前接口版本 | v1                                       |
| 其它接口版本 | 无                                       |

### 业务参数

| 参数名 | 参数全称 | 必选  | 参数类型 | 参数描述        |
|--------+----------+-------+----------+-----------------|
| uid    | uid      | true  | String   | 用户的设备ID    |
| plat   | platform | true  | String   | 用户的设备平台  |
| ver    | version  | true  | String   | 用户的SDK版本号 |
| api    | api      | false | String   | 探测接口版本    |

### 返回参数

| 参数名         | 参数类型 | 允许为空 | 参数描述               |
|----------------+----------+----------+------------------------|
| version        | String   | false    | 探测接口版本           |
| data           | Array    | false    | 探测任务列表           |
| data.type      | Int      | false    | 探测任务的类型         |
| data.dns       | String   | false    | DNS探测任务的URL       |
| data.detection | String   | false    | HTTP探测任务的URL      |
| data.dload     | String   | false    | 下载探测任务的URL      |
| data.version   | String   | false    | 默认任务的升级版本控制 |
| data.auto_up   | String   | true     | 默认任务的升级标志     |
| data.dns_check | String   | true     | 默认任务的DNS检测标志  |
| data.platform  | String   | true     | 默认任务的生效平台     |

### 调用示例

```sh
curl -X GET --header "Content-Type: text/json" http://ndct-data.video.iqiyi.com/get_cmd&uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1025
```

### 响应示例

```
> GET /get_cmd?uid=aaaa&plat=1&ver=1.0&api=1 HTTP/1.1
> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.21 Basic ECC zlib/1.2.3 libidn/1.18 libssh2/1.4.2
> Host: 127.0.0.1
> Accept: */*
> Content-Type: text/json
>
< HTTP/1.1 200 OK
< Server: openresty/1.9.7.4
< Date: Tue, 28 Mar 2017 11:38:47 GMT
< Content-Type: text/html; charset=utf-8
< Connection: keep-alive
< Content-Length: 158
< Cache-Control: no-cache
<
{
  "version": "1.0",
  "data": [
    {
      "version": "1.0.2.0618|1.0.2.0710",
      "type": 0,
      "auto_up": "1",
      "dns_check": "0",
      "platform": "0"
    },
    {
      "type": 2,
      "dns": "viqiyi.admaster.com.cn"
    }
  ]
}
```

## 获取服务器状态信息

### 接口描述

| URL          | http://ndct-data.video.iqiyi.com/get_status |
|--------------+---------------------------------------------|
| 功能描述     | 获取服务器状态信息                          |
| 返回格式     | UTF8                                        |
| HTTP请求方式 | GET                                         |
| 当前接口版本 | v1                                          |
| 其它接口版本 | 无                                          |

### 业务参数

| 参数名 | 参数全称 | 必选 | 参数类型 | 参数描述             |
|--------+----------+------+----------+----------------------|
| key    | key      | n/a  | String   | 请求次数接口关键字   |
| group  | group    | n/a  | String   | 指定查询状态信息组名 |

### 返回参数

| 参数名            | 参数类型 | 允许为空 | 参数描述                     |
|-------------------+----------+----------+------------------------------|
| get_cmd:command:* | Int      | false    | 对应的探测任务下发的数量     |
| *:request:total   | Int      | false    | 对应的接口请求次数的总量     |
| *;request:valid   | Int      | false    | 对应的接口请求次数的有效数量 |
|

### 调用示例

```sh
curl -H "Content-Type: text/json" -X GET http://ndct-data.video.iqyi.com/get_status?key=all
```

### 响应示例

```
> GET /get_status?key=all HTTP/1.1
> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.13.6.0 zlib/1.2.3 libidn/1.18 libssh2/1.4.2
> Host: 127.0.0.1
> Accept: */*
> Content-Type: text/json
>
< Server: openresty/1.9.7.4
< Date: Thu, 30 Mar 2017 10:13:55 GMT
< Content-Type: text/html; charset=utf-8
< Connection: close
< Cache-Control: no-cache
<
{
    "get_cmd:command:58da1e4eb29edb6898894d29": 368,
    "get_cmd:command:58da1e4eb29edb6898894d2a": 2108,
    "get_cmd:command:58da1e4eb29edb6898894d2b": 2811,
    "get_cmd:command:58da1e4eb29edb6898894d2c": 700,
    "get_cmd:command:58da1e4eb29edb6898894d2d": 1340,
    "get_cmd:command:58da1e4eb29edb6898894d2e": 1804,
    "get_cmd:command:58da1e4eb29edb6898894d2f": 460,
    "get_cmd:command:58da1e4eb29edb6898894d32": 504,
    "get_cmd:command:58da1e4eb29edb6898894d33": 504,
    "get_cmd:command:58da1e4eb29edb6898894d3b": 628,
    "get_cmd:command:58da1e4eb29edb6898894d3c": 628,
    "get_cmd:command:58da1e4eb29edb6898894d3e": 616,
    "get_cmd:command:58da1e4eb29edb6898894d3f": 616,
    "get_cmd:command:58da1e4eb29edb6898894d42": 528,
    "get_cmd:command:58da1e4eb29edb6898894d43": 528,
    "get_cmd:command:58da1e4eb29edb6898894d47": 540,
    "get_cmd:command:58da1e4eb29edb6898894d48": 1226,
    "get_cmd:command:58da1e4eb29edb6898894d49": 684,
    "get_cmd:command:58da1e4eb29edb6898894d4a": 1364,
    "get_cmd:command:58da1e4eb29edb6898894d4b": 1367,
    "get_cmd:command:58da1e4eb29edb6898894d4c": 843,
    "get_cmd:command:58da1e4eb29edb6898894d4d": 840,
    "get_cmd:command:58da1e4eb29edb6898894d4e": 686,
    "get_cmd:command:58da1e4eb29edb6898894d4f": 688,
    "get_cmd:command:58da1e4fb29edb6898894d50": 540,
    "get_cmd:command:58da1e4fb29edb6898894d51": 1080,
    "get_cmd:command:58da1e4fb29edb6898894d52": 1124,
    "get_cmd:command:58da1e4fb29edb6898894d53": 584,
    "get_cmd:command:58da1e4fb29edb6898894d55": 580,
    "get_cmd:command:58da1e4fb29edb6898894d56": 1090,
    "get_cmd:command:58da1e4fb29edb6898894d57": 512,
    "get_cmd:command:58da1e4fb29edb6898894d59": 368,
    "get_cmd:command:total": 28259,
    "get_cmd:request:total": 425138,
    "get_cmd:request:valid": 418330,
    "get_status:request:total": 6,
    "send_core_info:request:total": 1349,
    "send_hcdn_info:request:total": 13123,
    "send_pingback:request:total": 26183,
    "send_pingback:request:valid": 26183,
    "send_stuckinfo:request:total": 9161,
    "send_stuckinfo:request:valid": 9160
}
```

## NetDoctor-SDK模拟故障数据投递

### 接口描述

| URL          | http://ndct-data.video.iqiyi.com/send_stuckinfo |
|--------------+-------------------------------------------------|
| 功能描述     | NetDoctor SDK模拟故障数据投递接口               |
| 返回格式     | UTF8                                            |
| HTTP请求方式 | POST                                            |
| 当前接口版本 | v1                                              |
| 其它接口版本 | 无                                              |

### 业务参数

| 参数名 | 参数全称 | 必选 | 参数类型 | 参数描述        |
|--------+----------+------+----------+-----------------|
| uid    | uid      | true | String   | 用户的设备ID    |
| plat   | platform | true | String   | 用户的设备平台  |
| ver    | version  | true | String   | 用户的SDK版本号 |

### 投递数据

```json
{
    "play_result": {
        "timeout": 0,
        "version": "1.0.10.1205",
        "version_puma": "3.3.4.611",
        "version_app": "5.5.33.3550",
        "vip_res": 0,
        "vip_user": 1,
        "qyid": "adqeyjh4yhpwelsb7t7fxvcw2usimqht",
        "app_errcode": 0,
        "sgti": "sssssgggggtttttiiiii",
        "vid": "a5973c0475aa434fb522eb49bf86b981",
        "tvid": "380677700",
        "aid": "202817101",
        "bid": "2",
        "file_tpye": "F4V",
        "rate": 110,
        "timepoint": 0,
        "network_duration": 63,
        "vip_duration": 0,
        "auth_succ": 1,
        "step": 22,
        "access_vrs": {
            "timestamp": "1483952337312",
            "url": "http://cache.video.qiyi.com/vps?tvid=380677700&vid=a5973c0475aa434fb522eb49bf86b981&v=1&uid=1218211270&k_uid=adqeyjh4yhpwelsb7t7fxvcw2usimqht&src=01012001010000000000&t=1483952337213&k_ver=5.5.33.3550&k_from=5&k_tag=1&vf=99e08522a7d7a5e3914186b7cdc957b2",
            "code": 200,
            "duration": 15,
            "ip": "123.125.111.100",
            "return_data": ""
        },
        "access_pdata": {
            "url": "http://data.video.qiyi.com/videos/v0/20160202/de/dc/aed9d2b044bdc13efe8bcd07b5da1358.f4v?qd_tvid=380677700&qd_vipres=0&qd_index=1&qd_aid=202817101&qd_stert=0&qd_scc=5cc30d588ae21759643cdea619900d72&qd_sc=9f001a043380a9cbd250c95040b03c86&qd_ip=ca6c0ef0&qd_k=99e08522a7d7a5e3914186b7cdc957b2&qd_src=01012001010000000000&qd_vipdyn=0&qd_uid=1218211270&qd_tm=1483952337238&qd_vip=1&qypid=adqeyjh4yhpwelsb7t7fxvcw2usimqht",
            "ip": "111.206.13.224",
            "return_data": "eyJ0IjoiQ05DfFFpWWktMjAyLjEwOC4xNC4yNDAiLCJoIjoiLTU3IiwibCI6Imh0dHA6Ly8xMTEuMjA2LjIzLjEzOS92aWRlb3MvdjAvMjAxNjAyMDIvZGUvZGMvYWVkOWQyYjA0NGJkYzEzZWZlOGJjZDA3YjVkYTEzNTguZjR2P2tleT0wYjhkNjIyMDdmNmVlNWI3OGRhYmRhZjViZjEyMDMxZTImZGlzX2s9NjRmYzk4ZjFiOWI0ZDcwMzcxYTY5OGIyODY1YTI2ODEmZGlzX3Q9MTQ4Mzk1MjMzNyZzcmM9aXFpeWkuY29tJnFkX3R2aWQ9MzgwNjc3NzAwJnFkX3ZpcHJlcz0wJnFkX2luZGV4PTEmcWRfYWlkPTIwMjgxNzEwMSZxZF9zdGVydD0wJnFkX3NjYz01Y2MzMGQ1ODhhZTIxNzU5NjQzY2RlYTYxOTkwMGQ3MiZxZF9zYz05ZjAwMWEwNDMzODBhOWNiZDI1MGM5NTA0MGIwM2M4NiZxZF9pcD1jYTZjMGVmMCZxZF9rPTk5ZTA4NTIyYTdkN2E1ZTM5MTQxODZiN2NkYzk1N2IyJnFkX3NyYz0wMTAxMjAwMTAxMDAwMDAwMDAwMCZxZF92aXBkeW49MCZxZF91aWQ9MTIxODIxMTI3MCZxZF90bT0xNDgzOTUyMzM3MjM4JnFkX3ZpcD0xJnF5cGlkPWFkcWV5amg0eWhwd2Vsc2I3dDdmeHZjdzJ1c2ltcWh0JnV1aWQ9Y2E2YzBlZjAtNTg3MzUwZDEtNzkiLCJ6IjoiYmVpamluZzRfY25jIn0=",
            "code": 200,
            "duration": 0
        },
        "access_vip": {
            "url": "",
            "ip": "",
            "return_data": "",
            "duration": 0
        },
        "cache_status": {
            "host": "111.206.23.139",
            "url": "http://111.206.23.139/videos/v0/20160202/de/dc/aed9d2b044bdc13efe8bcd07b5da1358.f4v?key=0b8d62207f6ee5b78dabdaf5bf12031e2&dis_k=64fc98f1b9b4d70371a698b2865a2681&dis_t=1483952337&src=iqiyi.com&qd_tvid=380677700&qd_vipres=0&qd_index=1&qd_aid=202817101&qd_stert=0&qd_scc=5cc30d588ae21759643cdea619900d72&qd_sc=9f001a043380a9cbd250c95040b03c86&qd_ip=ca6c0ef0&qd_k=99e08522a7d7a5e3914186b7cdc957b2&qd_src=01012001010000000000&qd_vipdyn=0&qd_uid=1218211270&qd_tm=1483952337238&qd_vip=1&qypid=adqeyjh4yhpwelsb7t7fxvcw2usimqht&uuid=ca6c0ef0-587350d1-79",
            "code": 200,
            "duration": 0,
            "conn_duration": 15,
            "avg_speed": 8146,
            "max_speed": 8727,
            "ping": {
                "req_cnt": 0,
                "lost_cnt": 0,
                "lost_rate": 0,
                "avg_rtt": 0,
                "max_rtt": 0,
                "min_rtt": 0,
                "dst": ""
            },
            "tracert": {
                "dst": "",
                "hop_list": []
            }
        }
    },
    "dns_result": {
        "timeout": 0,
        "duration": 172,
        "netdoc": {
            "LDNSIP": [
                "10.11.50.65",
                "10.11.50.66"
            ]
        },
        "dnslab": {
            "version": "2.0",
            "ID": "appxxnode2xx545a46d8ada8a",
            "LDSERVERIP": "10.35.50.136",
            "UEIP": "202.108.14.240",
            "UE_AREA": "CNC_QiYi",
            "LDNSIP": "202.108.14.56",
            "LDNS_AREA": "CNC_QiYi",
            "UA": "netdoc",
            "X_Forward_For": "none",
            "SCache_RA": "202.108.14.240",
            "SCache_RA_AREA": "CNC_QiYi",
            "SCache_SA": "111.206.13.64",
            "SCache_SA_IDC": "beijing2_cnc",
            "SCache_RTT": "104",
            "SCache_RTTVAR": "135"
        }
    }
}
```

### 返回参数

无

### 调用示例

```sh
curl -X POST -d @data --header "Content-Type:text/json" http://ndct-data.video.iqiyi.com?send_stuckinfo?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205
```

### 响应示例

```
> POST /send_stuckinfo?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205 HTTP/1.1
> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.21 Basic ECC zlib/1.2.3 libidn/1.18 libssh2/1.4.2
> Host: ndct-data.video.iqiyi.com
> Accept: */*
> Content-Type: text/json
> Content-Length: 4492
> Expect: 100-continue
>
< HTTP/1.1 100 Continue
< HTTP/1.1 200 OK
< Server: openresty/1.9.7.4
< Date: Tue, 28 Mar 2017 10:12:08 GMT
< Content-Type: text/html; charset=utf-8
< Connection: keep-alive
< Content-Length: 0
< Cache-Control: no-cache
```

## NetDoctor-SDK现场故障数据投递

### 接口描述

| URL          | http://ndct-data.video.iqiyi.com/send_scene_info |
|--------------+--------------------------------------------------|
| 功能描述     | NetDoctor SDK现场故障数据投递接口                |
| 返回格式     | UTF8                                             |
| HTTP请求方式 | POST                                             |
| 当前接口版本 | v1                                               |
| 其它接口版本 | 无                                               |

### 业务参数

| 参数名    | 参数全称  | 必选 | 参数类型 | 参数描述           |
|-----------+-----------+------+----------+--------------------|
| uid       | uid       | true | String   | 用户的设备ID       |
| plat      | platform  | true | String   | 用户的设备平台     |
| ver       | version   | true | String   | 用户的SDK版本号    |
| timestamp | timeStamp | true | String   | 故障发生时的时间戳 |
| from      | from      | true | String   | 故障数据的来源     |

### 投递数据

```json
{
  "fly_data": {
    "puma": {
      "common": {
        "app_version": "3.0.1111111111",
        "puma_version": "3.9.1",
        "puma_error_code": "0",
        "qyid": "asn272"
      },
      "video": {
        "file_type": "F4V",
        "aid": "154825",
        "tvid": "166995",
        "vid": "e6a2166206709ba15600ebd1cc0d5cb6",
        "bid": "5",
        "vip_res": "0"
      },
      "user": {
        "vip_user": "0",
        "uid": ""
      },
      "vrs": {
        "vrs_req_mode": "1",
        "vrs_start_time": "1488880564255",
        "vrs_url": "http://cache.video.iqiyi.com/vps?tvid=166995&vid=b5ad13a9d8da984e9546774e367c1e03&v=0&qypid=166995_unknown&src=01012001020000000000&t=1488880564000&k_tag=1&k_uid=asn272&bid=5&pt=0&d=1&s=0&rs=1&k_ft1=167&vf=fed5d071b097f30af58376b2f31cd83e",
        "vrs_dns_server_ip": "1",
        "vrs_ip": "123.125.111.100",
        "vrs_first_status": "200",
        "vrs_dns_start_tick": "-1",
        "vrs_dns_end_tick": "-1",
        "vrs_conn_start_tick": "-1",
        "vrs_conn_establish_tick": "-1",
        "vrs_recv_header_tick": "61",
        "vrs_recv_data_tick": "40",
        "vrs_302_url": "",
        "vrs_302_ip": "",
        "vrs_last_status": "",
        "vrs_return_length": "37996",
        "vrs_return_code": "A00000",
        "vrs_return_st": "101",
        "vrs_return_boss_status": "",
        "vrs_return_timestamp": "55889748312"
      },
      "boss": {
        "boss_start_time": "",
        "boss_url": "",
        "boss_dns_server_ip": "",
        "boss_ip": "",
        "boss_first_status": "",
        "boss_dns_start_tick": "-1",
        "boss_dns_end_tick": "-1",
        "boss_conn_start_tick": "-1",
        "boss_conn_establish_tick": "-1",
        "boss_recv_header_tick": "-1",
        "boss_recv_data_tick": "-1",
        "boss_302_url": "",
        "boss_302_ip": "",
        "boss_last_status": "",
        "boss_return_length": "",
        "boss_return_code": "",
        "boss_return_data": ""
      }
    },
    "hcdn": {
      "boss": {
        "boss_302_ip": "",
        "boss_302_url": "",
        "boss_conn_establish_tick": "-1",
        "boss_conn_start_tick": "-1",
        "boss_dns_end_tick": "-1",
        "boss_dns_server_ip": "",
        "boss_dns_start_tick": "-1",
        "boss_first_status": "",
        "boss_ip": "",
        "boss_last_status": "",
        "boss_recv_data_tick": "-1",
        "boss_recv_header_tick": "-1",
        "boss_return_code": "",
        "boss_return_data": "",
        "boss_return_length": "",
        "boss_start_time": "",
        "boss_url": ""
      },
      "cache": {
        "cache_302_ip": "",
        "cache_302_url": "",
        "cache_avg_speed": "",
        "cache_conn_establish_tick": "-1",
        "cache_conn_start_tick": "-1",
        "cache_first_status": "",
        "cache_idc": "beijing4_cnc",
        "cache_ip": "",
        "cache_last_status": "",
        "cache_recv_data_tick": "-1",
        "cache_recv_header_tick": "-1",
        "cache_sample_data": "",
        "cache_sample_offset": "",
        "cache_start_time": "1488881485347",
        "cache_url": "http://111.206.23.142/videos/v0/20161226/06/6d/8a4ab3fc0714f3e57abdc4c1eaf57287.f4v?key=0000d2cd39a6edfed2c4d76ad0618d010&dis_k=af1ebcd4a23d0e07b9a5edc6fc4af1dd&dis_t=1488881481&src=iqiyi.com&qd_tvid=106699500&qd_vipres=0&qd_index=3&qd_aid=106699500&qd_stert=720634&qd_scc=7856c5c706ba28d11e0482909122a6cc&qd_sc=7765c9055397a43e799d3da1a00067cb&qd_ip=ca6c0ef0&qd_k=fed5d071b097f30af58376b2f31cd83e&qd_src=01012001020000000000&qd_vipdyn=0&qd_uid=0&qd_tm=1488880566981&qd_vip=0&qyid=asn272&qypid=&la=CNC|QiYi&li=beijing3_cnc&lsp=43&lc=15&uuid=ca6c0ef0-58be8749-76"
      },
      "common": {
        "app_version": "0.0.0.0",
        "hcdn_error_code": "0",
        "hcdn_version": "10.0.1.425",
        "qyid": "asn272"
      },
      "disp": {
        "disp_302_ip": "",
        "disp_302_url": "",
        "disp_conn_establish_tick": "9",
        "disp_conn_start_tick": "0",
        "disp_dns_end_tick": "-1",
        "disp_dns_server_ip": "10.11.50.65;10.11.50.66",
        "disp_dns_start_tick": "-1",
        "disp_first_status": "200",
        "disp_ip": "111.206.13.221",
        "disp_last_status": "",
        "disp_recv_data_tick": "11",
        "disp_recv_header_tick": "11",
        "disp_return_data": "eyJ0IjoiQ05DfFFpWWktMjAyLjEwOC4xNC4yNDAiLCJoIjoiLTg5IiwibCI6Imh0dHA6Ly8xMTEuMjA2LjIzLjE0Mi92aWRlb3MvdjAvMjAxNjEyMjYvMDYvNmQvOGE0YWIzZmMwNzE0ZjNlNTdhYmRjNGMxZWFmNTcyODcuZjR2P2tleT0wMDAwZDJjZDM5YTZlZGZlZDJjNGQ3NmFkMDYxOGQwMTAmZGlzX2s9YWYxZWJjZDRhMjNkMGUwN2I5YTVlZGM2ZmM0YWYxZGQmZGlzX3Q9MTQ4ODg4MTQ4MSZzcmM9aXFpeWkuY29tJnFkX3R2aWQ9MTA2Njk5NTAwJnFkX3ZpcHJlcz0wJnFkX2luZGV4PTMmcWRfYWlkPTEwNjY5OTUwMCZxZF9zdGVydD03MjA2MzQmcWRfc2NjPTc4NTZjNWM3MDZiYTI4ZDExZTA0ODI5MDkxMjJhNmNjJnFkX3NjPTc3NjVjOTA1NTM5N2E0M2U3OTlkM2RhMWEwMDA2N2NiJnFkX2lwPWNhNmMwZWYwJnFkX2s9ZmVkNWQwNzFiMDk3ZjMwYWY1ODM3NmIyZjMxY2Q4M2UmcWRfc3JjPTAxMDEyMDAxMDIwMDAwMDAwMDAwJnFkX3ZpcGR5bj0wJnFkX3VpZD0wJnFkX3RtPTE0ODg4ODA1NjY5ODEmcWRfdmlwPTAmcXlpZD1hc24yNzImcXlwaWQ9JmxhPUNOQ3xRaVlpJmxpPWJlaWppbmczX2NuYyZsc3A9NDMmbGM9MTUmdXVpZD1jYTZjMGVmMC01OGJlODc0OS03NiIsInoiOiJiZWlqaW5nNF9jbmMifQ==",
        "disp_return_length": "628",
        "disp_start_time": "1488881479324",
        "disp_url": "http://data.video.qiyi.com/videos/v0/20161226/06/6d/8a4ab3fc0714f3e57abdc4c1eaf57287.f4v?qd_tvid=106699500&qd_vipres=0&qd_index=3&qd_aid=106699500&qd_stert=720634&qd_scc=7856c5c706ba28d11e0482909122a6cc&qd_sc=7765c9055397a43e799d3da1a00067cb&qd_ip=ca6c0ef0&qd_k=fed5d071b097f30af58376b2f31cd83e&qd_src=01012001020000000000&qd_vipdyn=0&qd_uid=0&qd_tm=1488880566981&qd_vip=0&qyid=asn272&qypid=&la=CNC|QiYi&li=beijing3_cnc&lsp=43&lc=15"
      },
      "record": {
        "count": "5",
        "index1": {
          "disp_302_ip": "",
          "disp_302_url": "",
          "disp_conn_establish_tick": "4",
          "disp_conn_start_tick": "1",
          "disp_dns_end_tick": "-1",
          "disp_dns_server_ip": "10.11.50.65;10.11.50.66",
          "disp_dns_start_tick": "-1",
          "disp_first_status": "200",
          "disp_ip": "111.206.13.225",
          "disp_last_status": "",
          "disp_recv_data_tick": "6",
          "disp_recv_header_tick": "6",
          "disp_return_data": "eyJ0IjoiQ05DfFFpWWktMjAyLjEwOC4xNC4yNDAiLCJoIjoiLTQxIiwibCI6Imh0dHA6Ly8xMTEuMjA2LjIzLjgvdmlkZW9zL3YwLzIwMTYxMjI2LzA2LzZkLzhhNGFiM2ZjMDcxNGYzZTU3YWJkYzRjMWVhZjU3Mjg3LmY0dj9rZXk9MDAwMGQyY2QzOWE2ZWRmZWQ0YjFiNTIzZTQwZmI3NTg1JmRpc19rPWY4NTQ4NjllNzhmNzE3ZjFkYmMyNGY3YTMwZDM2ZGUzJmRpc190PTE0ODg4ODEwMDYmc3JjPWlxaXlpLmNvbSZxZF90dmlkPTEwNjY5OTUwMCZxZF92aXByZXM9MCZxZF9pbmRleD0zJnFkX2FpZD0xMDY2OTk1MDAmcWRfc3RlcnQ9NzIwNjM0JnFkX3NjYz03ODU2YzVjNzA2YmEyOGQxMWUwNDgyOTA5MTIyYTZjYyZxZF9zYz03NzY1YzkwNTUzOTdhNDNlNzk5ZDNkYTFhMDAwNjdjYiZxZF9pcD1jYTZjMGVmMCZxZF9rPWZlZDVkMDcxYjA5N2YzMGFmNTgzNzZiMmYzMWNkODNlJnFkX3NyYz0wMTAxMjAwMTAyMDAwMDAwMDAwMCZxZF92aXBkeW49MCZxZF91aWQ9MCZxZF90bT0xNDg4ODgwNTY2OTgxJnFkX3ZpcD0wJnF5aWQ9YXNuMjcyJnF5cGlkPSZsYT1DTkN8UWlZaSZsaT1iZWlqaW5nM19jbmMmbHNwPTQzJmxjPTE1JnV1aWQ9Y2E2YzBlZjAtNThiZTg1NmUtN2EiLCJ6IjoiYmVpamluZzNfY25jIn0=",
          "disp_return_length": "626",
          "disp_start_time": "1488881004149",
          "disp_url": "http://data.video.qiyi.com/videos/v0/20161226/06/6d/8a4ab3fc0714f3e57abdc4c1eaf57287.f4v?qd_tvid=106699500&qd_vipres=0&qd_index=3&qd_aid=106699500&qd_stert=720634&qd_scc=7856c5c706ba28d11e0482909122a6cc&qd_sc=7765c9055397a43e799d3da1a00067cb&qd_ip=ca6c0ef0&qd_k=fed5d071b097f30af58376b2f31cd83e&qd_src=01012001020000000000&qd_vipdyn=0&qd_uid=0&qd_tm=1488880566981&qd_vip=0&qyid=asn272&qypid=&la=CNC|QiYi&li=beijing3_cnc&lsp=43&lc=15"
        },
        "index2": {
          "disp_302_ip": "",
          "disp_302_url": "",
          "disp_conn_establish_tick": "9",
          "disp_conn_start_tick": "0",
          "disp_dns_end_tick": "-1",
          "disp_dns_server_ip": "10.11.50.65;10.11.50.66",
          "disp_dns_start_tick": "-1",
          "disp_first_status": "200",
          "disp_ip": "111.206.13.221",
          "disp_last_status": "",
          "disp_recv_data_tick": "11",
          "disp_recv_header_tick": "11",
          "disp_return_data": "eyJ0IjoiQ05DfFFpWWktMjAyLjEwOC4xNC4yNDAiLCJoIjoiLTg5IiwibCI6Imh0dHA6Ly8xMTEuMjA2LjIzLjE0Mi92aWRlb3MvdjAvMjAxNjEyMjYvMDYvNmQvOGE0YWIzZmMwNzE0ZjNlNTdhYmRjNGMxZWFmNTcyODcuZjR2P2tleT0wMDAwZDJjZDM5YTZlZGZlZDJjNGQ3NmFkMDYxOGQwMTAmZGlzX2s9YWYxZWJjZDRhMjNkMGUwN2I5YTVlZGM2ZmM0YWYxZGQmZGlzX3Q9MTQ4ODg4MTQ4MSZzcmM9aXFpeWkuY29tJnFkX3R2aWQ9MTA2Njk5NTAwJnFkX3ZpcHJlcz0wJnFkX2luZGV4PTMmcWRfYWlkPTEwNjY5OTUwMCZxZF9zdGVydD03MjA2MzQmcWRfc2NjPTc4NTZjNWM3MDZiYTI4ZDExZTA0ODI5MDkxMjJhNmNjJnFkX3NjPTc3NjVjOTA1NTM5N2E0M2U3OTlkM2RhMWEwMDA2N2NiJnFkX2lwPWNhNmMwZWYwJnFkX2s9ZmVkNWQwNzFiMDk3ZjMwYWY1ODM3NmIyZjMxY2Q4M2UmcWRfc3JjPTAxMDEyMDAxMDIwMDAwMDAwMDAwJnFkX3ZpcGR5bj0wJnFkX3VpZD0wJnFkX3RtPTE0ODg4ODA1NjY5ODEmcWRfdmlwPTAmcXlpZD1hc24yNzImcXlwaWQ9JmxhPUNOQ3xRaVlpJmxpPWJlaWppbmczX2NuYyZsc3A9NDMmbGM9MTUmdXVpZD1jYTZjMGVmMC01OGJlODc0OS03NiIsInoiOiJiZWlqaW5nNF9jbmMifQ==",
          "disp_return_length": "628",
          "disp_start_time": "1488881479324",
          "disp_url": "http://data.video.qiyi.com/videos/v0/20161226/06/6d/8a4ab3fc0714f3e57abdc4c1eaf57287.f4v?qd_tvid=106699500&qd_vipres=0&qd_index=3&qd_aid=106699500&qd_stert=720634&qd_scc=7856c5c706ba28d11e0482909122a6cc&qd_sc=7765c9055397a43e799d3da1a00067cb&qd_ip=ca6c0ef0&qd_k=fed5d071b097f30af58376b2f31cd83e&qd_src=01012001020000000000&qd_vipdyn=0&qd_uid=0&qd_tm=1488880566981&qd_vip=0&qyid=asn272&qypid=&la=CNC|QiYi&li=beijing3_cnc&lsp=43&lc=15"
        },
        "index3": {
          "cache_302_ip": "",
          "cache_302_url": "",
          "cache_avg_speed": "",
          "cache_conn_establish_tick": "2",
          "cache_conn_start_tick": "0",
          "cache_first_status": "0",
          "cache_idc": "beijing4_cnc",
          "cache_ip": "111.206.23.142",
          "cache_last_status": "",
          "cache_recv_data_tick": "-1",
          "cache_recv_header_tick": "-1",
          "cache_sample_data": "",
          "cache_sample_offset": "",
          "cache_start_time": "1488881479336",
          "cache_url": "http://111.206.23.142/videos/v0/20161226/06/6d/8a4ab3fc0714f3e57abdc4c1eaf57287.f4v?key=0000d2cd39a6edfed2c4d76ad0618d010&dis_k=af1ebcd4a23d0e07b9a5edc6fc4af1dd&dis_t=1488881481&src=iqiyi.com&qd_tvid=106699500&qd_vipres=0&qd_index=3&qd_aid=106699500&qd_stert=720634&qd_scc=7856c5c706ba28d11e0482909122a6cc&qd_sc=7765c9055397a43e799d3da1a00067cb&qd_ip=ca6c0ef0&qd_k=fed5d071b097f30af58376b2f31cd83e&qd_src=01012001020000000000&qd_vipdyn=0&qd_uid=0&qd_tm=1488880566981&qd_vip=0&qyid=asn272&qypid=&la=CNC|QiYi&li=beijing3_cnc&lsp=43&lc=15&uuid=ca6c0ef0-58be8749-76"
        },
        "index4": {
          "cache_302_ip": "",
          "cache_302_url": "",
          "cache_avg_speed": "",
          "cache_conn_establish_tick": "6",
          "cache_conn_start_tick": "0",
          "cache_first_status": "0",
          "cache_idc": "beijing4_cnc",
          "cache_ip": "111.206.23.142",
          "cache_last_status": "",
          "cache_recv_data_tick": "-1",
          "cache_recv_header_tick": "-1",
          "cache_sample_data": "",
          "cache_sample_offset": "",
          "cache_start_time": "1488881482339",
          "cache_url": "http://111.206.23.142/videos/v0/20161226/06/6d/8a4ab3fc0714f3e57abdc4c1eaf57287.f4v?key=0000d2cd39a6edfed2c4d76ad0618d010&dis_k=af1ebcd4a23d0e07b9a5edc6fc4af1dd&dis_t=1488881481&src=iqiyi.com&qd_tvid=106699500&qd_vipres=0&qd_index=3&qd_aid=106699500&qd_stert=720634&qd_scc=7856c5c706ba28d11e0482909122a6cc&qd_sc=7765c9055397a43e799d3da1a00067cb&qd_ip=ca6c0ef0&qd_k=fed5d071b097f30af58376b2f31cd83e&qd_src=01012001020000000000&qd_vipdyn=0&qd_uid=0&qd_tm=1488880566981&qd_vip=0&qyid=asn272&qypid=&la=CNC|QiYi&li=beijing3_cnc&lsp=43&lc=15&uuid=ca6c0ef0-58be8749-76"
        },
        "index5": {
          "cache_302_ip": "",
          "cache_302_url": "",
          "cache_avg_speed": "",
          "cache_conn_establish_tick": "-1",
          "cache_conn_start_tick": "-1",
          "cache_first_status": "",
          "cache_idc": "beijing4_cnc",
          "cache_ip": "",
          "cache_last_status": "",
          "cache_recv_data_tick": "-1",
          "cache_recv_header_tick": "-1",
          "cache_sample_data": "",
          "cache_sample_offset": "",
          "cache_start_time": "1488881485347",
          "cache_url": "http://111.206.23.142/videos/v0/20161226/06/6d/8a4ab3fc0714f3e57abdc4c1eaf57287.f4v?key=0000d2cd39a6edfed2c4d76ad0618d010&dis_k=af1ebcd4a23d0e07b9a5edc6fc4af1dd&dis_t=1488881481&src=iqiyi.com&qd_tvid=106699500&qd_vipres=0&qd_index=3&qd_aid=106699500&qd_stert=720634&qd_scc=7856c5c706ba28d11e0482909122a6cc&qd_sc=7765c9055397a43e799d3da1a00067cb&qd_ip=ca6c0ef0&qd_k=fed5d071b097f30af58376b2f31cd83e&qd_src=01012001020000000000&qd_vipdyn=0&qd_uid=0&qd_tm=1488880566981&qd_vip=0&qyid=asn272&qypid=&la=CNC|QiYi&li=beijing3_cnc&lsp=43&lc=15&uuid=ca6c0ef0-58be8749-76"
        }
      },
      "user": {
        "uid": "0",
        "vip_user": "0"
      },
      "video": {
        "aid": "166995",
        "file_type": "F4V",
        "rid": "8a4ab3fc0714f3e57abdc4c1eaf57287",
        "tvid": "166995",
        "vid": "e6a2166206709ba15600ebd1cc0d5cb6",
        "vip_res": "0"
      }
    }
  },
  "dns_result": {
    "timeout": 0,
    "duration": 1138,
    "netdoc": {
      "LDNSIP": [
        "10.11.50.65",
        "10.11.50.66"
      ]
    },
    "dnslab": {
      "version": "2.0",
      "ID": "appxxnode4xx54a213c2988c9",
      "LDSERVERIP": "10.35.50.135",
      "UEIP": "202.108.14.240",
      "UE_AREA": "CNC_QiYi",
      "LDNSIP": "123.125.7.21",
      "LDNS_AREA": "CNC_BeiJing",
      "UA": "netdoc",
      "X_Forward_For": "none",
      "SCache_RA": "202.108.14.240",
      "SCache_RA_AREA": "CNC_QiYi",
      "SCache_SA": "111.206.13.65",
      "SCache_SA_IDC": "beijing2_cnc",
      "SCache_RTT": "186",
      "SCache_RTTVAR": "121"
    }
  }
}
```

### 返回参数

无

### 调用示例

```sh
curl -X POST -d @data --header "Content-Type:text/json" http://ndct-data.video.iqiyi.com?send_scene_info?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205&timestamp=1490698138&from=hcdn
```

### 响应示例

```
> POST /send_scene_info?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205&timestamp=14888888&from=hcdn HTTP/1.1
> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.21 Basic ECC zlib/1.2.3 libidn/1.18 libssh2/1.4.2
> Host: 127.0.0.1
> Accept: */*
> Content-Type: text/json
> Content-Length: 13688
> Expect: 100-continue
>
< HTTP/1.1 100 Continue
< HTTP/1.1 200 OK
< Server: openresty/1.9.7.4
< Date: Tue, 28 Mar 2017 10:51:20 GMT
< Content-Type: text/html; charset=utf-8
< Connection: keep-alive
< Content-Length: 0
< Cache-Control: no-cache
```

## NetDoctor SDK探测结果投递

### 接口描述

| URL          | http://ndct-data.video.iqiyi.com/send_pingback  |
|--------------+-------------------------------------------------|
| 功能描述     | NetDoctor SDK探测结果投递接口                   |
| 返回格式     | UTF8                                            |
| HTTP请求方式 | POST                                            |
| 当前接口版本 | v1                                              |
| 其它接口版本 | 无                                              |

### 业务参数

| 参数名 | 参数全称 | 必选 | 参数类型 | 参数描述         |
|--------+----------+------+----------+------------------|
| uid    | uid      | true | String   | 用户的设备ID     |
| plat   | platform | true | String   | 用户的设备平台   |
| ver    | version  | true | String   | 用户的SDK版本号  |
| type   | type     | true | String   | 用户探测任务类型 |

### 投递数据

```json
{
    "dns_result" : {
        "data" : [{
            "httpdnsServer" : "36.110.220.216",
            "url" : "flux.hcdn.qiyi.com",
            "ip" : "101.227.12.96",
            "httpdnsClient" : "182.86.207.60",
            "httpdnsTime" : "76",
            "uLDNSIP" : "192.168.31.1",
            "rLDNSIP" : "",
            "httpdnsIp" : "101.227.12.96",
            "httpdnsCache" : "0"
        }],
        "version" : "2.0",
        "type" : 2
    }
}
```

### 返回参数

无

### 调用示例

```sh
curl -X POST -d @data --header "Content-Type:text/json" http://ndct-data.video.iqiyi.com?send_pingback?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205
```

### 响应示例

```
> POST /send_pingback?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205 HTTP/1.1
> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.21 Basic ECC zlib/1.2.3 libidn/1.18 libssh2/1.4.2
> Host: 127.0.0.1
> Accept: */*
> Content-Type: text/json
> Content-Length: 443
>
< HTTP/1.1 200 OK
< Server: openresty/1.9.7.4
< Date: Tue, 28 Mar 2017 10:51:20 GMT
< Content-Type: text/html; charset=utf-8
< Connection: keep-alive
< Content-Length: 0
< Cache-Control: no-cache
```

## ~~HCDN-SDK故障数据投递接口~~

**已废弃**

### 接口描述

| URL          | http://ndct-data.video.iqiyi.com/send_hcdn_info |
|--------------+-------------------------------------------------|
| 功能描述     | NetDoctor SDK模拟故障数据投递接口               |
| 返回格式     | UTF8                                            |
| HTTP请求方式 | GET                                             |
| 当前接口版本 | v1                                              |
| 其它接口版本 | 无                                              |

### 业务参数

| 参数名 | 参数全称 | 必选 | 参数类型 | 参数描述        |
|--------+----------+------+----------+-----------------|
| uid    | uid      | true | String   | 用户的设备ID    |
| plat   | platform | true | String   | 用户的设备平台  |
| ver    | version  | true | String   | 用户的SDK版本号 |

### 投递数据

```json
{
  "pform": "3",
  "play_process": {
    "access_pdata": {
      "code": 200,
      "duration": 29,
      "ip": "59.38.101.57",
      "return_data": "",
      "url": "http://pdata.video.ptqy.gitv.tv/5ce1efe76aa5151dc63126a124d7ad2e/videos/v0/20170117/64/e1/7487137bdf4d9a469d923777f4ee82d2.f4v?qyid=9d2d465364a622396e2e5642f768fc6a&qypid=-39201"
    },
    "access_vip": "",
    "cache_status": {
      "302url": "",
      "avgspeed": 61,
      "code": 206,
      "duration": 34,
      "idc": "",
      "url": "http://ksctcdn.inter.ptqy.gitv.tv/videos/v0/20170117/64/e1/7487137bdf4d9a469d923777f4ee82d2.f4v?key=052443a2bc31654b44a771c6d1bf76996&dis_k=9b5190d733ebc4c9095fdf864269a73f&dis_t=1490699708&uuid=ede64fc-58da45bc-ad&qypid=-39201&qyid=9d2d465364a622396e2e5642f768fc6a"
    },
    "file_type": "F4V",
    "step": "3"
  },
  "tvid": "604219100",
  "version": "2.0",
  "vid": "159156e732e9c04205982c0d9eb35b10"
}
```

### 返回参数

无

### 调用示例

```sh
curl -X POST -d @data --header "Content-Type:text/json" http://ndct-data.video.iqiyi.com?send_hcdn_info?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205
```

### 响应示例

```
> POST /send_hcdn_info?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205 HTTP/1.1
> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.21 Basic ECC zlib/1.2.3 libidn/1.18 libssh2/1.4.2
> Host: 127.0.0.1
> Accept: */*
> Content-Type: text/json
> Content-Length: 894
>
< HTTP/1.1 200 OK
< Server: openresty/1.9.7.4
< Date: Tue, 28 Mar 2017 10:51:20 GMT
< Content-Type: text/html; charset=utf-8
< Connection: keep-alive
< Content-Length: 0
< Cache-Control: no-cache
```

## ~~Puma-SDK故障数据投递~~

**已废弃**

### 接口描述

| URL          | http://ndct-data.video.iqiyi.com/send_core_info |
|--------------+-------------------------------------------------|
| 功能描述     | NetDoctor SDK模拟故障数据投递接口               |
| 返回格式     | UTF8                                            |
| HTTP请求方式 | GET                                             |
| 当前接口版本 | v1                                              |
| 其它接口版本 | 无                                              |

### 业务参数

| 参数名 | 参数全称 | 必选 | 参数类型 | 参数描述        |
|--------+----------+------+----------+-----------------|
| uid    | uid      | true | String   | 用户的设备ID    |
| plat   | platform | true | String   | 用户的设备平台  |
| ver    | version  | true | String   | 用户的SDK版本号 |

### 投递数据

```json
{
  "version": "2.0",
  "userID": "2402267995",
  "ra": 4,
  "tvid": "439174100",
  "pform": 3,
  "play_process": {
    "file_type": "F4V",
    "hcdn_code": "13",
    "step": 4,
    "access_vrs": {
      "url": "http://cache.video.ptqy.gitv.tv/vps?tvid=439174100&vid=5b72b64869d94184422b777d668d0386&uid=2402267995&v=1&qypid=439174100_5201&src=04022002021000000000&t=1490699619000&k_uid=652B9ECB1D38044B81F1F728814706E8&bid=4&pt=-1&d=1&s=0&rs=1&vt=0&k_from=1&k_ver=4.3.314.53674&vf=f092fa63f380b10f4e6a38f2ea2d9c20",
      "ip": "106.38.219.21",
      "duration": 1735,
      "code": 200,
      "return_data": ""
    },
    "access_vip": {
      "url": "http://cm.passport.ptqy.gitv.tv/apis/user/secure_check_vip.action?authcookie=09m21LhVIgTxkZgoRzN4m1QAdASBb4EbVY2Wm33am14AZ1ElYBJOU4PDjDtm3a0q1SKi46nda&agenttype=28&verify_type=1&sign=c412dfa4c16ab83c4a12bb241635f684&device_id=652B9ECB1D38044B81F1F728814706E8",
      "ip": "106.38.219.40",
      "duration": 2401,
      "code": 200,
      "return_data": "eyJjb2RlIjoiUTAwMzA1IiwibXNnIjoi5LiN5piv5Lya5ZGYIn0="
    },
    "access_pdata": {
      "url": "http://pdata.video.ptqy.gitv.tv/videos/v0/20160108/c9/7c/acc3ac08cbae7925cb2d03379cdef4b0.f4v",
      "ip": "222.173.57.195",
      "duration": 7063,
      "code": 200,
      "return_data": ""
    },
    "cache_status": {
      "url": "http://150.138.146.17/videos/v0/20160108/c9/7c/acc3ac08cbae7925cb2d03379cdef4b0.f4v?key=04025f1dd5dddf78a5c8ff7909829e85a&dis_k=0165675be45805a07c6d6b8e9347174d0&dis_t=1490699657&dis_dz=CT-HeNan_ZhengZhou&dis_st=42&uuid=6a2a1bb8-58da4589-5b&retry=0&mi=tv_203477201_439174100_5b72b64869d94184422b777d668d0386&e=0&tn=82516793&client=106.42.27.184&su=652B9ECB1D38044B81F1F728814706E8&start=221208&end=4186538",
      "ip": "150.138.146.17",
      "duration": 0,
      "code": 206,
      "avgspeed": 15,
      "302url": "",
      "idc": "qingdao3_ct"
    }
  }
}
```

### 返回参数

无

### 调用示例

```sh
curl -X POST -d @data --header "Content-Type:text/json" http://ndct-data.video.iqiyi.com?send_puma_info?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205
```

### 响应示例

```
> POST /send_puma_info?uid=appxxnode2xx545a46d8ada8a&plat=0&ver=1.0.10.1205 HTTP/1.1
> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.21 Basic ECC zlib/1.2.3 libidn/1.18 libssh2/1.4.2
> Host: 127.0.0.1
> Accept: */*
> Content-Type: text/json
> Content-Length: 1859
> Expect: 100-continue
>
< HTPP/1.1 100 Continue
< HTTP/1.1 200 OK
< Server: openresty/1.9.7.4
< Date: Tue, 28 Mar 2017 10:51:20 GMT
< Content-Type: text/html; charset=utf-8
< Connection: keep-alive
< Content-Length: 0
< Cache-Control: no-cache
```
