# AEM架构设计

## 目录结构

## 网关（Gateway）

## 后台管理（Dashboard）

## 实时分析（RealTime Statistics）