# AEM安装指南

## 概述

目前AEM的安装包只支持RPM-Based的Linux发行版，因为公司采用的服务器都是CentOS，对其他发行包需求没有需求。
其他Linux发行版可能需要手动源码安装或者使用DOCKER镜像。

## RPM包安装

1. 生成RPM文件

    $ cd aem-ng
    $ make

2. 卸载老版本，如果有的话

    $ rpm -e netdoctor

3. 安装生成的RPM包

    $ rpm -iVh aem-2.0.0.el6.qiyi.rpm

## 源码安装

1. 安装Nginx等依赖

    $ yum install nginx

2. 编译和安装Openresty

    $ tar xvfz openresty-1.9.7.4.tar.gz
    $ cd ngx_openresty-1.9.7.4 ; ./configure --with-luajit --with-http_stub_status_module --with-pcre-jit;  make ; make install

3. 安装AEM的lua代码

    $ make install

## DOCKER安装

TODO

## 如何运行

如果是通过RPM安装，post-script已经配置好了service，所以直接按下面的方式运行即可：

    $ service aem start
    $ service aem stop

如果是通过源码安装的，那么需要指定nginx运行：

    $ cd aem-ng; /usr/local/openresty/nginx/sbin/nginx -p `pwd` -c conf/nginx.conf