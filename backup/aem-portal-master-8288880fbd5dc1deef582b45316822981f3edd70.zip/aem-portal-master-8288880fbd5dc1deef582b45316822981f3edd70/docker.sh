#!/bin/bash

REGISTRY_URL=docker-registry.qiyi.virtual
REPO_NAME=aem/aem-portal
VERSION=$(sed -n 's/^# VERSION: \(.*\)$/\1/p' Dockerfile)

case $1 in
    build)
        docker rmi -f $REGISTRY_URL/$REPO_NAME:$VERSION
        docker build -t $REGISTRY_URL/$REPO_NAME:$VERSION .
        ;;
    run)
        mkdir -p /data/logs/aem-portal
        docker rm -f aem-portal
        docker run --name aem-portal -d -v /data/logs/aem-portal:/opt/aem/logs -p 8000:8000 -p 9001:9001 $REGISTRY_URL/$REPO_NAME:$VERSION
        ;;
    *)
        ;;
esac

