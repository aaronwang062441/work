# AEM-PORTAL说明文档 #
## AEM-PORTAL概要设计 ##
AEM-PORTAL（以下简称Portal）属于AEM项目的Dashboard，用于将AEM分析好的数据呈现在页面，方便用户分析某个时间段卡顿的走势、错误类型、错误分布和错误详情。Portal后端采用Tornado框架，数据来源于MySQL和MongoDB，由Python组织访问和处理数据的逻辑，实现访问接口，最终将结果显示在Echart上。Portal的进程由Supervisor管理，Supervisor会启动分别对应不同端口的四个Tornado进程，nginx会对前端的访问做反向代理和负载均衡，分配到这四个进程上。Portal的部署采用的是Docker容器技术，能够提高部署的效率和可靠性。
## AEM-PORTAL结构设计 ##
Portal框架结构包括四大部分：逻辑模块(aem_portal)，网页(website)，发布(PyPi)，部署(docker)。其中aem_portal包括6个部分：common模块是基础模块，包括数据库、日志和兼容OA登录的组件；utils模块包括路由装饰器、json_dumps重构以及详细卡顿数据分析组件；models是数据查询逻辑类，使用数据库连接实例进行初始化，不同的函数输出不同形式的数据；config模块包括一些常量数据；dashboard包括一些页面的渲染接口, 页面内部会调用api中的接口；api是输出具体数据的接口；如下详细介绍：
### 1. common模块
1. logging的设计初衷是想实现单例模式的日志类，这一模块暂时没有在工程中使用；
2. cas_client是用于兼容OA登录的；
3. request中包含数据库访问句柄，这些句柄继承自tornado.RequestHandler，然后包含数据库的单例实例对象(self.connection和self.database), Mongo和MySQL的底层分别用的是MotorClient和torndb，其中torndb是同步的，所以mysql相关的操作无法使用tornado的异步非阻塞特性。继承request中Handler的类将包含数据库访问和tornado.RequestHandler的特性，通过重写get函数即可实现对应的路由驱动程序。

### 2. utils模块
1. route是用来装饰路由的，可以很方便的将路由与继承自tornado.RequestHandler的类进行关联；
2. encoder主要是针对特殊字符比如MongoDB中的ObjectId重写了json_dumps中的解析类，防止普通json_dumps解析崩溃，另外也对日期进行了规范化处理，统一了输出格式；
3. analyze是一个独立的模块，对MongoDB中的单条数据进行解析，输出解析结果，StuckDiagnostic继承自object，使用了tornado的协程和异步HTTP获取和分析数据，该模块由上层调用。

### 3. models模块
1. geo用于查询运营商、省份、城市信息，对应的数据库表为isp_info、prvn_info、city_info；
2. stuck用于查询卡顿数据实时分析后的各种错误情况，输出的数据用于前端显示，对应的数据库表为xndctinfo_summary；
3. ndct用于查询卡顿原始数据，根据指定的条件，从MongoDB中提取ND投递的原始数据，一方面用于前端显示，一方面也可以作为analyze模块的输入；
4. scene用于查询现场数据实时分析后的各种错误情况，输出的数据用于前端显示，对应的数据库表为xsceneinfo_summary；
5. pback用于查询探测投递实时分析后的各种错误情况，输出的数据用于前端显示，对应的数据库表为pingback_summary；
6. url用于探针管理和查询，提供探针查询和管理的接口，对应的数据库表为url_info(MySQL)和aem_probe（MongoDB)；

### 4. config模块
1. constants是一些常量，对应于一些播放环节、错误类型等信息，用于前端显示时候的中英文对应；
2. options是一些用于创建tornado应用时需要关联的默认的参数，比如端口，数据库地址等信息；
3. settings是一些常量，比如数据库地址，文件路径等；

### 5. dashboard模块
1. index对应展示的首页、登录和登出，主要使用了route、CASClient和authenticated组件；
2. scene对应展示的现场数据显示，渲染对应的html，传递参数和url，前端内部会访问api中的接口，渲染在html上；
3. stuck对应展示的卡顿错误显示，渲染对应的html，传递参数和url，前端内部会访问api中的接口，渲染在html上；
4. pback对应展示的探测错误显示，渲染对应的html，传递参数和url，前端内部会访问api中的接口，渲染在html上；
5. legacy对应广告部门的一些业务；

### 6. api模块
1. geo_handler对应运营商和地域信息的查询接口，内部使用models中的geo类，关联的路由为"/api/info/#";
2. pback_handler对应探测的查询接口，内部使用models中的pback类，关联的路由为"/api/stats/pback/#"；
3. prepare_handler对应运营商、省份、城市、探针的查询，关联的路由为"/api/prepare/#.json"
4. probe_handler对应探针的管理，内部使用的是ProbeMongoModel和ProbeMySQLModel，关联的路由为"/api/probe/#"
5. scene_handler对应现场数据的查询接口，内部使用了models中SceneStatModel，关联的路由为'/api/stats/scene/#'
6. stuck_handler对应的是卡顿数据的查询，内部使用了models中的StuckStatModel和NdctStuckModel以及utils中的StuckDiagnostic，关联的路由为'/api/stats/stuck/#' 和 '/api/ndct/stuck/#'
7. top_handler对应某一天中某个时间段错误量最多的省份、城市、运营商、用户ID、IP查询接口，内部使用了models中的StuckStatModel和NdctStuckModel以及utils中的StuckDiagnostic，关联的路由为"/api/top/#"

## AEM-PORTAL部署设计 ##
Portal采用了Docker容器技术进行部署，由Dockerfile构建docker image，然后docker.sh中的命令创建一个container，并且运行，运行后会启动supervisord，supervisord跑在容器里，是父进程，nginx和tornado都是fork出来的子进程，由supervisord守护，容器中的nginx的端口对外开放，所以外部的request访问端口时，nginx会进行负载均衡，传递给tornado。

## AEM-PORTAL结构图 ##
![](http://i.imgur.com/90jkbAk.png)
