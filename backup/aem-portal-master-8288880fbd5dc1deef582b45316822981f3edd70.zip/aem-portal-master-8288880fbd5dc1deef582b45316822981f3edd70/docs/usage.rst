=====
Usage
=====

To use AEM Portal in a project::

    import aem_portal
