===============================
AEM Portal
===============================



.. image:: https://pyup.io/repos/github/chengui/aem_portal/shield.svg
     :target: https://pyup.io/repos/github/chengui/aem_portal/
     :alt: Updates


AEM portal including data api and web dashboard



Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

