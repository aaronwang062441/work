# encoding: utf-8
"""API handlers for scene info of AEM/NetDoctor SDK

The collection of api handlers for scene info, currently
the scene info include: mysql, storing realtime
anaylysis data from spark;.
"""

import logging

from datetime import datetime
from tornado.gen import coroutine
from tornado.web import Finish
from bson.objectid import ObjectId

from aem_portal.common.request import MysqlHandler
from aem_portal.utils.encoder import json_dumps
from aem_portal.utils.decorators import route
from aem_portal.models.scene import SceneStatModel


@route('/api/stats/scene/sum')
class SceneSumApiHandler(MysqlHandler):
    """Hanlder for summary realtime anaylysis

    The summary data calculates the total of error categories of
    scene info including network, vrs, pdata, cache, etc.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = SceneStatModel(self.database)
        chunk = dao.get_summary_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/scene/vrs')
class SceneVrsApiHandler(MysqlHandler):
    """Hanlder for vrs realtime anaylysis

    The vrs data calculates the total of error types of
    vrs scene info analyzed by dns and http

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = SceneStatModel(self.database)
        chunk = dao.get_vrs_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/scene/pdata')
class ScenePdataApiHandler(MysqlHandler):
    """Hanlder for pdata realtime anaylysis

    The pdata data calculates the total of error types of
    pdata scene info analyzed by dns and http

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = SceneStatModel(self.database)
        chunk = dao.get_pdata_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/scene/cache')
class SceneCacheApiHandler(MysqlHandler):
    """Hanlder for cache realtime anaylysis

    The cache data calculates the total of error types of
    cache scene info analyzed by dns and http

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = SceneStatModel(self.database)
        chunk = dao.get_cache_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()
