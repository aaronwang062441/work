"""API handlers for stuck info of AEM/NetDoctor SDK

The collection of api handlers for stuck info, currently
the stuck info include two parts: mysql, storing realtime
analysis data from spark; mongo, storing offline original
data posted by SDK client.
"""

import logging

from datetime import datetime
from tornado.gen import coroutine
from tornado.web import Finish

from aem_portal.common.request import MysqlHandler, MongoHandler
from aem_portal.utils.encoder import json_dumps
from aem_portal.utils.decorators import route
from aem_portal.utils.analyze import StuckDiagnostic
from aem_portal.models.stuck import StuckStatModel
from aem_portal.models.ndct import NdctStuckModel


@route('/api/stats/stuck/sum')
class StuckSumApiHandler(MysqlHandler):
    """Hanlder for summary realtime analysis

    The summary data calculates the total of error categories of
    stuck info including network, vrs, pdata, cache, etc.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp', 'total']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        if group == 'total':
            group = None

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = StuckStatModel(self.database)
        chunk = dao.get_summary_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/stuck/vrs')
class StuckVrsApiHandler(MysqlHandler):
    """Hanlder for vrs realtime analysis

    The vrs data calculates the total of error types of
    vrs stuck info analyzed by dns and http

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp', 'total']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        if group == 'total':
            group = None

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = StuckStatModel(self.database)
        chunk = dao.get_vrs_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/stuck/pdata')
class StuckPdataApiHandler(MysqlHandler):
    """Hanlder for pdata realtime analysis

    The pdata data calculates the total of error types of
    pdata stuck info analyzed by dns and http

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp', 'total']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        if group == 'total':
            group = None

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = StuckStatModel(self.database)
        chunk = dao.get_pdata_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/stuck/cache')
class StuckCacheApiHandler(MysqlHandler):
    """Hanlder for cache realtime analysis

    The cache data calculates the total of error types of
    cache stuck info analyzed by dns and http

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp', 'total']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        if group == 'total':
            group = None

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = StuckStatModel(self.database)
        chunk = dao.get_cache_error(sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/ndct/stuck/detail')
class StuckDetailApiHandler(MongoHandler):
    """Hanlder for querying one posted document in detailed

    The mongo database stores documents posted by sdk client,
    which is organized by collections separated by date, when
    query one document, date string should be provided

    request arguments:
    - dt: date string to be used
    - id: object id for query
    """
    def initialize(self, *args, **kwargs):
        super(StuckDetailApiHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_ndctinfo'
        self.database = self.connection[self.db_name]

    @coroutine
    def get(self):
        day_str = self.get_argument('dt', None)
        oid_str = self.get_argument('id', None)

        if not day_str or not oid_str:
            self.finish(chunk={'error': 'parameter not supported'})
            raise Finish()

        day = None
        try:
            if len(day_str) > 8:
                day_str = day_str[0:8]
            day = datetime.strptime(day_str, '%Y%m%d')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not day:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        dao = NdctStuckModel(self.db_name, self.database)
        doc = yield dao.get_detail_by_oid(oid_str, day)

        self.write(json_dumps(doc))
        self.finish()


@route('/api/ndct/stuck/user')
class StuckUserApiHandler(MongoHandler):
    """Hanlder for querying customized field

    The mongo database stores documents posted by sdk client,
    which is organized by collections separated by date, when
    query one document, date strings should be provided between
    one day. User is always identified by 'uid' and 'ip', the
    customized field should be 'uid', or 'ip', or 'tvid'

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - uid: specified device id for query
    - ip: specified ip for query
    - tvid: specified tvid for query
    """
    def initialize(self, *args, **kwargs):
        super(StuckUserApiHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_ndctinfo'
        self.database = self.connection[self.db_name]

    @coroutine
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        uuid = self.get_argument('uid', None) or self.get_argument('uuid', None)
        ip = self.get_argument('ip', None)
        tvid = self.get_argument('tvid', None)

        limit = self.get_argument('n', 0)
        detail = self.get_argument('d', None)
        unfinish = self.get_argument('u', None)

        filters = {'actime': {'$gte': sdt, '$lt': edt}}
        if ip is not None:
            filters.update({'ip': ip})
        if uuid is not None:
            filters.update({'uid': uuid})
        if tvid is not None:
            filters.update({'stuckinfo.play_result.tvid': tvid})
        if unfinish is not None:
            filters.update({'stuckinfo.play_result.step': {'$ne': 22}})

        projection = {
            '_id': 1, 'actime': 1,
            'uid': 1, 'ip': 1, 'zone': 1,
            'stuckinfo.play_result.tvid': 1,
            'stuckinfo.play_result.step': 1,
        }
        if detail is not None:
            projection = None

        logging.info('filters=%s, projection=%s, limit=%d' % (filters, projection, int(limit)))

        dao = NdctStuckModel(self.db_name, self.database)
        docs = yield dao.get_docs_by_user(sdt, edt, filters, projection, int(limit))

        self.write(json_dumps(docs))
        self.finish()


@route('/api/ndct/stuck/area')
class StuckAreaApiHandler(MongoHandler):
    """Hanlder for querying the specified zone

    The mongo database stores documents posted by sdk client,
    which is organized by collections separated by date, when
    query one document, date strings should be provided between
    one day. Zone will be specified by isp, or prvn, or city,
    or isp/prvn, or isp/city

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - isp: specified isp for query
    - prvn: specified prvn for query
    - city: specified city for query
    """
    def initialize(self, *args, **kwargs):
        super(StuckAreaApiHandler, self).initialize(*args, **kwargs)
        self.db_name = "aem_ndctinfo"
        self.database = self.connection[self.db_name]

    @coroutine
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        limit = self.get_argument('n', 0)
        unfinish = self.get_argument('u', None)

        match = {'actime': {'$gte': sdt, '$lt': edt}}
        if isp is not None:
            match.update({'isp': isp})
        if prvn is not None:
            match.update({'prvn': prvn})
        if city is not None:
            match.update({'city': city})
        if unfinish is not None:
            match.update({'stuckinfo.play_result.step': {'$ne': 22}})

        group = {
            '_id': '$uid',
            'zone': {'$first': '$zone'},
            'ip': {'$addToSet': '$ip'},
            'tvid': {'$addToSet': '$stuckinfo.play_result.tvid'},
            'total': {'$sum': 1}
        }

        dao = NdctStuckModel(self.db_name, self.database)
        docs = yield dao.get_aggr_by_area(sdt, edt, match, group, limit)

        self.write(json_dumps(docs))
        self.finish()


@route('/api/ndct/stuck/analyze')
class StuckDataAnalyzeHandler(MongoHandler):
    """Hanlder for analyzing the specified data

    The mongo database stores documents posted by sdk client,
    which is organized by collections separated by date, when
    query this api, one document will be read and analyzed,
    then supply a report just like the spark streaming parser.

    request arguments:
    - dt: datetime for query, format like "20170618"
    - id: specified id of mongo data
    """
    def initialize(self, *args, **kwargs):
        super(StuckDataAnalyzeHandler, self).initialize(*args, **kwargs)
        self.db_name = "aem_ndctinfo"
        self.database = self.connection[self.db_name]

    @coroutine
    def get(self):
        dt_str = self.get_argument('dt', None) or self.get_argument('date', None)
        id_str = self.get_argument('id', None)

        if not dt_str or not id_str:
            self.finish(chunk={'error': 'time and id required to specify document'})
            raise Finish()

        dt = None
        try:
            dt = datetime.strptime(dt_str, "%Y%m%d")
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not dt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        logging.info('id=%s, dt=%s', id_str, dt)

        dao = NdctStuckModel(self.db_name, self.database)
        doc = yield dao.get_detail_by_oid(id_str, dt)

        logging.info("doc=%s", doc)
        result  = yield StuckDiagnostic(doc).diagnose()

        # TODO: render the result

        self.write(json_dumps(result))
        self.finish()
