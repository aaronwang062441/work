"""Probe handlers for deal with probe management

This is a collection of api handlers that performs
probe management, including querying probing urls
"""

from tornado.gen import coroutine
from tornado.web import Finish
from aem_portal.utils.decorators import route
from aem_portal.utils.encoder import json_dumps
from aem_portal.common.request import MysqlHandler, MongoHandler
from aem_portal.models.url import UrlInfoModel
from aem_portal.models.url import ProbeMysqlModel, ProbeMongoModel


@route('/api/info/url')
class UrlInfoApiHandler(MysqlHandler):
    """Handler for querying url info

    This url info provides the info of probing urls enabled
    in AEM system

    request arguments:
    - list: list all probing url info
    - id: specified id code for query
    - url: specified url for query
    - type: specified probe type for query
    """
    def get(self):
        lst = self.get_argument('list', None)
        id_ = self.get_argument('id', None)
        name = self.get_argument('url', None)
        type_ = self.get_argument('type', None)

        chunk = None
        dao = UrlInfoModel(self.database)
        if lst is not None:
            chunk = dao.get_list()

        elif type_ is not None:
            if type_.isdigit():
                chunk = dao.get_by_type(int(type_))
            else:
                chunk = {'error': 'parameter format invalid: %s' % type_}

        elif id_ is not None:
            if id_.isdigit():
                chunk = dao.get_by_id(int(id_))
            else:
                chunk = {'error': 'parameter format invalid: %s' % id_}

        elif name is not None:
            chunk = dao.get_by_name(name)

        else:
            chunk = {'error': 'parameter not supported'}

        if not chunk:
            chunk = {'error': 'no result found'}

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/probe/list')
class ProbeListHandler(MongoHandler):
    """List all probes from mongo database"""
    def initialize(self, *args, **kwargs):
        super(ProbeListHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_probe'
        self.collection = self.connection[self.db_name]

    @coroutine
    def get(self):
        dao = ProbeMongoModel(self.collection)
        chunk = yield dao.list_all()
        res = list()
        for idx, value in enumerate(chunk):
            combine = dict()
            combine['id'] = idx
            combine['name'] = value['dlurl']
            combine['url'] = value['dlurl']
            combine['type'] = {1:'HTTP',2:'DNS',3:'APK'}.get(int(value['type']), 'UNKNOWN')
            combine['rate'] = 300
            combine['qps'] = 10
            combine['period'] = 0
            combine['zone'] = 0
            res.append(combine)

        self.write(json_dumps(res))
        self.finish()


@route('/api/probe/add')
class ProbeAddHandler(MysqlHandler, MongoHandler):
    """Add probe into database"""
    def initialize(self, *args, **kwargs):
        super(ProbeAddHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_probe'
        self.collection = self.connection[self.db_name]

    @coroutine
    def post(self):
        probe = self.get_argument('probe', None)
        typ = self.get_argument('type', None)
        reqs = self.get_argument('reqs', None)
        gap = self.get_argument('gap', None)
        if (probe and typ and reqs and gap) is None:
            self.finish(chunk={'error': 'insert needs parameter'})
            raise Finish()

        dao = ProbeMysqlModel(self.database)
        chunk = dao.insert(probe, typ)
        if chunk:
            self.finish(chunk={'error': 'insert error, maybe exist'})
            raise Finish()
        dao = ProbeMongoModel(self.collection)
        document = dict()
        document.update({'probe': str(probe), 'type': float(typ), 'reqs': float(reqs), 'gap': float(gap)})
        chunk = yield dao.insert(**document)
        if chunk:
            self.finish(chunk={'error': 'mongo insert error'})
            raise Finish()

        self.finish(chunk={'success': 'probe add success'})


@route('/api/probe/del')
class ProbeDelHandler(MysqlHandler, MongoHandler):
    """Delete probe from database"""
    def initialize(self, *args, **kwargs):
        super(ProbeDelHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_probe'
        self.collection = self.connection[self.db_name]

    @coroutine
    def get(self):
        probe = self.get_argument('probe', None)
        if not probe:
            self.finish(chunk={'error': 'delete need probe'})
            raise Finish()

        dao = ProbeMysqlModel(self.database)
        chunk = dao.delete(probe)
        if chunk:
            self.finish(chunk={'error': 'probe not exist'})
            raise Finish()
        dao = ProbeMongoModel(self.collection)
        chunk = yield dao.delete(probe)
        if chunk:
            self.finish(chunk={'error': 'probe not exist'})
            raise Finish()

        self.finish(chunk={'success': 'probe delete success'})


@route('/api/probe/update')
class ProbeUpdateHandler(MongoHandler):
    """Update probe gap and reqs"""
    def initialize(self, *args, **kwargs):
        super(ProbeUpdateHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_probe'
        self.collection = self.connection[self.db_name]

    @coroutine
    def post(self):
        probe = self.get_argument('probe', None)
        reqs = self.get_argument('reqs', None)
        gap = self.get_argument('gap', None)
        if not probe:
            self.finish(chunk={'error': 'update need probe'})
            raise Finish()
        if not (reqs or gap):
            self.finish(chunk={'error': 'update need value'})
            raise Finish()

        document = dict()
        filter = dict()
        filter.update({'dlurl': str(probe)})
        if reqs and str(reqs).isdigit():
            document.update({'reqs': float(reqs)})
        if gap and str(gap).isdigit():
            document.update({'gap': float(gap)})

        dao = ProbeMongoModel(self.collection)
        chunk = yield dao.update(filter, document)
        if chunk:
            chunk = {'error': 'update failed, maybe not match'}
        else:
            chunk = {'success': 'update success'}

        self.finish(chunk)


@route('/api/probe/get')
class ProbeGetHandler(MongoHandler):
    """Get certain probe(s) from MongoDB"""
    def initialize(self, *args, **kwargs):
        super(ProbeGetHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_probe'
        self.collection = self.connection[self.db_name]

    @coroutine
    def get(self):
        probe = self.get_argument('probe', None)
        pbtype = self.get_argument('type', None)
        if not (probe or pbtype):
            self.finish(chunk={'error': 'probe or type need'})
            raise Finish()

        query = dict()
        if probe:
            query.update({'dlurl': str(probe)})
        if pbtype and str(pbtype).isdigit():
            query.update({'type': int(pbtype)})
        elif pbtype and isinstance(pbtype, basestring):
            pbtype = {'HTTP':1,'DNS':2,'APK':3}.get(pbtype.upper(), 0)
            query.update({'type': int(pbtype)})

        dao = ProbeMongoModel(self.collection)
        chunk = yield dao.get(query)
        if not chunk:
            chunk = {'error': 'no probe match'}

        self.write(json_dumps(chunk))
        self.finish()
