"""Ajax handlers for AEM/Portal dashboard

This is a collection of ajax handlers for AEM/Portal dashboard,
they provides all stuff needed by dashboard ajax query, including
step description, china zone description, china isp description,
china isp/prvn/city for initializing select controls, etc
"""

from aem_portal.utils.decorators import route
from aem_portal.utils.encoder import json_dumps
from aem_portal.config.constants import STUCK_STEPS
from aem_portal.common.request import ApiHandler, MysqlHandler
from aem_portal.models.geo import IspInfoModel, PrvnInfoModel, CityInfoModel


@route('/api/step/types.js')
class StepTypesApiHandler(ApiHandler):
    """Provide description for stuckinfo step field"""
    def get(self):
        chunk = dict(map(lambda d: (str(d['id']), d['type']), STUCK_STEPS))
        self.write('window.step_types=%s' % json_dumps(chunk))
        self.finish()


@route('/api/geo/china.js')
class ChinaGeoHandler(MysqlHandler):
    """Provide China zone description in details"""
    def get(self):
        chunk = {}
        dao_p = PrvnInfoModel(self.database)
        prvns = dao_p.get_china_provinces()
        for prvn in prvns:
            if not prvn: continue

            chunk[str(prvn['id'])] = {
                'name': prvn['prvn'] or 'None',
                'text': prvn['prvn_cn'] or 'None',
            }

            dao_c = CityInfoModel(self.database)
            cities = dao_c.get_china_cities(prvn['id'])
            chunk[str(prvn['id'])]['cities'] = dict(map(
                lambda c: (str(c['id']), {'name': c['city'], 'text': c['city_cn']}),
                cities
            ))

        self.write('window.china_zones=%s' % json_dumps(chunk))
        self.finish()


@route('/api/isp/major.js')
class IspMajorApiHandler(MysqlHandler):
    """Provide China major isp description in details"""
    def get(self):
        chunk = {}
        dao = IspInfoModel(self.database)
        isps = dao.get_majors()
        for isp in isps:
            if not isp: continue

            chunk[str(isp['id'])] = {
                'name': isp['isp'] or 'None',
                'text': isp['isp_cn'] or 'None',
            }
        self.write('window.major_isps=%s' % json_dumps(chunk))
        self.finish()


@route('/api/view/filter/isp.json')
class IspFilterApiHandler(MysqlHandler):
    """Provide major isp info for initializing isp select control"""
    def get(self):
        dao = IspInfoModel(self.database)
        isps = dao.get_majors()
        chunk = dict(map(lambda d: (str(d['id']), d['isp_cn']), isps))

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/view/filter/prvn.json')
class PrvnFilterApiHandler(MysqlHandler):
    """Provide China province info for initializing prvn select control"""
    def get(self):
        dao = PrvnInfoModel(self.database)
        prvns = dao.get_china_provinces()
        chunk = dict(map(lambda d: (str(d['id']), d['prvn_cn']), prvns))

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/view/filter/city.json')
class CityFilterApiHandler(MysqlHandler):
    """Provide China city info for initializing city select control"""
    def get(self):
        prvn = self.get_argument('prvn', None)

        if prvn and prvn.isdigit():
            dao = CityInfoModel(self.database)
            cities = dao.get_china_cities(int(prvn))
            chunk = dict(map(lambda d: (str(d['id']), d['city_cn']), cities))
        else:
            chunk = {}

        self.write(json_dumps(chunk))
        self.finish()
