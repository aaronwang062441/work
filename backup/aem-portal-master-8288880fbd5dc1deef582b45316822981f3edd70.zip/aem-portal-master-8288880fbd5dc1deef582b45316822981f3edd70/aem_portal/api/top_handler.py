"""API handlers for querying top N result of stuck statistics

The collections of api handlers for querying top N result of stuck
statistics data, currently calculates result from view point of
isp, prvn, and city
"""

from tornado.web import Finish
from tornado.gen import coroutine
from aem_portal.utils.decorators import route
from aem_portal.utils.encoder import json_dumps
from aem_portal.common.request import MysqlHandler, MongoHandler
from aem_portal.models.stuck import StuckStatModel
from aem_portal.models.ndct import NdctStuckModel
from datetime import datetime

import logging


@route('/api/top/isp')
class IspTopHandler(MysqlHandler):
    """Handler for querying isp statistics of top N in stuckinfo

    The class provides the top N result of isp statistics during a period
    for the stuckinfo data analysis.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - limit: limit number

    response:
    [
        {
            'id': <int, isp encode>,
            'isp': <string, isp name>,
            'isp_cn': <string, isp chinese name>,
            'total': <int, total of stuck statistics>,
            'err_net': <int, amount of network error>,
            'err_boss': <int, amount of boss error>,
            'err_vrs': <int, amount of vrs error>,
            'err_pdata': <int, amount of pdata error>,
            'err_cache': <int, amount of cache error>
        }
    ]
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None)
        edt_str = self.get_argument('edt', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        sdt, edt = None, None

        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn("%s: %s" % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 5

        dao = StuckStatModel(self.database)

        chunk = dao.get_isp_top(sdt, edt, limit)
        if not chunk:
            self.write(json_dumps({'error': 'no result'}))
            raise Finish()

        self.write(json_dumps(chunk))
        raise Finish()


@route('/api/top/prvn')
class PrvnTopHandler(MysqlHandler):
    """Handler for querying prvn statistics of top N in stuckinfo

    The class provides the top N result of prvn statistics during a period
    for the stuckinfo data analysis.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - limit: limit number

    response:
    [
        {
            'id': <int, prvn encode>,
            'prvn': <string, prvn name>,
            'prvn_cn': <string, prvn chinese name>,
            'total': <int, total of stuck statistics>,
            'err_net': <int, amount of network error>,
            'err_boss': <int, amount of boss error>,
            'err_vrs': <int, amount of vrs error>,
            'err_pdata': <int, amount of pdata error>,
            'err_cache': <int, amount of cache error>
        }
    ]
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None)
        edt_str = self.get_argument('edt', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        sdt, edt = None, None

        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn("%s: %s" % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 5

        dao = StuckStatModel(self.database)

        chunk = dao.get_prvn_top(sdt, edt, limit)
        if not chunk:
            self.write(json_dumps({'error': 'no result'}))
            raise Finish()

        self.write(json_dumps(chunk))
        raise Finish()


@route('/api/top/city')
class CityTopHandler(MysqlHandler):
    """Handler for querying city statistics of top N in stuckinfo

    The class provides the top N result of city statistics during a period
    for the stuckinfo data analysis.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - limit: limit number

    response:
    [
        {
            'id': <int, city encode>,
            'city': <string, city name>,
            'city_cn': <string, city chinese name>,
            'total': <int, total of stuck statistics>,
            'err_net': <int, amount of network error>,
            'err_boss': <int, amount of boss error>,
            'err_vrs': <int, amount of vrs error>,
            'err_pdata': <int, amount of pdata error>,
            'err_cache': <int, amount of cache error>
        }
    ]
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None)
        edt_str = self.get_argument('edt', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        sdt, edt = None, None

        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn("%s: %s" % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 5

        dao = StuckStatModel(self.database)

        chunk = dao.get_city_top(sdt, edt, limit)
        if not chunk:
            self.write(json_dumps({'error': 'not result'}))
            raise Finish()

        self.write(json_dumps(chunk))
        raise Finish()


@route('/api/top/uid')
class UidTopHandler(MongoHandler):
    """Handler for querying uid statistics of top N in stuckinfo

    The class provides the top N result of uid statistics during a period
    for the stuckinfo data analysis.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - limit: limit number

    response:
    [
        {
            '_id': <string, uid>,
            'total': <int, uid total>
        }
    ]
    """
    def initialize(self, *args, **kwargs):
        super(UidTopHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_ndctinfo'
        self.database = self.connection[self.db_name]

    @coroutine
    def get(self):
        sdt_str = self.get_argument('sdt', None)
        edt_str = self.get_argument('edt', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'input format invalid'})
            raise Finish()

        if sdt.date() != edt.date():
            self.finish(chunk={'error': 'input date should in the same day'})
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 0

        match = {'actime': {'$gte': sdt, '$lt': edt}}

        logging.info('match=%s, limit=%d' % (match, limit))

        dao = NdctStuckModel(self.db_name, self.database)
        docs = yield dao.get_aggr_by_uid(sdt, edt, match, limit)

        self.write(json_dumps(docs))
        self.finish()


@route('/api/top/ip')
class IpTopHandler(MongoHandler):
    """Handler for querying ip statistics of top N in stuckinfo

    The class provides the top N result of ip statistics during a period
    for the stuckinfo data analysis.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - limit: limit number

    response:
    [
        {
            '_id': <string, ip>,
            'total': <int, uid total>
        }
    ]
    """
    def initialize(self, *args, **kwargs):
        super(IpTopHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_ndctinfo'
        self.database = self.connection[self.db_name]

    @coroutine
    def get(self):
        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str or not limit.isdigit():
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))
            raise Finish()

        if not sdt or not edt:
            self.finish(chunk={'error': 'input format invalid'})
            raise Finish()

        if sdt.date() != edt.date():
            self.finish(chunk={'error': 'input date should in the same day'})
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 0

        match = {'actime': {'$gte': sdt, '$lt': edt}}

        logging.info('match=%s, limit=%d' % (match, limit))

        dao = NdctStuckModel(self.db_name, self.database)
        docs = yield dao.get_aggr_by_ip(sdt, edt, match, limit)

        self.write(json_dumps(docs))
        self.finish()


@route('/api/ztop/vrs')
class VrsZtopHandler(MysqlHandler):
    """Handler for querying isp statistics of top N in specified zone

    The class provides the top N result of isp statistics during a period
    for the 'vrs' stuckinfo data analysis with specified zone.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - prvn: specified prvn encode
    - city: specified city encode
    - limit: limit number

    response:
    [
        {
            'id': <int, isp encode>,
            'isp': <string, isp name>,
            'isp_cn': <string, isp chinese name>,
            'total': <int, total of stuck statistics>,
            'vrs_ip_absent': <int, amount of ip_absent error>,
            'vrs_ip_crossisp': <int, amount of ip_crossisp error>,
            'vrs_code_zero': <int, amount of code_zero error>,
            'vrs_code_3xx': <int, amount of code_3xx error>,
            'vrs_code_4xx': <int, amount of code_4xx error>,
            'vrs_code_5xx': <int, amount of code_5xx error>
        }
    ]
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None)
        edt_str = self.get_argument('edt', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        sdt, edt = None, None

        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn("%s: %s" % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 10

        filters = dict()
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})

        dao = StuckStatModel(self.database)

        chunk = dao.get_vrs_ztop(sdt, edt, filters, limit)
        if not chunk:
            self.write(json_dumps({'error': 'no result'}))
            raise Finish()

        self.write(json_dumps(chunk))
        raise Finish()


@route('/api/ztop/pdata')
class PdataZtopApiHandler(MysqlHandler):
    """Handler for querying isp statistics of top N in specified zone

    The class provides the top N result of isp statistics during a period
    for the 'pdata' stuckinfo data analysis with specified zone.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - prvn: specified prvn encode
    - city: specified city encode
    - limit: limit number

    response:
    [
        {
            'id': <int, isp encode>,
            'isp': <string, isp name>,
            'isp_cn': <string, isp chinese name>,
            'total': <int, total of stuck statistics>,
            'pdata_ip_absent': <int, amount of ip_absent error>,
            'pdata_ip_crossisp': <int, amount of ip_crossisp error>,
            'pdata_code_zero': <int, amount of code_zero error>,
            'pdata_code_3xx': <int, amount of code_3xx error>,
            'pdata_code_4xx': <int, amount of code_4xx error>,
            'pdata_code_5xx': <int, amount of code_5xx error>
        }
    ]
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None)
        edt_str = self.get_argument('edt', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        sdt, edt = None, None

        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn("%s: %s" % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 10

        filters = dict()
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})

        dao = StuckStatModel(self.database)

        chunk = dao.get_pdata_ztop(sdt, edt, filters, limit)
        if not chunk:
            self.write(json_dumps({'error': 'no result'}))
            raise Finish()

        self.write(json_dumps(chunk))
        raise Finish()


@route('/api/ztop/cache')
class CacheZtopApiHandler(MysqlHandler):
    """Handler for querying isp statistics of top N in specified zone

    The class provides the top N result of isp statistics during a period
    for the 'cache' stuckinfo data analysis with specified zone.

    request arguments:
    - sdt: start datetime for query
    - edt: end datetime for query
    - prvn: specified prvn encode
    - city: specified city encode
    - limit: limit number

    response:
    [
        {
            'id': <int, isp encode>,
            'isp': <string, isp name>,
            'isp_cn': <string, isp chinese name>,
            'total': <int, total of stuck statistics>,
            'cache_code_zero': <int, amount of code_zero error>,
            'cache_code_3xx': <int, amount of code_3xx error>,
            'cache_code_4xx': <int, amount of code_4xx error>,
            'cache_code_5xx': <int, amount of code_5xx error>
        }
    ]
    """
    def get(self):
        sdt_str = self.get_argument('sdt', None)
        edt_str = self.get_argument('edt', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)
        limit = self.get_argument('limit', None)

        if not sdt_str or not edt_str:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        sdt, edt = None, None

        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn("%s: %s" % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.write(json_dumps({'error': 'datetime range required'}))
            raise Finish()

        if limit and limit.isdigit():
            limit = int(limit)
        else:
            limit = 10

        filters = dict()
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})

        dao = StuckStatModel(self.database)

        chunk = dao.get_cache_ztop(sdt, edt, filters, limit)
        if not chunk:
            self.write(json_dumps({'error': 'no result'}))
            raise Finish()

        self.write(json_dumps(chunk))
        raise Finish()
