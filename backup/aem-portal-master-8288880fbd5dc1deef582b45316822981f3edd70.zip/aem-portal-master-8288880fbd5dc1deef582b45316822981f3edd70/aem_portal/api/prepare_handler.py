"""HTTP handlers for AEM/Stats real-time analyis

This is a collection of http handlers prepared for AEM/Stats
real-time analyis, providing isp/prvn/city/url encoding info
"""

from aem_portal.utils.decorators import route
from aem_portal.utils.encoder import json_dumps
from aem_portal.common.request import MysqlHandler
from aem_portal.models.url import UrlInfoModel
from aem_portal.models.geo import IspInfoModel, PrvnInfoModel, CityInfoModel


@route('/api/prepare/isp.json')
class IspInfoPrepareHandler(MysqlHandler):
    """Provide isp encoding info"""
    def get(self):
        dao = IspInfoModel(self.database)
        isps = dao.get_list()
        chunk = dict(map(lambda p: (str(p['id']), p['isp']), isps))
        self.write(json_dumps(chunk))
        self.finish()


@route('/api/prepare/prvn.json')
class PrvnInfoPrepareHandler(MysqlHandler):
    """Provide prvn encoding info"""
    def get(self):
        dao = PrvnInfoModel(self.database)
        prvns = dao.get_list()
        chunk = dict(map(lambda p: (str(p['id']), p['prvn']), prvns))
        self.write(json_dumps(chunk))
        self.finish()


@route('/api/prepare/city.json')
class CityInfoPrepareHandler(MysqlHandler):
    """Provide city encoding info"""
    def get(self):
        dao = CityInfoModel(self.database)
        cities = dao.get_list()
        chunk = dict(map(lambda p: (str(p['id']), ("%s-%s" % (p['prvn'], p['city']))), cities))
        self.write(json_dumps(chunk))
        self.finish()


@route('/api/prepare/url.json')
class UrlInfoPrepareHandler(MysqlHandler):
    """Provide url encoding info"""
    def get(self):
        dao = UrlInfoModel(self.database)
        urls = dao.get_list()
        chunk = dict(map(lambda p: (str(p['id']), p['url']), urls))
        self.write(json_dumps(chunk))
        self.finish()
