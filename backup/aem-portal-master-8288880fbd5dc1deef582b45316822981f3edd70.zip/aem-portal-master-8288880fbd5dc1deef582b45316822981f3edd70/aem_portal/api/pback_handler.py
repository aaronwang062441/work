# encoding: utf-8
"""API handlers for pingback info from AEM/NetDoctor SDK

The collection of api handlers for pingback info, the realtime
analysis treats records as a hours-continuous-time-series
statistics data, which categoried by four factors including url,
isp, prvn, city.
"""

import logging

from datetime import datetime
from tornado.web import Finish

from aem_portal.common.request import MysqlHandler, MongoHandler
from aem_portal.utils.encoder import json_dumps
from aem_portal.utils.decorators import route
from aem_portal.models.url import UrlInfoModel
from aem_portal.models.pback import PbackStatModel


@route('/api/stats/pback/dns')
class PbackDnsApiHandler(MysqlHandler):
    """Hanlder for dns probing realtime analysis

    The dns probing data calculates the total of error types of
    dns probing analysis including dns normal, dns hijack, dns
    cross isp, etc

    request arguments:
    - url: probing url for query
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        url = self.get_argument('url', None)

        if not url:
            self.finish(chunk={'error': 'url paramter required'})
            raise Finish()

        dao = UrlInfoModel(self.database)
        if url.isdigit():
            res = dao.get_by_id(int(url))
        else:
            res = dao.get_by_name(url)

        if not res or len(res) == 0:
            self.finish(chunk={'error': 'url not found'})
            raise Finish()

        if len(res) > 1:
            urls = ','.join(map(lambda p: p['url'], res))
            self.finish(chunk={'error': 'more than one url found: %s' % urls})
            raise Finish()

        if int(res[0]['pbtype']) != 2:
            self.finish(chunk={'error': 'dns probing not enable on this url'})
            raise Finish()

        url = int(res[0]['id'])

        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = PbackStatModel(self.database)
        chunk = dao.get_dns_stats(url, sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/pback/http')
class PbackHttpHandler(MysqlHandler):
    """Hanlder for http probing realtime analysis

    The http probing data calculates the total of error types of
    http probing analysis according to http return code, including
    3xx, 4xx, 5xx, zero, etc

    request arguments:
    - url: probing url for query
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        url = self.get_argument('url', None)

        if not url:
            self.finish(chunk={'error': 'url paramter required'})
            raise Finish()

        dao = UrlInfoModel(self.database)
        if url.isdigit():
            res = dao.get_by_id(int(url))
        else:
            res = dao.get_by_name(url)

        if not res or len(res) == 0:
            self.finish(chunk={'error': 'url not found'})
            raise Finish()

        if len(res) > 1:
            urls = ','.join(map(lambda p: p['url'], res))
            self.finish(chunk={'error': 'more than one url found: %s' % urls})
            raise Finish()

        if int(res[0]['pbtype']) != 1:
            self.finish(chunk={'error': 'http probing not enable on this url'})
            raise Finish()

        url = int(res[0]['id'])

        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = PbackStatModel(self.database)
        chunk = dao.get_http_stats(url, sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/stats/pback/download')
class PbackDownloadHandler(MysqlHandler):
    """Hanlder for apk probing realtime analysis

    The apk probing data calculates the total of calculated types of
    apk probing analysis including  maximum speed, minimum speed,
    average speed, etc

    request arguments:
    - url: probing url for query
    - sdt: start datetime for query
    - edt: end datetime for query
    - grp: calculate total by group
    - isp: specified isp for query
    - prvn: specified province for query
    - city: specified city for query
    """
    def get(self):
        url = self.get_argument('url', None)

        if not url:
            self.finish(chunk={'error': 'url paramter required'})
            raise Finish()

        dao = UrlInfoModel(self.database)
        if url.isdigit():
            res = dao.get_by_id(int(url))
        else:
            res = dao.get_by_name(url)

        if not res or len(res) == 0:
            self.finish(chunk={'error': 'url not found'})
            raise Finish()

        if len(res) > 1:
            urls = ','.join(map(lambda p: p['url'], res))
            self.finish(chunk={'error': 'more than one url found: %s' % urls})
            raise Finish()

        if int(res[0]['pbtype']) != 3:
            self.finish(chunk={'error': 'apk probing not enable on this url'})
            raise Finish()

        url = int(res[0]['id'])

        sdt_str = self.get_argument('sdt', None) or self.get_argument('start', None)
        edt_str = self.get_argument('edt', None) or self.get_argument('end', None)

        if not sdt_str or not edt_str:
            self.finish(chunk={'error': 'datetime range required'})
            raise Finish()

        sdt, edt = None, None
        try:
            sdt = datetime.strptime(sdt_str, '%Y%m%d%H%M%S')
            edt = datetime.strptime(edt_str, '%Y%m%d%H%M%S')
        except ValueError, e:
            logging.warn('%s: %s' % (self.__class__.__name__, e))

        if not sdt or not edt:
            self.finish(chunk={'error': 'datetime format invalid'})
            raise Finish()

        group = self.get_argument('grp', None) or self.get_argument('group', None)

        if not group:
            self.finish(chunk={'error': 'group paramter required'})
            raise Finish()

        if group not in set(['time', 'prvn', 'city', 'isp']):
            self.finish(chunk={'error': 'group "%s" not supported' % group})
            raise Finish()

        isp = self.get_argument('isp', None)
        prvn = self.get_argument('prvn', None)
        city = self.get_argument('city', None)

        filters = dict()
        if isp is not None:
            filters.update({'isp': int(isp)})
        if prvn is not None:
            filters.update({'prvn': int(prvn)})
        if city is not None:
            filters.update({'city': int(city)})
        filters = filters or None

        dao = PbackStatModel(self.database)
        chunk = dao.get_http_stats(url, sdt, edt, filters, group)
        chunk = dao.get_download_stats(url, sdt, edt, filters, group)

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/ndct/pback/dns')
class NdctPDnsHandler(MongoHandler):
    """TODO:"""
    def get(self):
        pass


@route('/api/ndct/pback/http')
class NdctPHttpHandler(MongoHandler):
    """TODO:"""
    def get(self):
        pass


@route('/api/ndct/pback/download')
class NdctPDownloadHandler(MongoHandler):
    """TODO:"""
    def get(self):
        pass
