import hashlib
import logging

from urllib import urlencode
from tornado import httpclient
from tornado.gen import coroutine

from aem_portal.utils.decorators import route
from aem_portal.common.request import ApiHandler, MongoHandler

KEPLER_API = "http://kepler.qiyi.domain/apis/kepler/send_message.action"
KEPLER_SECRET_KEY = "54ddd90524c2d4ca8962a2bd09fb8d63"

def generate_message(pbtype, url, ver="1.0"):
    pbkey = {1: 'detection', 2: 'dns', 3: 'dload'}.get(int(pbtype), 'dns')

    content = {
        'version': str(ver),
        'data': [{
            'type': int(pbtype),
            pbkey: str(url)
        }]
    }

    return str(content)

def generate_signature(params, secret_key):
    sorted_params = sorted(params.iteritems(), key=lambda d: d[0])
    str_sign = ""
    for k, v in sorted_params:
        str_sign += "%s=%s|" % (k, v)
    str_sign += secret_key

    sign = hashlib.md5(str_sign).hexdigest()
    return sign

@route('/api/jitback/push')
class PushProbeApiHandler(ApiHandler):
    @coroutine
    def get(self):
        device_id = self.get_argument('device_id', None)
        pbtype = self.get_argument('pbtype', None)
        url = self.get_argument('url', None)

        http_client = httpclient.AsyncHTTPClient()
        try:
            params = {
                'msg_channel': 2,
                'agent_type' : 221,
                'platform'   : 22,
                'user_type'  : 0,
                'msg_type'   : 81,
                'source'     : 57,
                'content'    : generate_message(int(pbtype), str(url)),
                'app_id'     : 1004,
                'device_ids' : device_id,
            }

            params['sign'] = generate_signature(params, KEPLER_SECRET_KEY)

            request = httpclient.HTTPRequest(
                url=KEPLER_API,
                method='POST',
                body=urlencode(params),
                validate_cert=False,
            )
            response = yield http_client.fetch(request)

            logging.warn("response=%s", response.body)

        except httpclient.HTTPError as e:
            logging.error('failed to request http: %s', e)

        except Exception as e:
            logging.error('failed to request http: %s', e)

        finally:
            http_client.close()

@route('/api/jitback/pull')
class PullProbeApiHandler(MongoHandler):
    def initialize(self, *args, **kwargs):
        super(PullProbeApiHandler, self).initialize(*args, **kwargs)
        self.db_name = 'aem_jitback'
        self.database = self.connection[self.db_name]

    @coroutine
    def get(self):
        task_id = self.get_argument('task', None)

        result = yield self.database.find({'task_id': task_id})
        raise Return(result)
