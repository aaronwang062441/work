"""API handlers for base zone/geograghy info for AEM/Portal

This is a collections of api handlers for base info, currently
including global zone info, china isp info, china provinces
info, and china cities info
"""

from aem_portal.utils.decorators import route
from aem_portal.utils.encoder import json_dumps
from aem_portal.common.request import MysqlHandler
from aem_portal.models.geo import IspInfoModel, PrvnInfoModel, CityInfoModel


@route('/api/info/isp')
class IspInfoApiHandler(MysqlHandler):
    """Handler for querying isp info

    The isp info provides Internet Service Provider infomations
    used in AEM system

    request arguments:
    - list: list all isp info
    - id: specified id code for query
    - name: specified name for query
    - cn: specified chinese name for query
    - qyid: qiyi id
    """
    def get(self):
        lst = self.get_argument('list', None)
        id_ = self.get_argument('id', None)
        name = self.get_argument('name', None)
        zhcn = self.get_argument('cn', None)
        qyid = self.get_argument('qyid', None)

        chunk = None
        dao = IspInfoModel(self.database)
        if lst is not None:
            chunk = dao.get_list()

        elif id_ is not None:
            if id_.isdigit():
                chunk = dao.get_by_id(int(id_))
            else:
                chunk = {'error': 'parameter format invalid: %s' % id_}

        elif name is not None:
            chunk = dao.get_by_name(name)

        elif zhcn is not None:
            chunk = dao.get_by_cn(zhcn)

        elif qyid is not None:
            if qyid.isdigit():
                chunk = dao.get_by_qyid(int(qyid))
            else:
                chunk = {'error': 'parameter format invalid: %s' % qyid}

        else:
            chunk = {'error': 'parameter not supported'}

        if not chunk:
            chunk = {'error': 'no result found'}

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/info/prvn')
class PrvnInfoApiHandler(MysqlHandler):
    """Handler for querying country or province info

    The prvn info provides province info of China or country info
    out of China

    request arguments:
    - list: list all country or province (China) info
    - id: specified id code for query
    - name: specified name for query
    - cn: specified chinese name for query
    - qyid: qiyi id
    """
    def get(self):
        lst = self.get_argument('list', None)
        id_ = self.get_argument('id', None)
        name = self.get_argument('name', None)
        zhcn = self.get_argument('cn', None)
        qyid = self.get_argument('qyid', None)

        chunk = None
        dao = PrvnInfoModel(self.database)
        if lst is not None:
            chunk = dao.get_list()

        elif id_ is not None:
            if id_.isdigit():
                chunk = dao.get_by_id(int(id_))
            else:
                chunk = {'error': 'parameter format invalid: %s' % id_}

        elif name is not None:
            chunk = dao.get_by_name(name)

        elif zhcn is not None:
            chunk = dao.get_by_cn(zhcn)

        elif qyid is not None:
            if qyid.isdigit():
                chunk = dao.get_by_qyid(int(qyid))
            else:
                chunk = {'error': 'parameter format invalid: %s' % qyid}

        else:
            chunk = {'error': 'parameter not supported'}

        if not chunk:
            chunk = {'error': 'no result found'}

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/info/city')
class CityInfoApiHandler(MysqlHandler):
    """Handler for querying country or city info

    The prvn info provides city info of China or country info
    out of China

    request arguments:
    - list: list all country or city (China) info
    - id: specified id code for query
    - name: specified name for query
    - cn: specified chinese name for query
    - qyid: qiyi id
    """
    def get(self):
        lst = self.get_argument('list', None)
        id_ = self.get_argument('id', None)
        name = self.get_argument('name', None)
        zhcn = self.get_argument('cn', None)
        qyid = self.get_argument('qyid', None)

        chunk = None
        dao = CityInfoModel(self.database)
        if lst is not None:
            chunk = dao.get_list()

        elif id_ is not None:
            if id_.isdigit():
                chunk = dao.get_by_id(int(id_))
            else:
                chunk = {'error': 'parameter format invalid: %s' % id_}

        elif name is not None:
            chunk = dao.get_by_name(name)

        elif zhcn is not None:
            chunk = dao.get_by_cn(zhcn)

        elif qyid is not None:
            if qyid.isdigit():
                chunk = dao.get_by_qyid(int(qyid))
            else:
                chunk = {'error': 'parameter format invalid: %s' % qyid}

        else:
            chunk = {'error': 'parameter not supported'}

        if not chunk:
            chunk = {'error': 'no result found'}

        self.write(json_dumps(chunk))
        self.finish()


@route('/api/info/china')
class ChinaInfoApiHandler(MysqlHandler):
    """Handler for querying provinces or cities of China

    This api handler provides infomation of China provinces or
    China cities for the specified province

    request arguments:
    - prvn: specified province id or name for query, 0 means
          querying provinces of China
    """
    def get(self):
        prvn = self.get_argument('prvn', None)

        chunk = None
        # calculate prvn value to int or None
        if prvn is None:
            chunk = {'error': 'parameter not supported'}

        elif prvn.isdigit():
            prvn = int(prvn)

        else:
            dao = PrvnInfoModel(self.database)
            res = dao.get_by_name(prvn)

            if not res:
                prvn = None
            else:
                prvn = int(res['id'])

        if not prvn:
            pass

        elif prvn == 0:
            dao = PrvnInfoModel(self.database)
            prvns = dao.get_china_provinces()
            chunk = dict(map(lambda p: (str(p['id']), {'name': p['prvn'], 'text': p['prvn_cn']}), prvns))

        else:
            dao = CityInfoModel(self.database)
            cities = dao.get_china_cities(prvn)
            chunk = dict(map(lambda p: (str(p['id']), {'name': p['city'], 'text': p['city_cn']}), cities))

        if not chunk:
            chunk = {'error': 'no result found'}

        self.write(json_dumps(chunk))
        self.finish()
