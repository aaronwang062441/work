# encoding: utf-8

import tornado.web

from aem_portal.common.request import ViewHandler
from aem_portal.utils.decorators import route, route_redirect
from aem_portal.config.constants import SCENE_VIEWS


route_redirect('/dashboard/sceneinfo', '/dashboard/sceneinfo/overview')
@route('/dashboard/sceneinfo/overview')
class SceneOverviewHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['overview']

        self.render(
            'overview.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenemon/vrs')
class SceneVrsMonitorHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['monitor.vrs']

        self.render(
            'monitor.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenemon/pdata')
class ScenePdataMonitorHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['monitor.pdata']

        self.render(
            'monitor.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenemon/cache')
class SceneCacheMonitorHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['monitor.cache']

        self.render(
            'monitor.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenezone/vrs')
class SceneVrsZoneHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['zone.vrs']

        self.render(
            'zone.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenezone/pdata')
class ScenePdataZoneHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['zone.pdata']

        self.render(
            'zone.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenezone/cache')
class SceneCacheZoneHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['zone.cache']

        self.render(
            'zone.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenequery/user')
class SceneQueryUserHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['query.user']

        self.render(
            'qryuser.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenequery/area')
class SceneQueryAreaHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = SCENE_VIEWS['title']
        views = SCENE_VIEWS['query.area']

        self.render(
            'qryarea.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/scenealert/alarm')
class SceneAlarmAlertHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()

        self.render('alarm.html', user=user)


@route('/dashboard/scenealert/report')
class SceneReportAlertHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()

        self.render('report.html', user=user)
