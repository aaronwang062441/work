# -*- coding: utf-8 -*-
"""Basic pages for dashboard

This module collects the basic view handlers for dashboard, including
index page, login page, logout page, etc.
"""

import logging
from tornado.web import authenticated

from aem_portal.common.request import ViewHandler
from aem_portal.common.cas_client import CASClient
from aem_portal.utils.decorators import route, route_redirect


route_redirect('/', '/dashboard/index')
@route('/dashboard/index')
class HomeHandler(ViewHandler):
    """Home page for dashboard"""
    @authenticated
    def get(self):
        user = self.get_current_user()
        logging.info("/dashboard/index: user=%s" % user)
        self.render('index.html', user=user)


@route('/dashboard/status')
class StatusHandler(ViewHandler):
    """Status page for online servers"""
    @authenticated
    def get(self):
        user = self.get_current_user()
        logging.info("/dashboard/status: user=%s" % user)
        self.render('status.html', user=user)


cas_url = 'http://sso.qiyi.com/cas'
cas_client = CASClient(cas_url, auth_prefix='')

@route('/dashboard/login')
class LoginHandler(ViewHandler):
    """Login page for dashboard"""
    def get(self):
        if self.current_user:
            return self.redirect(self.get_argument('next', '/dashboard/index'))

        ticket = self.get_argument('ticket', None)
        if ticket:
            login_url = self.request.full_url()
            cas_response = cas_client.perform_service_validate(ticket=ticket, service_url=login_url)
            if cas_response and cas_response.success:
                self.session['ticket'] = ticket
                self.session['username'] = cas_response.user
                self.session.save()
                return self.redirect(self.get_argument('next', '/dashboard/index'))

        self.session.clear()

        login_url = self.request.full_url()
        cas_login_url = cas_client.get_login_url(service_url=login_url)

        return self.redirect(cas_login_url)


@route('/dashboard/logout')
class LogoutHandler(ViewHandler):
    """Logout page for dashboard"""
    def get(self):
        self.session.clear()

        login_url = self.request.protocol + '://' + self.request.host + '/dashboard/login'
        cas_logout_url = cas_client.get_logout_url(service_url=login_url)

        return self.redirect(cas_logout_url)
