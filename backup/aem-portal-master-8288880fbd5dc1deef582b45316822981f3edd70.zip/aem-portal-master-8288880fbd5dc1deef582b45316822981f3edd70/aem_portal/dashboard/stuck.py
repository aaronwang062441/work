# encoding: utf-8

import tornado.web

from aem_portal.common.request import ViewHandler
from aem_portal.utils.decorators import route, route_redirect
from aem_portal.config.constants import STUCK_VIEWS


route_redirect('/dashboard/stuckinfo', '/dashboard/stuckinfo/overview')


@route('/dashboard/stuckinfo/overview')
class StuckOverviewHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['overview']

        self.render(
            'overview.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckmon/vrs')
class StuckVrsMonitorHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['monitor.vrs']

        self.render(
            'monitor.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckmon/pdata')
class StuckPdataMonitorHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['monitor.pdata']

        self.render(
            'monitor.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckmon/cache')
class StuckCacheMonitorHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['monitor.cache']

        self.render(
            'monitor.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckzone/vrs')
class StuckVrsZoneHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['zone.vrs']

        self.render(
            'zone.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckzone/pdata')
class StuckPdataZoneHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['zone.pdata']

        self.render(
            'zone.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckzone/cache')
class StuckCacheZoneHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['zone.cache']

        self.render(
            'zone.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckquery/user')
class StuckQueryUserHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['query.user']

        self.render(
            'qryuser.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckquery/area')
class StuckQueryAreaHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()
        title = STUCK_VIEWS['title']
        views = STUCK_VIEWS['query.area']

        self.render(
            'qryarea.html',
            user=user,
            title=title,
            views=views,
        )


@route('/dashboard/stuckalert/alarm')
class StuckAlarmAlertHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()

        self.render('alarm.html', user=user)


@route('/dashboard/stuckalert/report')
class StuckReportAlertHandler(ViewHandler):
    @tornado.web.authenticated
    def get(self):
        user = self.get_current_user()

        self.render('report.html', user=user)
