# encoding: utf-8

from tornado.web import authenticated

from aem_portal.common.request import ViewHandler
from aem_portal.utils.decorators import route
from aem_portal.config.constants import PBACK_VIEWS


@route('/dashboard/pingback/overview')
class OverviewPingbackViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()

        self.render('base.html', user=user)


@route('/dashboard/pingback/http')
class HttpPingbackViewHanlder(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()
        title = PBACK_VIEWS['title']
        views = PBACK_VIEWS['monitor.http']

        self.render(
            'pbackmon.html',
            user=user,
            title=title,
            views=views,
            pbtype=1,
        )


@route('/dashboard/pingback/dns')
class DnsPinbackViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()
        title = PBACK_VIEWS['title']
        views = PBACK_VIEWS['monitor.dns']

        self.render(
            'pbackmon.html',
            user=user,
            title=title,
            views=views,
            pbtype=2,
        )


@route('/dashboard/pingback/apk')
class ApkPingbackViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()
        title = PBACK_VIEWS['title']
        views = PBACK_VIEWS['monitor.apk']

        self.render(
            'pbackmon.html',
            user=user,
            title=title,
            views=views,
            pbtype=3,
        )


@route('/dashboard/pbackzone/http')
class HttpPbackzoneViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()
        title = PBACK_VIEWS['title']
        views = PBACK_VIEWS['zone.http']

        self.render(
            'pbackzone.html',
            user=user,
            title=title,
            views=views,
            pbtype=1,
        )


@route('/dashboard/pbackzone/dns')
class DnsPbackzoneViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()
        title = PBACK_VIEWS['title']
        views = PBACK_VIEWS['zone.dns']

        self.render(
            'pbackzone.html',
            user=user,
            title=title,
            views=views,
            pbtype=2,
        )


@route('/dashboard/pbackzone/apk')
class ApkPbackzoneViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()
        title = PBACK_VIEWS['title']
        views = PBACK_VIEWS['zone.apk']

        self.render(
            'pbackzone.html',
            user=user,
            title=title,
            views=views,
            pbtype=3,
        )


@route('/dashboard/pingback/policy')
class PolicyPingbackViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()

        self.render('base.html', user=user)


@route('/dashboard/pingback/event')
class EventPingbackViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()

        self.render('base.html', user=user)


@route('/dashboard/pingback/rapid')
class RapidPingbackViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()

        self.render('base.html', user=user)

@route('/dashboard/pingback/probe')
class ProbePingbackViewHandler(ViewHandler):
    @authenticated
    def get(self):
        user = self.get_current_user()

        self.render('pbackmgr.html', user=user, title='Probe Management')
