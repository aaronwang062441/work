import logging

from datetime import datetime
from tornado.template import Template
from aem_portal.common.request import ViewHandler, MysqlHandler
from aem_portal.utils.decorators import route, route_redirect


route_redirect('/get_result', '/dashboard/stuckquery/user')


ADVERT_VENDORS = {
    'adm_397c0'    : 14,
    'adm_ty'       : 12,
    'adm_viqiyi'   : 2,
    'adm_vtyqy'    : 13,
    'iqiyi_api'    : 7,
    'iqiyi_t7z'    : 11,
    'iqiyi_v2a'    : 15,
    'mz_iqiyi'     : 3,
    'mz_tyaqy'     : 9,
    'pb_71_msga'   : 18,
    'pb_cupid_msg2': 24,
    'pb_cupid_msga': 25,
    'pb_gitv_msg2' : 17,
    'pb_gitv_msga' : 19,
    'pb_iqiyi_msg2': 16,
    'iqiyi_mz'     : 28,
    'iqiyi_vadm'   : 29,
    'iqiyi_c7r'    : 30,
    'iqiyi_msgs'   : 31
}

MAJOR_ISPS = [
    ('GWBN' , 155, 9),
    ('CT'   , 26 , 8),
    ('CNC'  , 77 , 5),
    ('CMNET', 147, 4),
]


INDEX_TEMPLATE = '<!DOCTYPE html>\n\
<html><head><title>Index of {{title}}</title></head>\n\
<body bgcolor="white">\n<h1>Index of {{title}}</h1><hr><pre><a href="../">../</a>\n\
{% for (vendor, num) in vendors.iteritems() %}\
{% for ago in xrange(30, 0, -1) %}\
{% set dt = today - datetime.timedelta(days=ago) %}\
{% set dt_str = dt.strftime("%Y%m%d") %}\
{% set ct_str = (dt - datetime.timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S") %}\
{% set fname = vendor + "_summary_" + dt.strftime("%Y%m%d") + ".csv" %}\
{% set spaces = " " * (width - 24 - len(fname)) %}\
<a href="{{fname}}">{{fname}}</a>{{spaces}}{{ct_str}}  {{"---"}}\n\
{% end %}\
{% end %}\
'

TXT_TEMPLATE = '<!DOCTYPE html>\n\
<html lang="en">\n<head></head>\n\
<body><pre style="line-height:8px;">\
{% for (vendor, _) in vendors.iteritems() %}\
{{vendor}}\n\
{% end %}\
</pre>\n</body>\n</html>\
'

CSV_TEMPLATE = 'isp,isp_id,province,province_id,city,city_id,total,no_return,%,error_return,%,correct_return,%\n\
{% for (isp, isp_id, isp_qyid) in major_isps %}\
{% for it in query(isp_id) %}\
{% if it["prvn"] != "None" %}\
{{isp}},{{isp_qyid}},{{it["prvn"]}},{{it["qyid"]/100}},{{it["city"]}},{{it["qyid"]}},{{it["total"]}},\
{{it["no_return"]}},{{round(100*it["no_return"]/it["total"], 2)}}%,\
{{it["error_return"]}},{{round(100*it["error_return"]/it["total"], 2)}}%,\
{{it["correct_return"]}},{{round(100*it["correct_return"]/it["total"], 2)}}%\n\
{% end %}\
{% end %}\
,,,,,,,,,,,,\n\
{% end %}\
'


@route('/city_dns_detection/')
class IndexRenderLegacyHandler(ViewHandler):
    def get(self):
        t = Template(INDEX_TEMPLATE, whitespace='single')
        self.write(t.generate(
            title="/city_dns_detection/",
            today=datetime.now(),
            vendors=ADVERT_VENDORS,
            width=80
        ))
        self.finish()


@route('/city_dns_detection/netdoctor_(\d+).txt')
class TxtRenderLegacyHandler(ViewHandler):
    def initialize(self, *args, **kwargs):
        super(TxtRenderLegacyHandler, self).initialize(*args, **kwargs)
        self.set_header('Content-Type', 'text/plain')

    def get(self, date):
        self.write('\n'.join(ADVERT_VENDORS.keys()))
        self.finish()


@route('/city_dns_detection/(.*)_summary_(\d+)\.csv')
class CsvRenderLegacyHandler(MysqlHandler):
    def initialize(self, *args, **kwargs):
        super(CsvRenderLegacyHandler, self).initialize(*args, **kwargs)
        self.set_header('Content-Type', 'text/plain')

    def get(self, vendor, date):
        url_id = ADVERT_VENDORS[vendor]

        t = Template(CSV_TEMPLATE, whitespace='single')
        self.write(t.generate(
            major_isps=MAJOR_ISPS,
            query=lambda x: self.query(date, url_id, x)
        ))
        self.finish()

    def query(self, date, url_id, isp_id):
        master_table = 'pingback_summary'
        slave_table = 'city_info'
        partition = 'P%s' % date

        sql = """
            SELECT S.qyid,S.prvn,S.city,SUM(total) AS total,SUM(no_return) AS no_return,
                   SUM(error_return) AS error_return,SUM(correct_return) AS correct_return
            FROM {master_table} PARTITION ({partition}) AS M
            LEFT OUTER JOIN {slave_table} AS S on M.city = S.id
            WHERE url = {url_id}
            AND   isp = {isp_id}
            AND   M.prvn > 0 AND M.prvn < 32
            GROUP BY M.city
        """.format(
            master_table=master_table,
            slave_table=slave_table,
            partition=partition,
            url_id=url_id,
            isp_id=isp_id,
        )
        logging.info('sql=%s', sql)
        return self.database.query(sql)
