#!/usr/bin/env python
# encoding: utf-8

from aem_portal.models import Model

class IspInfoModel(Model):
    def __init__(self, db):
        self.table = 'isp_info'
        self.db = db

    def get_by_id(self, id_):
        sql = "SELECT * FROM %s WHERE id=%d" % (self.table, id_)
        return self.db.get(sql)

    def get_by_name(self, name):
        sql = "SELECT * FROM %s WHERE isp='%s'" % (self.table, name.upper())
        return self.db.get(sql)

    def get_by_cn(self, name):
        sql = "SELECT * FROM %s WHERE isp_cn='%s'" % (self.table, name)
        return self.db.get(sql)

    def get_by_qyid(self, qyid):
        raise NotImplemented("Not supported")

    def get_isp(self, isp):
        if isp.isdigit():
            return self.get_by_id(int(isp))
        else:
            return self.get_by_name(isp)

    def get_list(self):
        return self.db.query("SELECT * FROM %s" % self.table)

    def get_big3(self):
        big3 = ['26', '77', '147']
        return self.db.query("SELECT * FROM %s WHERE id IN (%s)" % (self.table, ','.join(big3)))

    def get_majors(self):
        majors = ['26', '77', '147', '155', '9', '30', '56', '100', '116', '122', '168']
        return self.db.query("SELECT * FROM %s WHERE id IN (%s)" % (self.table, ','.join(majors)))

class PrvnInfoModel(Model):
    def __init__(self, db):
        self.table = 'prvn_info'
        self.db = db

    def get_by_id(self, id_):
        sql = "SELECT * FROM %s WHERE id=%d" % (self.table, id_)
        return self.db.get(sql)

    def get_by_name(self, name):
        sql = "SELECT * FROM %s WHERE prvn='%s'" % (self.table, name)
        return self.db.get(sql)

    def get_by_cn(self, name):
        sql = "SELECT * FROM %s WHERE prvn_cn='%s'" % (self.table, name)
        return self.db.get(sql)

    def get_by_qyid(self, qyid):
        if qyid == 0: return None
        sql = "SELECT * FROM %s WHERE qyid=%d" % (self.table, qyid)
        return self.db.get(sql)

    def get_prvn(self, prvn):
        if prvn.isdigit():
            return self.get_by_id(int(prvn))
        else:
            return self.get_by_name(prvn)

    def get_list(self):
        return self.db.query("SELECT * FROM %s" % self.table)

    def get_china_provinces(self):
        sql = "SELECT * FROM %s WHERE id>0 and id<=31 or id=95 or id=148 or id=228" % self.table
        return self.db.query(sql)

class CityInfoModel(Model):
    def __init__(self, db):
        self.table = 'city_info'
        self.db = db

    def get_by_id(self, id_):
        sql = "SELECT * FROM %s WHERE id=%d" % (self.table, id_)
        return self.db.get(sql)

    def get_by_name(self, name):
        if name == 'None': return None
        sql = "SELECT * FROM %s WHERE city='%s'" % (self.table, name)
        return self.db.get(sql)

    def get_by_qyid(self, qyid):
        if qyid == 0: return None
        sql = "SELECT * FROM %s WHERE qyid=%d" % (self.table, qyid)
        return self.db.get(sql)

    def get_by_cn(self, name):
        sql = "SELECT * FROM %s WHERE city_cn='%s'" % (self.table, name)
        return self.db.get(sql)

    def get_city(self, city, prvn=None):
        if city.isdigit():
            return self.get_by_id(int(city))
        else:
            return self.get_by_name(city)

    def get_list(self):
        return self.db.query("SELECT * FROM %s" % self.table)

    def get_china_cities(self, prvn):
        sql = "SELECT * FROM %s WHERE city!='None' and pid=%d" % (self.table, prvn)
        return self.db.query(sql)

