"""Data model for stuck info statistics

This module supports database access object interface over
AEM/Stats database structure aem_stats.xndctinfo_summary,
the categories of statistics info include net, boss, vrs,
pdata, cache.

The structure of aem_stats.xndctinfo_summary is defined as:
mysql> SHOW CREATE TABLE `xndctinfo_summary`;
CREATE TABLE `xndctinfo_summary` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `isp` int(10) unsigned NOT NULL DEFAULT '0',
    `prvn` int(10) unsigned NOT NULL DEFAULT '0',
    `city` int(10) unsigned NOT NULL DEFAULT '0',
    `total` int(10) unsigned NOT NULL DEFAULT '0',
    `tmo_network` int(10) unsigned NOT NULL DEFAULT '0',
    `tmo_vrs` int(10) unsigned NOT NULL DEFAULT '0',
    `tmo_pdata` int(10) unsigned NOT NULL DEFAULT '0',
    `tmo_m3u8` int(10) unsigned NOT NULL DEFAULT '0',
    `tmo_vip` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_code_zero` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_code_2xx` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_code_3xx` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_code_4xx` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_code_5xx` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_ip_absent` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_ip_present` int(10) unsigned NOT NULL DEFAULT '0',
    `vrs_ip_crossisp` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_code_zero` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_code_2xx` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_code_3xx` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_code_4xx` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_code_5xx` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_ip_absent` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_ip_present` int(10) unsigned NOT NULL DEFAULT '0',
    `pdata_ip_crossisp` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_code_zero` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_code_2xx` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_code_3xx` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_code_4xx` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_code_5xx` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_ip_absent` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_ip_present` int(10) unsigned NOT NULL DEFAULT '0',
    `cache_ip_crossisp` int(10) unsigned NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`,`time`),
    KEY `isp` (`isp`),
    KEY `prvn` (`prvn`,`city`)
)
"""

import logging
from aem_portal.models import Model


class StuckStatModel(Model):
    """Database access object for xndctinfo_summary

    This model class provides data interfaces over mysql
    table xndctinfo_summary, which is storing statistics
    data of stuck info from AEM/NetDoctor.
    """
    def __init__(self, db):
        self.db = db
        self.table_name = 'xndctinfo_summary'
        self.isp_table_name  = 'isp_info'
        self.city_table_name = 'city_info'
        self.prvn_table_name = 'prvn_info'
        self.columns = {
            'net': [
                'tmo_network'
            ],
            'boss': [
                'tmo_vip'
            ],
            'vrs': [
                'tmo_vrs',
                'vrs_ip_absent',
                'vrs_ip_crossisp',
                'vrs_code_zero',
                'vrs_code_3xx',
                'vrs_code_4xx',
                'vrs_code_5xx'
            ],
            'pdata': [
                'tmo_pdata',
                'pdata_ip_absent',
                'pdata_ip_crossisp',
                'pdata_code_zero',
                'pdata_code_3xx',
                'pdata_code_4xx',
                'pdata_code_5xx'
            ],
            'cache': [
                'cache_code_zero',
                'cache_code_3xx',
                'cache_code_4xx',
                'cache_code_5xx'
            ]
        }

    def get_summary_error(self, dt_start, dt_end, filters, group):
        """Get statistics data in major categories

        @param dt_start: start point of datetime range
        @param dt_end: end point of datetime range
        @param filters: conditions to be filtered
        @param group: summary by grouping, summarize total by default
        """
        fmt_sql = " \
            SELECT {columns} \
            FROM {table_name} \
            WHERE time >='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        columns = []
        if group is not None:
            columns.append(group)
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)

        for it in ['net', 'boss', 'vrs', 'pdata', 'cache']:
            columns.append('SUM(%s) AS err_%s' % ('+'.join(self.columns[it]), it))

        sql = fmt_sql.format(
            columns=','.join(columns),
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_vrs_error(self, dt_start, dt_end, filters, group):
        """Get statistics data of vrs stuck info

        @param dt_start: start point of datetime range
        @param dt_end: end point of datetime range
        @param filters: conditions to be filtered
        @param group: summary by grouping, summarize total by default
        """
        fmt_sql = " \
            SELECT {columns} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        columns = []
        if group is not None:
            columns.append(group)
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)

        """The http code may be assigned to zero in two conditions:
           1. When access to vrs or pdata timeout occurs, http code would be set zero by default,
           2. When access to vrs or pdata response with zero,
           The REAL http_zero means the second part, so calculate it with old http_zero minus tmo_vrs or tmo_pdata.
        """
        if 'vrs_code_zero' in self.columns['vrs']:
            columns.extend(['SUM(vrs_code_zero) - SUM(tmo_vrs) AS vrs_code_zero'])
            self.columns['vrs'].remove('vrs_code_zero')

        columns.extend(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['vrs']))

        sql = fmt_sql.format(
            columns=','.join(columns),
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_pdata_error(self, dt_start, dt_end, filters, group):
        """Get statistics data of pdata stuck info

        @param dt_start: start point of datetime range
        @param dt_end: end point of datetime range
        @param filters: conditions to be filtered
        @param group: summary by grouping, summarize total by default
        """
        fmt_sql = " \
            SELECT {columns} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        columns = []
        if group is not None:
            columns.append(group)
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)

        # The http code may be assigned to zero in two conditions:
        #   1. When access to vrs or pdata timeout occurs, http code would be set zero by default,
        #   2. When access to vrs or pdata response with zero,
        # The REAL http_zero means the second part, so calculate it with old http_zero minus tmo_vrs or tmo_pdata.
        if 'pdata_code_zero' in self.columns['pdata']:
            columns.extend(['SUM(pdata_code_zero) - SUM(tmo_pdata) AS pdata_code_zero'])
            self.columns['pdata'].remove('pdata_code_zero')

        columns.extend(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['pdata']))

        sql = fmt_sql.format(
            columns=','.join(columns),
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_cache_error(self, dt_start, dt_end, filters, group):
        """Get statistics data of cache stuck info

        @param dt_start: start point of datetime range
        @param dt_end: end point of datetime range
        @param filters: conditions to be filtered
        @param group: summary by grouping, summarize total by default
        """
        fmt_sql = " \
            SELECT {columns} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        columns = []
        if group is not None:
            columns.append(group)
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)

        columns.extend(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['cache']))

        sql = fmt_sql.format(
            columns=','.join(columns),
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)


    def get_isp_top(self, dt_start, dt_end, limit):
        """Get isp top N result

        @param start: start point of datetime
        @param end: end point of datetime
        @param limit: show top limit result
        """
        fmt_sql = " \
            SELECT M.isp AS id,S.isp,S.isp_cn,{columns} \
            FROM {master_table} AS M \
            LEFT OUTER JOIN {slave_table} AS S on M.isp = S.id \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
            GROUP BY M.isp \
            ORDER BY total DESC \
            LIMIT {limit} \
        "

        columns = map(lambda s: 'SUM(%s) AS err_%s' % ('+'.join(self.columns[s]), s), self.columns.keys())
        columns.append('SUM(%s) AS total' % '+'.join([i for v in self.columns.itervalues() for i in v]))

        sql = fmt_sql.format(
            columns=','.join(columns),
            master_table=self.table_name,
            slave_table=self.isp_table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S'),
            limit=limit
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_city_top(self, dt_start, dt_end, limit):
        """Get city top N result

        @param start: start point of datetime
        @param end: end point of datetime
        @param limit: show top limit result
        """
        fmt_sql = " \
            SELECT M.city AS id,S.city,S.city_cn,{columns} \
            FROM {master_table} AS M \
            LEFT OUTER JOIN {slave_table} AS S on M.city = S.id \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
            GROUP BY M.city \
            ORDER BY total DESC \
            LIMIT {limit} \
        "

        columns = map(lambda s: 'SUM(%s) AS err_%s' % ('+'.join(self.columns[s]), s), self.columns.keys())
        columns.append('SUM(%s) AS total' % '+'.join([i for v in self.columns.itervalues() for i in v]))

        sql = fmt_sql.format(
            columns=','.join(columns),
            master_table=self.table_name,
            slave_table=self.city_table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S'),
            limit=limit
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_prvn_top(self, dt_start, dt_end, limit):
        """Get prvn top N result

        @param start: start point of datetime
        @param end: end point of datetime
        @param limit: show top limit result
        """
        fmt_sql = " \
            SELECT M.prvn AS id,S.prvn,S.prvn_cn,{columns} \
            FROM {master_table} AS M \
            LEFT OUTER JOIN {slave_table} AS S on M.prvn = S.id \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
            GROUP BY M.prvn \
            ORDER BY total DESC \
            LIMIT {limit} \
        "

        columns = map(lambda s: 'SUM(%s) AS err_%s' % ('+'.join(self.columns[s]), s), self.columns.keys())
        columns.append('SUM(%s) AS total' % '+'.join([i for v in self.columns.itervalues() for i in v]))

        sql = fmt_sql.format(
            columns=','.join(columns),
            master_table=self.table_name,
            slave_table=self.prvn_table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S'),
            limit=limit
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_vrs_ztop(self, dt_start, dt_end, filters, limit=10):
        """Get prvn top N result

        @param start: start point of datetime
        @param end: end point of datetime
        @param limit: show top limit result
        """
        fmt_sql = " \
            SELECT M.isp AS id,S.isp,S.isp_cn,{columns} \
            FROM {master_table} AS M \
            LEFT OUTER JOIN {slave_table} AS S on M.isp = S.id \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' {andwheres}\
            GROUP BY M.isp \
            ORDER BY total DESC \
            LIMIT {limit} \
        "

        andwheres = ''
        if filters:
            andwheres = ' AND '.join([''] + ['%s=%d' % (k, v) for k, v in filters.iteritems()])

        columns = map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['vrs'])
        columns.append('SUM(%s) AS total' % '+'.join(self.columns['vrs']))

        sql = fmt_sql.format(
            columns=','.join(columns),
            master_table=self.table_name,
            slave_table=self.isp_table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S'),
            andwheres=andwheres,
            limit=limit
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_pdata_ztop(self, dt_start, dt_end, filters, limit=10):
        """Get prvn top N result

        @param start: start point of datetime
        @param end: end point of datetime
        @param limit: show top limit result
        """
        fmt_sql = " \
            SELECT M.isp AS id,S.isp,S.isp_cn,{columns} \
            FROM {master_table} AS M \
            LEFT OUTER JOIN {slave_table} AS S on M.isp = S.id \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' {andwheres}\
            GROUP BY M.isp \
            ORDER BY total DESC \
            LIMIT {limit} \
        "

        andwheres = ''
        if filters:
            andwheres = ' AND '.join([''] + ['%s=%d' % (k, v) for k, v in filters.iteritems()])

        columns = map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['pdata'])
        columns.append('SUM(%s) AS total' % '+'.join(self.columns['pdata']))

        sql = fmt_sql.format(
            columns=','.join(columns),
            master_table=self.table_name,
            slave_table=self.isp_table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S'),
            andwheres=andwheres,
            limit=limit
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_cache_ztop(self, dt_start, dt_end, filters, limit=10):
        """Get prvn top N result

        @param start: start point of datetime
        @param end: end point of datetime
        @param limit: show top limit result
        """
        fmt_sql = " \
            SELECT M.isp AS id,S.isp,S.isp_cn,{columns} \
            FROM {master_table} AS M \
            LEFT OUTER JOIN {slave_table} AS S on M.isp = S.id \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' {andwheres}\
            GROUP BY M.isp \
            ORDER BY total DESC \
            LIMIT {limit} \
        "

        andwheres = ''
        if filters:
            andwheres = ' AND '.join([''] + ['%s=%d' % (k, v) for k, v in filters.iteritems()])

        columns = map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['cache'])
        columns.append('SUM(%s) AS total' % '+'.join(self.columns['cache']))

        sql = fmt_sql.format(
            columns=','.join(columns),
            master_table=self.table_name,
            slave_table=self.isp_table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S'),
            andwheres=andwheres,
            limit=limit
        )

        logging.info(sql)

        return self.db.query(sql)
