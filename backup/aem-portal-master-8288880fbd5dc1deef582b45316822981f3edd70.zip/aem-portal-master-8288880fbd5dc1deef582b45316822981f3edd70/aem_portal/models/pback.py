# encoding: utf-8

import logging

from aem_portal.models import Model


class PbackStatModel(Model):
    def __init__(self, db):
        self.db = db
        self.table_name = 'pingback_summary'
        self.columns = {
            'dns': [
                'total',
                'no_return',
                'error_return',
                'correct_return',
            ],
            'http': [
                'total',
                'http_zero',
                'http_2xx',
                'http_3xx',
                'http_4xx',
                'http_5xx',
            ],
            'download': [
                'total',
                'speed_min',
                'speed_max',
                'speed_avg',
            ]
        }

    def get_dns_stats(self, url, dt_start, dt_end, filters, group):
        logging.info('url=%s, dt_start=%s, dt_end=%s, filters=%s, group=%s' % (url, dt_start, dt_end, filters, group))

        fmt_sql = " \
            SELECT {comm_cols},{dns_cols} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
            AND url={url} \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        if group is not None:
            comm_cols = group
            dns_cols = ','.join(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['dns']))
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)
        else:
            comm_cols = 'time,isp,prvn,city'
            dns_cols = ','.join(self.columns['dns'])

        logging.info(fmt_sql)

        sql = fmt_sql.format(
            url=url,
            comm_cols=comm_cols,
            dns_cols=dns_cols,
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_http_stats(self, url, dt_start, dt_end, filters, group):
        logging.info('url=%s, dt_start=%s, dt_end=%s, filters=%s, group=%s' % (url, dt_start, dt_end, filters, group))

        fmt_sql = " \
            SELECT {comm_cols},{http_cols} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
            AND url={url} \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        if group is not None:
            comm_cols = group
            http_cols = ','.join(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['http']))
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)
        else:
            comm_cols = 'time,isp,prvn,city'
            http_cols = ','.join(self.columns['http'])

        sql = fmt_sql.format(
            url=url,
            comm_cols=comm_cols,
            http_cols=http_cols,
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_download_stats(self, url, dt_start, dt_end, filters, group):
        logging.info('url=%s, dt_start=%s, dt_end=%s, filters=%s, group=%s' % (url, dt_start, dt_end, filters, group))

        fmt_sql = " \
            SELECT {comm_cols},{download_cols} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
            AND url={url} \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        if group is not None:
            comm_cols = group
            download_cols = ','.join(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['download']))
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)
        else:
            comm_cols = 'time,isp,prvn,city'
            download_cols = ','.join(self.columns['download'])

        sql = fmt_sql.format(
            url=url,
            comm_cols=comm_cols,
            download_cols=download_cols,
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)
