"""
"""

from bson.son import SON
from bson.objectid import ObjectId
from tornado.gen import Return, coroutine
from aem_portal.models import Model


class NdctStuckModel(Model):
    def __init__(self, db_name, db):
        self.db_name = db_name
        self.db = db

    @coroutine
    def get_detail_by_oid(self, oid, dt=None):
        if dt is not None:
            collect = '%s_%s' % (self.db_name, dt.strftime('%Y%m%d'))
            doc = yield self.db[collect].find_one({'_id': ObjectId(oid)})
            raise Return(doc)
        else:
            pass

    @coroutine
    def get_docs_by_user(self, sdt, edt, filters, projection, limit=0):
        if sdt.date() == edt.date():
            collect = '%s_%s' % (self.db_name, sdt.strftime('%Y%m%d'))
            docs = yield self.db[collect].find(filters, projection, limit=limit).to_list(length=None)
            raise Return(docs)
        else:
            collect1 = '%s_%s' % (self.db_name, sdt.strftime('%Y%m%d'))
            collect2 = '%s_%s' % (self.db_name, edt.strftime('%Y%m%d'))
            docs1, docs2 = yield [
                self.db[collect1].find(filters, projection).to_list(length=None),
                self.db[collect2].find(filters, projection).to_list(length=None),
            ]
            raise Return(docs1 + docs2)

    @coroutine
    def get_aggr_by_area(self, sdt, edt, match, group, limit=0):
        pipeline = [
            {'$match': match},
            {'$group': group},
            # {'$sort': SON([('total', -1)])},
            # {'$limit': int(limit)},
        ]

        if sdt.date() == edt.date():
            collect = '%s_%s' % (self.db_name, sdt.strftime('%Y%m%d'))
            docs = yield self.db[collect].aggregate(pipeline).to_list(length=None)
            raise Return(docs)
        else:
            collect1 = '%s_%s' % (self.db_name, sdt.strftime('%Y%m%d'))
            collect2 = '%s_%s' % (self.db_name, edt.strftime('%Y%m%d'))
            docs1, docs2 = yield [
                self.db[collect1].aggregate(pipeline).to_list(length=None),
                self.db[collect2].aggregate(pipeline).to_list(length=None),
            ]
            raise Return(docs1 + docs2)

    @coroutine
    def get_aggr_by_uid(self, sdt, edt, match, limit=3):
        pipeline = [
            {'$match': match},
            {"$group": {"_id": "$uid", "total": {"$sum": 1}}},
            {'$sort': SON([('total', -1)])},
            {'$limit': int(limit)}
        ]

        if sdt.date() == edt.date():
            collect = '%s_%s' % (self.db_name, sdt.strftime('%Y%m%d'))
            docs = yield self.db[collect].aggregate(pipeline, allowDiskUse=True).to_list(length=None)
            raise Return(docs)
        else:
            pass

    @coroutine
    def get_aggr_by_ip(self, sdt, edt, match, limit=3):
        pipeline = [
            {'$match': match},
            {"$group": {"_id": "$ip", "total": {"$sum": 1}}},
            {'$sort': SON([('total', -1)])},
            {'$limit': int(limit)}
        ]

        if sdt.date() == edt.date():
            collect = '%s_%s' % (self.db_name, sdt.strftime('%Y%m%d'))
            docs = yield self.db[collect].aggregate(pipeline, allowDiskUse=True).to_list(length=None)
            raise Return(docs)
        else:
            pass
