#!/usr/bin/env python
# encoding: utf-8

import logging

from aem_portal.models import Model


class SceneStatModel(Model):
    def __init__(self, db):
        self.db = db
        self.table_name = 'xsceneinfo_summary'
        self.columns = {
            'net': [
                'net_conn_error'
            ],
            'boss': [
                'boss_resolv_failed',
                'boss_conn_failed',
                'boss_dns_incorrect',
                'boss_dns_crossisp',
                'boss_http_zero',
                'boss_http_3xx',
                'boss_http_other',
                'boss_ret_incorrect'
            ],
            'vrs': [
                'vrs_resolv_failed',
                'vrs_conn_failed',
                'vrs_dns_incorrect',
                'vrs_dns_crossisp',
                'vrs_http_zero',
                'vrs_http_3xx',
                'vrs_http_other',
                'vrs_ret_cderror',
                'vrs_ret_sterror',
            ],
            'pdata': [
                'pdata_resolv_failed',
                'pdata_conn_failed',
                'pdata_dns_incorrect',
                'pdata_dns_crossisp',
                'pdata_http_zero',
                'pdata_http_3xx',
                'pdata_http_other',
                'pdata_caddr_failed',
            ],
            'cache': [
                'cache_conn_failed',
                'cache_http_zero',
                'cache_http_3xx',
                'cache_http_other',
            ]
        }

    def get_summary_error(self, dt_start, dt_end, filters, group):
        logging.info('dt_start=%s, dt_end=%s, filters=%s, group=%s' % (dt_start, dt_end, filters, group))

        fmt_sql = " \
            SELECT {comm_cols},{err_net_cols},{err_boss_cols},{err_vrs_cols},{err_pdata_cols},{err_cache_cols} \
            FROM {table_name} \
            WHERE time >='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        def f_plus(n): return '+'.join(self.columns[n])
        if group is not None:
            comm_cols = group
            f_columns = lambda n: 'SUM(%s) AS err_%s' % (f_plus(n), n)
            fmt_sql += " GROUP BY %s ORDER BY %s" % (group, group)
        else:
            comm_cols = "time,isp,prvn,city"
            f_columns = lambda n: '%s AS err_%s' % (f_plus(n), n)

        sql = fmt_sql.format(
            comm_cols=comm_cols,
            err_net_cols=f_columns('net'),
            err_boss_cols=f_columns('boss'),
            err_vrs_cols=f_columns('vrs'),
            err_pdata_cols=f_columns('pdata'),
            err_cache_cols=f_columns('cache'),
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_vrs_error(self, dt_start, dt_end, filters, group):
        logging.info('dt_start=%s, dt_end=%s, filters=%s, group=%s' % (dt_start, dt_end, filters, group))

        fmt_sql = " \
            SELECT {comm_cols},{vrs_cols} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        if group is not None:
            comm_cols = group
            vrs_cols = ','.join(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['vrs']))
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)
        else:
            comm_cols = 'time,isp,prvn,city'
            vrs_cols = ','.join(self.columns['vrs'])

        logging.info(fmt_sql)

        sql = fmt_sql.format(
            comm_cols=comm_cols,
            vrs_cols=vrs_cols,
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_pdata_error(self, dt_start, dt_end, filters, group):
        logging.info('dt_start=%s, dt_end=%s, filters=%s, group=%s' % (dt_start, dt_end, filters, group))

        fmt_sql = " \
            SELECT {comm_cols},{pdata_cols} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        if group is not None:
            comm_cols = group
            pdata_cols = ','.join(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['pdata']))
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)
        else:
            comm_cols = 'time,isp,prvn,city'
            pdata_cols = ','.join(self.columns['pdata'])

        sql = fmt_sql.format(
            comm_cols=comm_cols,
            pdata_cols=pdata_cols,
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

    def get_cache_error(self, dt_start, dt_end, filters, group):
        logging.info('dt_start=%s, dt_end=%s, filters=%s, group=%s' % (dt_start, dt_end, filters, group))

        fmt_sql = " \
            SELECT {comm_cols},{cache_cols} \
            FROM {table_name} \
            WHERE time>='{datetime_start}' \
            AND time<'{datetime_end}' \
        "

        if filters is not None:
            andwheres = ' AND '.join(['%s=%d' % (k, v) for k, v in filters.items()])
            fmt_sql += ' AND %s' % andwheres

        if group is not None:
            comm_cols = group
            cache_cols = ','.join(map(lambda s: 'SUM(%s) AS %s' % (s, s), self.columns['cache']))
            fmt_sql += ' GROUP BY %s ORDER BY %s' % (group, group)
        else:
            comm_cols = 'time,isp,prvn,city'
            cache_cols = ','.join(self.columns['cache'])

        sql = fmt_sql.format(
            comm_cols=comm_cols,
            cache_cols=cache_cols,
            table_name=self.table_name,
            datetime_start=dt_start.strftime('%Y-%m-%d %H:%M:%S'),
            datetime_end=dt_end.strftime('%Y-%m-%d %H:%M:%S')
        )

        logging.info(sql)

        return self.db.query(sql)

