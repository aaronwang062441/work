# encoding: utf-8

import logging
import commands
from tornado.gen import Return, coroutine
from aem_portal.models import Model


class UrlInfoModel(Model):
    def __init__(self, db):
        self.table = 'url_info'
        self.db = db

    def insert(self):
        pass

    def update(self):
        pass

    def delete(self):
        pass

    def query(self):
        pass

    def get_by_type(self, type_):
        sql = "SELECT * FROM %s WHERE pbtype=%d" % (self.table, type_)
        return self.db.query(sql)

    def get_by_id(self, id_):
        sql = "SELECT * FROM %s WHERE id=%d" % (self.table, id_)
        logging.info(sql)
        return self.db.query(sql)

    def get_by_name(self, name):
        sql = "SELECT * FROM %s WHERE url='%s'" % (self.table, name)
        logging.info(sql)
        res = self.db.query(sql)
        if not res:
            sql = "SELECT * FROM %s WHERE url like '%%%%%s%%%%'" % (self.table, name)
            logging.info(sql)
            res = self.db.query(sql)
        return res

    def get_list(self):
        sql = "SELECT * FROM %s" % self.table
        logging.info(sql)
        return self.db.query(sql)


class ProbeMysqlModel(Model):
    def __init__(self, db):
        self.table = 'url_info'
        self.db = db

    def insert(self, probe=None, pbtype=None):
        if (probe and pbtype) is None:
            logging.error("Insert needs valid parameters!")
            chunk  = {"error": "Insert needs valid parameters"}
            return chunk
        if int(pbtype) in [1, 2, 3]:
            count = self.db.query("SELECT COUNT(id) AS t FROM {table} WHERE url='{probe}'".format(table=self.table, probe=probe))[0]['t']
            if int(count):
                logging.info("{probe} already exists!".format(probe=probe))
                chunk = {"error": "{probe} already exists!".format(probe=probe)}
                return chunk
            max_id = self.db.query("SELECT max(id) FROM {table}".format(table=self.table))[0]['max(id)']
            insert_string = "INSERT INTO `{table}` (`id`, `url`, `qyid`, `vendor`, `pbtype`) \
                             VALUES (\'{id}\', \'{url}\', \'0\', \'{vendor}\', \'{pbtype}\');".format(table=self.table, id=max_id+1, url=probe, vendor=max_id+1, pbtype=pbtype)
            logging.info(insert_string)
            try:
                self.db.execute(insert_string)
            except Exception as e:
                logging.error("Insert {probe} error!".format(probe=probe))
                chunk = {"error": "Insert {probe} error!".format(probe=probe)}
                return chunk
        else:
            logging.info("{probe} insert type {typ} incorrect!".format(probe=self.probe, typ=self.pbtype))
            chunk = {"error": "{probe} insert type {typ} incorrect!".format(probe=self.probe, typ=self.pbtype)}
            return chunk

    def delete(self, probe=None):
        if probe is None:
            logging.error("Delete needs valid parameters!")
            chunk = {"error": "Delete needs valid parameters!"}
            return chunk

        count = self.db.query("SELECT COUNT(id) AS id FROM {table} WHERE url='{probe}'".format(table=self.table, probe=probe))[0]['id']
        if int(count):
            delete_string = "DELETE FROM {table} WHERE url='{probe}'".format(table=self.table, probe=probe)
            logging.info(delete_string)
            try:
                self.db.execute(delete_string)
            except Exception as e:
                logging.error("Delete {probe} error!".format(probe=probe))
                chunk = {"error": "Delete {probe} error".format(probe=probe)}
                return chunk
        else:
            logging.info("{probe} does not exist!".format(probe=probe))
            chunk = {"error": "{probe} does not exist!".format(probe=probe)}
            return chunk


class ProbeMongoModel(Model):
    def __init__(self, db):
        self.db = db
        self.db_name = "probes"

    @coroutine
    def insert(self, *args, **kwargs):
        probe = kwargs.get('probe', None)
        pbtype = kwargs.get('type', None)
        reqs = kwargs.get('reqs', None)
        gap = kwargs.get('gap', None)

        res = yield self.db[self.db_name].find({"dlurl": probe}).count()
        if res:
            logging.info("{probe} already exists!".format(probe=probe))
            chunk = {"error": "{probe} already exists!".format(probe=probe)}
            raise Return(chunk)

        insert_string = self.generate(probe, pbtype, reqs, gap)
        if insert_string:
            try:
                self.db[self.db_name].insert_one(insert_string)
                logging.info(insert_string)
            except Exception as e:
                logging.error("{probe} insert error: {e}".format(probe=probe, e=e))
                chunk = {"error": "{probe} insert error: {e}".format(probe=probe, e=e)}
                raise Return(chunk)
        else:
            logging.info("{probe} failed to insert!".format(probe=probe))
            chunk = {"error": "{probe} insert failed!".format(probe=probe)}
            raise Return(chunk)

    @coroutine
    def update(self, filter, document):
        """Only update the reqs and gap"""
        res = yield self.db[self.db_name].update_one(filter, {"$set": document})
        if not res.matched_count:
            logging.info("%s not match" % filter)
            chunk = {"error": "%s not match" % filter}
            raise Return(chunk)

    @coroutine
    def delete(self, probe=None):
        res = yield self.db[self.db_name].find({"dlurl": probe}).count()
        if not res:
            logging.info("{probe} does not exist!".format(probe=probe))
            chunk = {"error": "{probe} does not exist!".format(probe=probe)}
            raise Return(chunk)
        self.db[self.db_name].delete_many({"dlurl": probe})

    @coroutine
    def query(self, probe=None):
        if not probe:
            logging.error("Query need probe!")
            chunk = {"error": "Query need probe!"}
            raise Return(chunk)
        res = yield self.db[self.db_name].find({"dlurl": str(probe)}).to_list(length=None)
        raise Return(res)

    @coroutine
    def list_all(self):
        res = yield self.db[self.db_name].find().to_list(length=None)
        raise Return(res)

    @coroutine
    def get(self, filters):
        res = yield self.db[self.db_name].find(filters).to_list(length=None)
        raise Return(res)

    def generate(self, probe, pbtype, reqs, gap):
        insert_string = None
        if int(pbtype) == 1:
            insert_string = {\
                             "type": 1.0, "policy": {},\
                             "period": {}, "reqs": float(reqs), "gap": float(gap), "dlurl": probe,\
                             "cmd": {"type": 1.0, "detection": "%s" % probe}\
                            }
        elif int(pbtype) == 2:
            insert_string = {\
                             "type": 2.0,\
                             "policy": {},\
                             "period": {},\
                             "reqs": float(reqs),\
                             "gap": float(gap),\
                             "dlurl": probe,\
                             "cmd": {"type": 2.0, "dns": "%s" % probe}\
                            }
        elif int(pbtype) == 3:
            status, res = commands.getstatusoutput("curl -r 0-1048575 -o 1.zip {url}".format(url=probe))
            # status 0 meaning success
            if not status:
                status, res = commands.getstatusoutput("md5sum 1.zip")
                mdsum = res.split()[0]
            else:
                return None

            insert_string = {\
                             "type": 3.0, "policy": {}, "period": {},\
                             "reqs": float(reqs), "gap": float(gap),\
                             "dlurl": probe,\
                             "cmd": {\
                                     "type": 3.0,\
                                     "dload": "{url}|{md5}|0|1048575".format(url=probe, md5=mdsum)\
                                    }\
                            }
        return insert_string
