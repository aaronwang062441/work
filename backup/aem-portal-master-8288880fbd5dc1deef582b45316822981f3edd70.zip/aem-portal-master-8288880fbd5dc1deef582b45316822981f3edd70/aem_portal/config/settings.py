#!/usr/bin/env python
# encoding: utf-8

import sys
import uuid
import base64

app_path = sys.path[0]

# global setting
debug = True
port = 8001
cookie_secret = base64.b64encode(uuid.uuid4().bytes + uuid.uuid4().bytes)

# path setting
template_dir = "/opt/aem/www/templates"
static_path = "/opt/aem/www/static"

# mongodb settings
mongodb_host = ['aem-1.qiyi.mongo', 'aem-2.qiyi.mongo']
mongodb_port = 27017
mongodb_username = 'netdoctor'
mongodb_password = '123456'
mongodb_database = 'aem_ndctinfo'

# mysql database settings
mysqldb_host = '10.153.3.74'
mysqldb_port = 3306
mysqldb_username = 'netdoctor'
mysqldb_password = '123456'
mysqldb_database = 'aem_stats'

# memcached server settings
session_backend = ['127.0.0.1:11211']
session_secret = base64.b64encode(uuid.uuid4().bytes + uuid.uuid4().bytes)
session_timeout = 24*60*60
