# encoding: utf-8

from tornado.options import define

define('debug', default=False, help='enable autoreload for tonado web apps', type=bool)

define('port', default=8888, help='tornado listen port', type=int)

define('static_path', default='resources', help='define the staic files path for the app')
define('template_dir', default='/tmp/views', help='define the path to look for templates')

define('cookie_secret', default='myowncookiesecret', help='cookie secret for tornado secure cookies')

# mongo database options
define('mongodb_host', type=list, default=None, help='mongodb server address')
define('mongodb_port', type=int, default=None, help='mongodb server port')
define('mongodb_username', default=None, help='mongodb database username')
define('mongodb_password', default=None, help='mongodb database password')

# mysql database options
define('mysqldb_host', default=None, help='mysqldb server address')
define('mysqldb_port', type=int, default=None, help='mysqldb server port')
define('mysqldb_username', default=None, help='mysqldb server username')
define('mysqldb_password', default=None, help='mysqldb server password')
define('mysqldb_database', default=None, help='mysqldb database name')

# memcache server options
define('session_secret', default='myownsessionsecret', help='tornado session secret')
define('session_timeout', type=int, default=60, help='tornado session timeout')
define('session_backend', type=list, default=None, help='memcached backend address')
