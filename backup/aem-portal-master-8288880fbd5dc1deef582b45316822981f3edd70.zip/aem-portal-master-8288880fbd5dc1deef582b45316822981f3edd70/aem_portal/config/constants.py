# encoding: utf-8

PLATFROMS = [
    {
        'id'  : 0,
        'name': 'PC',
        'text': u'PC客户端',
    },
    {
        'id'  : 1,
        'name': 'TV',
        'text': u'TV客户端',
    },
    {
        'id'  : 2,
        'name': 'MITV',
        'text': u'小米电视',
    },
    {
        'id'  : 3,
        'name': 'GAME',
        'text': u'游戏机',
    },
    {
        'id'  : 4,
        'name': 'GPHONE',
        'text': u'Android端',
    },
    {
        'id'  : 5,
        'name': 'IPHONE',
        'text': u'iPhone端',
    },
    {
        'id'  : 99,
        'name': 'OTHER',
        'text': '其他平台'
    }
]

STUCK_STEPS = [
    {
        'id'  : 0,
        'type': u'初始状态',
        'desc': u'初始状态',
    },
    {
        'id'  : 1,
        'type': u'联网故障',
        'desc': u'开始检测网络连通性',
    },
    {
        'id'  : 2,
        'type': u'联网故障',
        'desc': u'',
    },
    {
        'id'  : 3,
        'type': u'联网故障',
        'desc': u'',
    },
    {
        'id'  : 4,
        'type': u'鉴权错误',
        'desc': u'',
    },
    {
        'id'  : 5,
        'type': u'鉴权错误',
        'desc': u'',
    },
    {
        'id'  : 6,
        'type': u'鉴权错误',
        'desc': u'',
    },
    {
        'id'  : 7,
        'type': u'VRS故障',
        'desc': u'',
    },
    {
        'id'  : 8,
        'type': u'VRS故障',
        'desc': u'',
    },
    {
        'id'  : 9,
        'type': u'VRS故障',
        'desc': u'',
    },
    {
        'id'  : 10,
        'type': u'BOSS故障',
        'desc': u'',
    },
    {
        'id'  : 11,
        'type': u'BOSS故障',
        'desc': u'',
    },
    {
        'id'  : 12,
        'type': u'BOSS故障',
        'desc': u'',
    },
    {
        'id'  : 13,
        'type': u'M3U8故障',
        'desc': u'',
    },
    {
        'id'  : 14,
        'type': u'M3U8故障',
        'desc': u'',
    },
    {
        'id'  : 15,
        'type': u'M3U8故障',
        'desc': u'',
    },
    {
        'id'  : 16,
        'type': u'调度故障',
        'desc': u'',
    },
    {
        'id'  : 17,
        'type': u'调度故障',
        'desc': u'',
    },
    {
        'id'  : 18,
        'type': u'调度故障',
        'desc': u'',
    },
    {
        'id'  : 19,
        'type': u'Cache故障',
        'desc': u'',
    },
    {
        'id'  : 20,
        'type': u'Cache故障',
        'desc': u'',
    },
    {
        'id'  : 21,
        'type': u'Cache故障',
        'desc': u'',
    },
    {
        'id'  : 22,
        'type': u'播放正常',
        'desc': u'',
    },
    {
        'id'  : 23,
        'type': u'VRS劫持',
        'desc': u'',
    },
    {
        'id'  : 24,
        'type': u'调度劫持',
        'desc': u'',
    },
    {
        'id'  : 25,
        'type': u'Cache劫持',
        'desc': u'',
    },
    {
        'id'  : 26,
        'type': u'M3U8劫持',
        'desc': u'',
    },
]

STUCK_TYPES = {
    'overview': [
        {
            'name': 'err_net',
            'text': u'网络故障',
        },
        {
            'name': 'err_boss',
            'text': u'VIP故障',
        },
        {
            'name': 'err_vrs',
            'text': u'VRS故障',
        },
        {
            'name': 'err_pdata',
            'text': u'调度故障',
        },
        {
            'name': 'err_cache',
            'text': u'缓存机故障',
        },
    ],
    'vrs': [
        {
            'name': 'tmo_vrs',
            'text': u'服务访问超时',
        },
        {
            'name': 'vrs_ip_absent',
            'text': u'DNS劫持故障',
        },
        {
            'name': 'vrs_ip_crossisp',
            'text': u'DNS跨运营商',
        },
        {
            'name': 'vrs_code_zero',
            'text': u'HTTP无返回码',
        },
        {
            'name': 'vrs_code_3xx',
            'text': u'HTTP访问劫持',
        },
        {
            'name': 'vrs_code_4xx',
            'text': u'HTTP访问拒绝',
        },
        {
            'name': 'vrs_code_5xx',
            'text': u'HTTP服务超载',
        }
    ],
    'pdata': [
        {
            'name': 'tmo_pdata',
            'text': u'服务访问超时',
        },
        {
            'name': 'pdata_ip_absent',
            'text': u'DNS劫持故障',
        },
        {
            'name': 'pdata_ip_crossisp',
            'text': u'DNS跨运营商',
        },
        {
            'name': 'pdata_code_zero',
            'text': u'HTTP无返回码',
        },
        {
            'name': 'pdata_code_3xx',
            'text': u'HTTP访问劫持',
        },
        {
            'name': 'pdata_code_4xx',
            'text': u'HTTP访问拒绝',
        },
        {
            'name': 'pdata_code_5xx',
            'text': u'HTTP服务超载',
        }
    ],
    'cache': [
        # {
        #     'name': 'cache_timeout',
        #     'text': u'服务访问超时',
        # },
        {
            'name': 'cache_code_zero',
            'text': u'HTTP无返回码',
        },
        {
            'name': 'cache_code_3xx',
            'text': u'HTTP访问劫持',
        },
        {
            'name': 'cache_code_4xx',
            'text': u'HTTP访问拒绝',
        },
        {
            'name': 'cache_code_5xx',
            'text': u'HTTP服务超载',
        }
    ]
}

STUCK_VIEWS = {
    'title': u'播放故障',
    'overview': {
        'url': '/dashboard/stuckinfo/overview',
        'title': u'总览',
        'types': STUCK_TYPES['overview'],
        'echart': {
            'title': u'播放故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/stuck/sum',
        },
        'top_isp': {
            'title': u'播放故障运营商排行',
            'type' : 'line',
            'api'  : '/api/top/isp',
            'label': 'isp_cn',
        },
        'top_prvn': {
            'title': u'播放故障省份排行',
            'type' : 'line',
            'api'  : '/api/top/prvn',
            'label': 'prvn_cn',
        },
        'top_city': {
            'title': u'播放故障城市排行',
            'type' : 'line',
            'api'  : '/api/top/city',
            'label': 'city_cn',
        },
        'hrefs': {
            'err_net'  : '',
            'err_boss' : '',
            'err_vrs'  : '/dashboard/stuckzone/vrs',
            'err_pdata': '/dashboard/stuckzone/pdata',
            'err_cache': '/dashboard/stuckzone/cache',
        },
    },
    'monitor.vrs': {
        'url': '/dashboard/stuckmon/vrs',
        'title': u'VRS故障',
        'types': STUCK_TYPES['vrs'],
        'echart': {
            'title': u'VRS故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/stuck/vrs',
        },
        'hrefs': {
            'tmo_vrs'        : '/dashboard/stuckzone/vrs',
            'vrs_ip_absent'  : '/dashboard/stuckzone/vrs',
            'vrs_ip_crossisp': '/dashboard/stuckzone/vrs',
            'vrs_code_zero'  : '/dashboard/stuckzone/vrs',
            'vrs_code_3xx'   : '/dashboard/stuckzone/vrs',
            'vrs_code_4xx'   : '/dashboard/stuckzone/vrs',
            'vrs_code_5xx'   : '/dashboard/stuckzone/vrs',
        },
    },
    'monitor.pdata': {
        'url': '/dashboard/stuckmon/pdata',
        'title': u'调度故障',
        'types': STUCK_TYPES['pdata'],
        'echart': {
            'title': u'PDATA故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/stuck/pdata',
        },
        'hrefs': {
            'tmo_pdata'        : '/dashboard/stuckzone/pdata',
            'pdata_ip_absent'  : '/dashboard/stuckzone/pdata',
            'pdata_ip_crossisp': '/dashboard/stuckzone/pdata',
            'pdata_code_zero'  : '/dashboard/stuckzone/pdata',
            'pdata_code_3xx'   : '/dashboard/stuckzone/pdata',
            'pdata_code_4xx'   : '/dashboard/stuckzone/pdata',
            'pdata_code_5xx'   : '/dashboard/stuckzone/pdata',
        }
    },
    'monitor.cache': {
        'url': '/dashboard/stuckmon/cache',
        'title': u'缓存机故障',
        'types': STUCK_TYPES['cache'],
        'echart': {
            'title': u'CACHE故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/stuck/cache',
        },
        'hrefs': {
            'cache_code_zero': '/dashboard/stuckzone/cache',
            'cache_code_3xx' : '/dashboard/stuckzone/cache',
            'cache_code_4xx' : '/dashboard/stuckzone/cache',
            'cache_code_5xx' : '/dashboard/stuckzone/cache',
        }
    },
    'zone.vrs': {
        'url': '/dashboard/stuckzone/vrs',
        'title': u'VRS故障',
        'types': STUCK_TYPES['vrs'],
        'echart': {
            'title': u'VRS故障分布图',
            'type' : 'map',
            'api'  : '/api/stats/stuck/vrs',
        },
        'top_isp': {
            'title': u'VRS故障运营商排行',
            'type' : 'datatable',
            'api'  : '/api/ztop/vrs',
        },
        'hrefs': {
            'tmo_vrs'        : '/dashboard/stuckquery/area',
            'vrs_ip_absent'  : '/dashboard/stuckquery/area',
            'vrs_ip_crossisp': '/dashboard/stuckquery/area',
            'vrs_code_zero'  : '/dashboard/stuckquery/area',
            'vrs_code_3xx'   : '/dashboard/stuckquery/area',
            'vrs_code_4xx'   : '/dashboard/stuckquery/area',
            'vrs_code_5xx'   : '/dashboard/stuckquery/area',
        }
    },
    'zone.pdata': {
        'url': '/dashboard/stuckzone/pdata',
        'title': u'调度故障',
        'types': STUCK_TYPES['pdata'],
        'echart': {
            'title': u'PDATA故障分布图',
            'type' : 'map',
            'api'  : '/api/stats/stuck/pdata',
        },
        'top_isp': {
            'title': u'PDATA故障运营商排行',
            'type' : 'datatable',
            'api'  : '/api/ztop/pdata',
        },
        'hrefs': {
            'tmo_pdata'        : '/dashboard/stuckquery/area',
            'pdata_ip_absent'  : '/dashboard/stuckquery/area',
            'pdata_ip_crossisp': '/dashboard/stuckquery/area',
            'pdata_code_zero'  : '/dashboard/stuckquery/area',
            'pdata_code_3xx'   : '/dashboard/stuckquery/area',
            'pdata_code_4xx'   : '/dashboard/stuckquery/area',
            'pdata_code_5xx'   : '/dashboard/stuckquery/area',
        }
    },
    'zone.cache': {
        'url': '/dashboard/stuckzone/cache',
        'title': u'缓存机故障',
        'types': STUCK_TYPES['cache'],
        'echart': {
            'title': u'CACHE故障趋势图',
            'type' : 'map',
            'api'  : '/api/stats/stuck/cache',
        },
        'top_isp': {
            'title': u'CACHE故障运营商排行',
            'type' : 'datatable',
            'api'  : '/api/ztop/cache',
        },
        'hrefs': {
            'cache_code_zero': '/dashboard/stuckquery/area',
            'cache_code_3xx' : '/dashboard/stuckquery/area',
            'cache_code_4xx' : '/dashboard/stuckquery/area',
            'cache_code_5xx' : '/dashboard/stuckquery/area',
        }
    },
    'query.user': {
        'url': '/dashboard/stuckquery/user',
        'title': u'单点查询',
        'datatable': {
            'title': u'单点查询',
            'type' : 'datatable',
            'api'  : '/api/ndct/stuck/user',
        }
    },
    'query.area': {
        'url': '/dashboard/stuckquery/area',
        'title': u'区域查询',
        'datatable': {
            'title': u'区域查询',
            'type' : 'datatable',
            'api'  : '/api/ndct/stuck/area',
        }
    }
}

SCENE_TYPES = {
    'overview': [
        {
            'name': 'err_net',
            'text': u'网络故障',
        },
        {
            'name': 'err_boss',
            'text': u'VIP故障',
        },
        {
            'name': 'err_vrs',
            'text': u'VRS故障',
        },
        {
            'name': 'err_pdata',
            'text': u'调度故障',
        },
        {
            'name': 'err_cache',
            'text': u'缓存机故障',
        },
    ],
    'vrs': [
        {
            'name': 'vrs_resolv_failed',
            'text': u'域名解析故障',
        },
        {
            'name': 'vrs_conn_failed',
            'text': u'服务连接故障',
        },
        {
            'name': 'vrs_dns_incorrect',
            'text': u'DNS劫持故障',
        },
        {
            'name': 'vrs_dns_crossisp',
            'text': u'DNS跨运营商',
        },
        {
            'name': 'vrs_http_zero',
            'text': u'HTTP无返回码',
        },
        {
            'name': 'vrs_http_3xx',
            'text': u'HTTP访问劫持',
        },
        {
            'name': 'vrs_http_other',
            'text': u'HTTP访问拒绝或超载',
        },
        {
            'name': 'vrs_ret_cderror',
            'text': u'服务返回码错误',
        },
        {
            'name': 'vrs_ret_sterror',
            'text': u'服务返回状态错误',
        }
    ],
    'pdata': [
        {
            'name': 'pdata_resolv_failed',
            'text': u'域名解析故障',
        },
        {
            'name': 'pdata_conn_failed',
            'text': u'服务连接故障',
        },
        {
            'name': 'pdata_dns_incorrect',
            'text': u'DNS劫持故障',
        },
        {
            'name': 'pdata_dns_crossisp',
            'text': u'DNS跨运营商',
        },
        {
            'name': 'pdata_http_zero',
            'text': u'HTTP无返回码',
        },
        {
            'name': 'pdata_http_3xx',
            'text': u'HTTP访问劫持',
        },
        {
            'name': 'pdata_http_other',
            'text': u'HTTP访问拒绝或超载',
        },
        {
            'name': 'pdata_caddr_failed',
            'text': u'调度地址解析故障',
        }
    ],
    'cache': [
        {
            'name': 'cache_conn_failed',
            'text': u'服务连接故障',
        },
        {
            'name': 'cache_http_zero',
            'text': u'HTTP无返回码',
        },
        {
            'name': 'cache_http_3xx',
            'text': u'HTTP访问劫持',
        },
        {
            'name': 'cache_http_other',
            'text': u'HTTP访问拒绝',
        },
    ]
}

SCENE_VIEWS = {
    'title': u'现场数据故障',
    'overview': {
        'url': '/dashboard/sceneinfo/overview',
        'title': u'总览',
        'types': SCENE_TYPES['overview'],
        'echart': {
            'title': u'现场数据故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/scene/sum',
        },
        'top_isp': {
            'title': u'播放故障运营商排行',
            'type' : 'line',
            'api'  : '/api/top/isp',
            'label': 'isp_cn',
        },
        'top_prvn': {
            'title': u'播放故障省份排行',
            'type' : 'line',
            'api'  : '/api/top/prvn',
            'label': 'prvn_cn',
        },
        'top_city': {
            'title': u'播放故障城市排行',
            'type' : 'line',
            'api'  : '/api/top/city',
            'label': 'city_cn',
        },
        'hrefs': {
            'err_net'  : '',
            'err_boss' : '',
            'err_vrs'  : '/dashboard/scenezone/vrs',
            'err_pdata': '/dashboard/scenezone/pdata',
            'err_cache': '/dashboard/scenezone/cache',
        },
        'datatable.top_isp': {
        },
    },
    'monitor.vrs': {
        'url': '/dashboard/scenemon/vrs',
        'title': u'VRS故障',
        'types': SCENE_TYPES['vrs'],
        'echart': {
            'title': u'VRS故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/scene/vrs',
        },
        'hrefs': {
            'vrs_resolv_failed': '/dashboard/scenezone/vrs',
            'vrs_conn_failed'  : '/dashboard/scenezone/vrs',
            'vrs_dns_incorrect': '/dashboard/scenezone/vrs',
            'vrs_dns_crossisp' : '/dashboard/scenezone/vrs',
            'vrs_http_zero'    : '/dashboard/scenezone/vrs',
            'vrs_http_3xx'     : '/dashboard/scenezone/vrs',
            'vrs_http_other'   : '/dashboard/scenezone/vrs',
            'vrs_ret_cderror'  : '/dashboard/scenezone/vrs',
            'vrs_ret_sterror'  : '/dashboard/scenezone/vrs',
        },
    },
    'monitor.pdata': {
        'url': '/dashboard/scenemon/pdata',
        'title': u'调度故障',
        'types': SCENE_TYPES['pdata'],
        'echart': {
            'title': u'PDATA故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/scene/pdata',
        },
        'hrefs': {
            'pdata_resolv_failed': '/dashboard/scenezone/pdata',
            'pdata_conn_failed'  : '/dashboard/scenezone/pdata',
            'pdata_dns_incorrect': '/dashboard/scenezone/pdata',
            'pdata_dns_crossisp' : '/dashboard/scenezone/pdata',
            'pdata_http_zero'    : '/dashboard/scenezone/pdata',
            'pdata_http_3xx'     : '/dashboard/scenezone/pdata',
            'pdata_http_other'   : '/dashboard/scenezone/pdata',
            'pdata_caddr_failed' : '/dashboard/scenezone/pdata',
        }
    },
    'monitor.cache': {
        'url': '/dashboard/scenemon/cache',
        'title': u'缓存机故障',
        'types': SCENE_TYPES['cache'],
        'echart': {
            'title': u'CACHE故障趋势图',
            'type' : 'line',
            'api'  : '/api/stats/scene/cache',
        },
        'hrefs': {
            'cache_conn_failed': '/dashboard/scenezone/cache',
            'cache_http_zero'  : '/dashboard/scenezone/cache',
            'cache_http_3xx'   : '/dashboard/scenezone/cache',
            'cache_http_other' : '/dashboard/scenezone/cache',
        }
    },
    'zone.vrs': {
        'url': '/dashboard/scenezone/vrs',
        'title': u'VRS故障',
        'types': SCENE_TYPES['vrs'],
        'echart': {
            'title': u'VRS故障分布图',
            'type' : 'map',
            'api'  : '/api/stats/scene/vrs',
        },
        'hrefs': {
            'vrs_resolv_failed': '/dashboard/scenequery/area',
            'vrs_conn_failed'  : '/dashboard/scenequery/area',
            'vrs_dns_incorrect': '/dashboard/scenequery/area',
            'vrs_dns_crossisp' : '/dashboard/scenequery/area',
            'vrs_http_zero'    : '/dashboard/scenequery/area',
            'vrs_http_3xx'     : '/dashboard/scenequery/area',
            'vrs_http_other'   : '/dashboard/scenequery/area',
            'vrs_ret_cderror'  : '/dashboard/scenequery/area',
            'vrs_ret_sterror'  : '/dashboard/scenequery/area',
        }
    },
    'zone.pdata': {
        'url': '/dashboard/scenezone/pdata',
        'title': u'调度故障',
        'types': SCENE_TYPES['pdata'],
        'echart': {
            'title': u'PDATA故障分布图',
            'type' : 'map',
            'api'  : '/api/stats/scene/pdata',
        },
        'hrefs': {
            'pdata_resolv_failed': '/dashboard/scenequery/area',
            'pdata_conn_failed'  : '/dashboard/scenequery/area',
            'pdata_dns_incorrect': '/dashboard/scenequery/area',
            'pdata_dns_crossisp' : '/dashboard/scenequery/area',
            'pdata_http_zero'    : '/dashboard/scenequery/area',
            'pdata_http_3xx'     : '/dashboard/scenequery/area',
            'pdata_http_other'   : '/dashboard/scenequery/area',
            'pdata_caddr_failed' : '/dashboard/scenequery/area',
        }
    },
    'zone.cache': {
        'url': '/dashboard/scenezone/cache',
        'title': u'缓存机故障',
        'types': SCENE_TYPES['cache'],
        'echart': {
            'title': u'CACHE故障趋势图',
            'type' : 'map',
            'api'  : '/api/stats/scene/cache',
        },
        'hrefs': {
            'cache_conn_failed': '/dashboard/scenequery/area',
            'cache_http_zero'  : '/dashboard/scenequery/area',
            'cache_http_3xx'   : '/dashboard/scenequery/area',
            'cache_http_other' : '/dashboard/scenequery/area',
        }
    },
    'query.user': {
        'url': '/dashboard/scenequery/user',
        'title': u'单点查询',
        'datatable': {
            'title': u'单点查询',
            'type' : 'datatable',
            'api'  : '/api/ndct/scene/user',
        }
    },
    'query.area': {
        'url': '/dashboard/scenequery/area',
        'title': u'区域查询',
        'datatable': {
            'title': u'区域查询',
            'type' : 'datatable',
            'api'  : '/api/ndct/scene/top',
        }
    }
}

PBACK_TYPES = {
    'http': [
        {
            'name': 'http_zero',
            'text': u'HTTP无返回码',
        },
        {
            'name': 'http_3xx',
            'text': u'HTTP劫持',
        },
        {
            'name': 'http_4xx',
            'text': u'HTTP访问拒绝',
        },
        {
            'name': 'http_5xx',
            'text': u'HTTP访问超载',
        },
        {
            'name': 'http_other',
            'text': u'HTTP未知错误',
        },
        {
            'name': 'http_2xx',
            'text': u'HTTP正常',
        }
    ],
    'dns': [
        {
            'name': 'no_return',
            'text': u'无结果',
        },
        {
            'name': 'error_return',
            'text': u'DNS劫持',
        },
        {
            'name': 'correct_return',
            'text': u'DNS正常',
        }
    ],
    'apk': [
        {
            'name': 'speed_max',
            'text': u'最大速度',
        },
        {
            'name': 'speed_min',
            'text': u'最小速度',
        },
        {
            'name': 'speed_avg',
            'text': u'平均速度',
        }
    ]
}

PBACK_VIEWS = {
    'title': u'探测任务监测',
    'monitor.http': {
        'url': '/dashboard/pingback/http',
        'title': u'HTTP监控',
        'types': PBACK_TYPES['http'],
        'echart': {
            'title': u'HTTP实时监控',
            'type' : 'line',
            'api'  : '/api/stats/pback/http',
        },
        'hrefs': {
            'http_zero' : '/dashboard/pbackzone/http',
            'http_3xx'  : '/dashboard/pbackzone/http',
            'http_4xx'  : '/dashboard/pbackzone/http',
            'http_5xx'  : '/dashboard/pbackzone/http',
            'http_other': '/dashboard/pbackzone/http',
            'http_2xx'  : '/dashboard/pbackzone/http',
        },
    },
    'monitor.dns': {
        'url': '/dashboard/pingback/dns',
        'title': u'DNS监控',
        'types': PBACK_TYPES['dns'],
        'echart': {
            'title': u'DNS实时监控',
            'type' : 'line',
            'api'  : '/api/stats/pback/dns',
        },
        'hrefs': {
            'no_return'      : '/dashboard/pbackzone/dns',
            'error_return'   : '/dashboard/pbackzone/dns',
            'correct_return' : '/dashboard/pbackzone/dns',
        },
    },
    'monitor.apk': {
        'url': '/dashboard/pingback/apk',
        'title': u'APK监控',
        'types': PBACK_TYPES['apk'],
        'echart': {
            'title': u'APK实时监控',
            'type' : 'line',
            'api'  : '/api/stats/pback/download',
        },
        'hrefs': {
            'speed_min' : '/dashboard/pbackzone/apk',
            'speed_max' : '/dashboard/pbackzone/apk',
            'speed_avg' : '/dashboard/pbackzone/apk',
        },
    },
    'zone.http': {
        'url': '/dashboard/pingback/http',
        'title': u'HTTP监控',
        'types': PBACK_TYPES['http'],
        'echart': {
            'title': u'HTTP监控热力图',
            'type' : 'map',
            'api'  : '/api/stats/pback/http',
        },
    },
    'zone.dns': {
        'url': '/dashboard/pingback/dns',
        'title': u'DNS监控',
        'types': PBACK_TYPES['dns'],
        'echart': {
            'title': u'DNS监控热力图',
            'type' : 'map',
            'api'  : '/api/stats/pback/dns',
        },
    },
    'zone.apk': {
        'url': '/dashboard/pingback/apk',
        'title': u'APK监控',
        'types': PBACK_TYPES['apk'],
        'echart': {
            'title': u'APK监控热力图',
            'type' : 'map',
            'api'  : '/api/stats/pback/download',
        },
    }
}
