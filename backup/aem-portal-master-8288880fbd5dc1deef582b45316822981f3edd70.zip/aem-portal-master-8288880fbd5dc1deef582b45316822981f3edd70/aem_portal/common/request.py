# encoding: utf-8
"""Common request handlers

This module defines the common request handlers to be derived from,
These common handler classes is used to initialize the common variable
or common actions, which will be flexible to be extended
"""

from tornado.web import RequestHandler

from aem_portal.common.mongodb import MongoDB
from aem_portal.common.mysqldb import MysqlDB
from aem_portal.common.session import Session, SessionManager


class NotFoundHandler(RequestHandler):
    """404 handler for not found requests"""
    def prepare(self):
        # Override prepare() instead of get() to cover all possible HTTP methods.
        self.set_status(404)
        self.render("error.html")


class BaseHandler(RequestHandler):
    """Basic handler for all tornado requests"""
    def __init__(self, *args, **kwargs):
        super(BaseHandler, self).__init__(*args, **kwargs)


class ViewHandler(BaseHandler):
    """View handler for dashboard requests"""
    def initialize(self, *args, **kwargs):
        super(ViewHandler, self).initialize(*args, **kwargs)
        self.session = Session(SessionManager.instance(), self)

    def get_current_user(self):
        return self.session.get('username', None)


class ApiHandler(BaseHandler):
    """API handler for open api requests which render as json data"""
    def initialize(self, *args, **kwargs):
        self.set_header('Content-Type', 'application/json')


class MongoHandler(ApiHandler):
    """API handler based on mongo database query"""
    def initialize(self, *args, **kwargs):
        super(MongoHandler, self).initialize(*args, **kwargs)
        self.connection = MongoDB.instance().connection


class MysqlHandler(ApiHandler):
    """API handler based on mysql database query"""
    def initialize(self, *args, **kwargs):
        super(MysqlHandler, self).initialize(*args, **kwargs)
        self.database = MysqlDB.instance().database
