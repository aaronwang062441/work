# encoding: utf-8
"""A singleton wrapper class around motor tornado

This module is used to create a singleton instance of Mongo connection,
as MotorClient is asynchonous with connection pooling built in, so it
need not make changes
"""

import logging

from tornado.options import options
from motor.motor_tornado import MotorClient


class MongoDB(object):
    """A singleton wrapper for mongo connection

    This class is used to create singleton instance of Mongo Connection.

    Usage::
        >>> conn = MongoDB.create('127.0.0.1', 27172)
        >>> conn.test.test.find()
    """

    db = None

    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, '_instance'):
            cls._instance = object.__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        self._host = None
        self._port = None
        self._client = None

    def __del__(self):
        self._client.close()

    def __repr__(self):
        return '%s(%r)' % (self.__class__.__name__, self._client)

    def __str__(self):
        return 'host=%s, port=%s' % (self._host, self._port)

    def __getattr__(self, name):
        return getattr(self._client, name)

    def __getitem__(self, name):
        return self._client[name]

    @property
    def connection(self):
        """Property of connection instance"""
        return self._client

    @staticmethod
    def instance():
        """Instance of Mongo database"""
        return MongoDB.db

    @staticmethod
    def create(host=None, port=None, username=None, password=None):
        """The creator of mongo singleton instance

        Create a singleton instance for mongo database

        @param host: mongo database host
        @param port: mongo database port
        @param user: access username
        @param password: access password
        """
        if not host and not port:
            try:
                host, port = options.mongodb_host, options.mongodb_port
            except (AttributeError, ValueError):
                host, port = None, None

        if host and port:
            db = MongoDB()
            db._client = MotorClient(host, int(port))
            db._host = host
            db._port = port
            MongoDB.db = db
            logging.info("MongoDB: %s." % MongoDB.db)
        else:
            raise Exception('You need to configure MongDB server')
