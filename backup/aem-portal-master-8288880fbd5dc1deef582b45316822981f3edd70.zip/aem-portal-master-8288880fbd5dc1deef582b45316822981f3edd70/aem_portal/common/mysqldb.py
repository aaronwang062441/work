# encoding: utf-8
"""A singleton wrapper around torndb

This module is used to create a singleton instance of MySQL database,
and the instance could be used as a wrapper of torndb, which is following
by DB-API style
"""

import logging

from tornado.options import options
from torndb import Connection


class MysqlDB(object):
    """A singleton wrapper around tornado.database for mysql database

    This class is wrapping Connection so that database instance can be
    delivered to tornado handler easily. And the methods of database
    property are very similar to the DB-API for easy use.

    TODO: make it async

    Usage::
        >>> db = MysqlDB.create('127.0.0.1', 3306, 'root', '123')
        >>> db.test.query('SELECT * FROM mysql.user')
    """
    db = None

    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, '_instance'):
            cls._instance = object.__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        self._host = None
        self._port = None
        self._database = None

    def __del__(self):
        self.__database.close()

    def __repr__(self):
        return '%s(%r)' % (self.__class__.__name__, self._database)

    def __str__(self):
        return 'host=%s, port=%s' % (self._host, self._port)

    def __getattr__(self, name):
        return getattr(self.__client, name)

    def __getitem__(self, name):
        return self._database[name]

    @property
    def database(self):
        """Property of database instance"""
        return self._database

    @staticmethod
    def instance():
        """Instance of MySQL database"""
        return MysqlDB.db

    @staticmethod
    def create(host=None, port=None, username=None, password=None, database=None):
        """Create singleton instance for mysql database

        Create a singleton instance for mysql database

        @param host: mysql database host
        @param port: mysql database port
        @param user: mysql database user
        @param password: mysql database password
        @param database: mysql database name
        """
        if not host and not port:
            try:
                host, port = options.mysqldb_host, options.mysqldb_port
            except (AttributeError, ValueError):
                host, port = None, None

        if host and port:
            db = MysqlDB()
            db._database= Connection(
                "%s:%d" % (host, int(port)),
                database or options.mysqldb_database,
                user=username,
                password=password)
            db._host = host
            db._port = port
            MysqlDB.db = db
            logging.info("MysqlDB: %s." % MysqlDB.db)
        else:
            raise Exception('You need to configure mysql server')
