#!/usr/bin/env python
# encoding: utf-8

import logging

class Log(object):

    instance = None

    def __init__(self, options=None):
        if options is None:
            import tornado.options
            options = tornado.options.options

        self.logger = logging.getLogger("portal")
        # from tornado.log import enable_pretty_logging
        # enable_pretty_logging(options, self.logger)

    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, '_instance'):
            cls._instance = super(Log, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def message(self, level, message):
        getattr(self.logger, level)(message)

    @staticmethod
    def create(options=None):
        Log.instance = Log(options)

    @staticmethod
    def info(message):
        Log.instance.message('info', message)

    @staticmethod
    def debug(message):
        Log.instance.message('debug', message)

    @staticmethod
    def error(message):
        Log.instance.message('error', message)

    @staticmethod
    def warn(message):
        Log.instance.message('warning', message)

    @staticmethod
    def fatal(message):
        Log.instance.message('critical', message)
