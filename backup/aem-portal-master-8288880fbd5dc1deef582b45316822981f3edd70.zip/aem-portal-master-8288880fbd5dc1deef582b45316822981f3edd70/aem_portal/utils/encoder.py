#!/usr/bin/env python
# encoding: utf-8

import json
from decimal import Decimal
from datetime import date, datetime
from bson.objectid import ObjectId

class ComplexJSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.strftime("%Y-%m-%d %H:%M:%S")
        elif isinstance(o, date):
            return o.strftime("%Y-%m-%d")
        elif isinstance(o, Decimal):
            return int(o)
        elif isinstance(o, ObjectId):
            return str(o)
        return super(ComplexJSONEncoder, self).default(o)

def json_dumps(d, **kwargs):
    return json.dumps(d, cls=ComplexJSONEncoder, **kwargs)
