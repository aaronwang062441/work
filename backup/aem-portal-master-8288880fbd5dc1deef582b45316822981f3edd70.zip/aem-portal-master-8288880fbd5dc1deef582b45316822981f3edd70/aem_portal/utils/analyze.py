import json
import socket
import logging
import urlparse

from tornado import ioloop
from tornado.gen import Return, coroutine
from tornado.httpclient import AsyncHTTPClient, HTTPError

# Fuxi api format string
FUXI_STR = "http://fuxi.qiyi.domain/?appkey=domainResolution&type=video&domain={url}&extends=1&recursion=1&account=netdoc&passwd=netdoc_dns"

# Time out for judging http duration
ACCESS_HTTP_TIMEOUT = 5000

# Enum class definition
class Enum(tuple): __getattr__ = tuple.index

# Enum code definition for parse
EnumParse = Enum([
    'E_NONE',
    'E_OK',
    'E_NET_OFFLINE',
    'E_NET_UNREACHABLE',
    'E_NET_LOWSPEED',
    'E_NET_INTRANAT',
    'E_DNS_HIJACK',
    'E_DNS_CROSSPRVN',
    'E_DNS_CROSSISP',
    'E_DNS_TIMEOUT',  # resolve timeout
    'E_DNS_FAILED',  # resolve failed
    'E_HTTP_TIMEOUT',
    'E_HTTP_FAILED',
    'E_HTTP_UNDEFINED',
    'E_HTTP_NOCONTENT',
    'E_HTTP_HIJACK',
    'E_HTTP_UNAUTHORIZED',
    'E_HTTP_DENIED',
    'E_HTTP_BUSY',
])


logger = logging.getLogger(__name__)


def makeup_fuxi_url(domain):
    """Make up fuxi url by using specified domain"""
    return FUXI_STR.format(url=domain)


# class ParseResult(dict):
    # def __init__(self, value=-1):
        # self.value = value
        # if value >= 0 and value < len(PARSE_RESULTS):
            # self.message = PARSE_RESULTS[self.value]
        # else:
            # self.message = 'None'

    # def __str__(self):
        # return 'return: %d, message: %s' % (self.value, self.message)


class StuckDiagnostic(object):
    """Diagnostics for stuckinfo from mongo database

    @param stuckinfo: stuckinfo from mongo database
    """
    def __init__(self, record):
        self.orig_record = record
        self.stuck_info = record['stuckinfo']
        self.play_result = self.stuck_info['play_result']
        self.dns_result = self.stuck_info['dns_result']

    def validate(self, result, field):
        """Validate syntax for specified field"""
        pass

    @coroutine
    def _parse_dns(self, idc_zone, domain_name, resolved_ip):
        """Parse dns status to diagnose dns problem

        @param idc_zone: idc zone classified by ip address
        @param domain_name: domain name to parse
        @param resolved_ip: ip resolved for domain from user side
        """
        # TODO: more precisely, split crossisp to crossprvn and crossisp
        fuxi_data = dict()
        http_client = AsyncHTTPClient()

        try:
            url = makeup_fuxi_url(domain_name)
            resp = yield http_client.fetch(url, validate_cert=False)

            if resp.code == 200:
                fuxi_resp = json.loads(resp.body.decode())
            else:
                resp.rethrow()

            fuxi_data = fuxi_resp['data']

        except (socket.error, HTTPError) as e:
            logger.error('fetch fuxi api failed: %s', e)
            raise Return(None)

        except (TypeError, ValueError) as e:
            logger.error('load json object failed: %s', e)
            raise Return(None)

        except KeyError as e:
            logger.error('result data invalid: %s', e)
            raise Return(None)

        finally:
            http_client.close()

        logger.info('fuxi_data=%s', fuxi_data)

        iplist_all, iplist_idc = set(), set()
        for k, l in fuxi_data.items():
            if k == idc_zone:
                iplist_idc.update(l)
            iplist_all.update(l)

        # if len(iplist_idc) == 0:
        #    iplist_idc = fuxi_data['default']

        if resolved_ip not in iplist_all:
            raise Return(EnumParse.E_DNS_HIJACK)

        if resolved_ip not in iplist_idc:
            raise Return(EnumParse.E_DNS_CROSSISP)

        raise Return(EnumParse.E_OK)

    parse_dns = _parse_dns

    @coroutine
    def _parse_http(self, http_retcode, http_duration):
        """Parse http status to diagnose http problem

        @param http_retcode: return code of http service
        @param http_duration: duration time for access http service
        """
        if http_retcode == 0:
            if http_duration > ACCESS_HTTP_TIMEOUT:
                raise Return(EnumParse.E_HTTP_TIMEOUT)
            else:
                raise Return(EnumParse.E_HTTP_FAILED)


        if http_retcode == 200:
            if http_duration > ACCESS_HTTP_TIMEOUT / 2:
                raise Return(EnumParse.E_HTTP_LOWSPEED)
            else:
                raise Return(EnumParse.E_OK)

        category = http_retcode / 100

        if category == 1:
            raise Return(EnumParse.E_HTTP_UNDEFINED)
        if category == 2:
            raise Return(EnumParse.E_HTTP_NOCONTENT)
        if category == 3:
            raise Return(EnumParse.E_HTTP_HIJACK)
        if category == 4:
            raise Return(EnumParse.E_HTTP_DENIED)
        if category == 5:
            raise Return(EnumParse.E_HTTP_BUSY)

        raise Return(EnumParse.E_NONE)

    parse_http = _parse_http

    @coroutine
    def diagnose_network(self):
        """Diagnose network problem"""
        raise Return(EnumParse.E_OK)

    @coroutine
    def diagnose_boss(self):
        """Diagnose vip problem"""
        raise Return(EnumParse.E_OK)

    @coroutine
    def diagnose_vrs(self):
        """Diagnose vrs problem"""
        self.validate(self.play_result, 'access_vrs')

        self.vrs_result = self.play_result['access_vrs']

        result = list()

        idc_zone = '%s|%s' % (self.orig_record['isp'], self.orig_record['prvn'])
        domain_name = urlparse.urlparse(self.vrs_result['url']).netloc
        resolved_ip = self.vrs_result['ip']
        res = yield self._parse_dns(idc_zone, domain_name, resolved_ip)
        if res not in (None, EnumParse.E_OK, EnumParse.E_NONE):
            result.append(res)

        http_retcode = int(self.vrs_result['code'])
        http_duration = int(self.vrs_result['duration'])
        res = yield self._parse_http(http_retcode, http_duration)
        if res not in (None, EnumParse.E_OK, EnumParse.E_NONE):
            result.append(res)

        # parse return_data to check service status
        # return_data = self.vrs_result['return_data']
        # if return_data not ok:
        #     result.append()

        if not result:
            result = [EnumParse.E_OK]

        raise Return(result)

    @coroutine
    def diagnose_pdata(self):
        """Diagnose pdata problem"""
        self.validate(self.play_result, 'access_pdata')

        self.pdata_result = self.play_result['access_pdata']

        result = list()

        idc_zone = '%s|%s' % (self.orig_record['isp'], self.orig_record['prvn'])
        domain_name = urlparse.urlparse(self.pdata_result['url']).netloc
        resolved_ip = self.pdata_result['ip']
        res = yield self._parse_dns(idc_zone, domain_name, resolved_ip)
        if res not in (None, EnumParse.E_OK, EnumParse.E_NONE):
            result.append(res)

        http_retcode = int(self.pdata_result['code'])
        http_duration = int(self.pdata_result['duration'])
        res = yield self._parse_http(http_retcode, http_duration)
        if res not in (None, EnumParse.E_OK, EnumParse.E_NONE):
            result.append(res)

        # parse return_data to check service status
        # return_data = self.pdata_result['return_data']
        # if return_data not ok:
        #     result.append()

        if not result:
            result = [EnumParse.E_OK]

        raise Return(result)

    @coroutine
    def diagnose_cache(self):
        """Diagnose cache problem"""
        self.validate(self.play_result, 'cache_status')

        self.cache_result = self.play_result['cache_status']

        result = list()

        http_retcode = int(self.pdata_result['code'])
        http_duration = int(self.pdata_result['duration'])
        res = yield self._parse_http(http_retcode, http_duration)
        if res not in (None, EnumParse.E_OK, EnumParse.E_NONE):
            result.append(res)

        # parse thirdy cdn provides
        # parse cache speed

        if not result:
            result = [EnumParse.E_OK]

        raise Return(result)

    @coroutine
    def diagnose(self):
        """Diagnose stuck problem"""
        # TODO: check app error code and puma error code
        result = dict()
        result['network'] = yield self.diagnose_network()
        result['boss'] = yield self.diagnose_boss()
        result['vrs'] = yield self.diagnose_vrs()
        result['pdata'] = yield self.diagnose_pdata()
        result['cache'] = yield self.diagnose_cache()

        logger.info('result=%s', result)
        raise Return(result)

@coroutine
def main():
    from tornado.gen import sleep

    content = None
    with open('data') as f:
        content = json.loads(f.read())

    logger.info('content=%s', content)

    p = StuckDiagnostic(content)
    res = yield p.diagnose()
    print(str(res))
    yield sleep(3)
    io_loop.stop()

if __name__  == "__main__":
    io_loop = ioloop.IOLoop.instance()
    io_loop.add_callback(main)
    io_loop.start()
