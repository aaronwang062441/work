#!/usr/bin/env python
# encoding: utf-8
"""Main application module

This module is used to define aem portal application, which provides most of
aem backend services as http services, it includes admin dashbaord and open
api: the dashboard is designed to provide data visulization for play stucking
analyzed and cached data, also some relavent functions to help researching
play stucking info; the open api is used to provide a data backend organizing
mysql and mongo data as useful for developers
"""

import os
import sys
import logging

from tornado.web import Application


class App(Application):
    """Application class

    This application is a tornado based http server, it includes a backend
    admin dashboard, and an restful open data api. The entry of the application
    will utilize mongo and mysql database too
    """
    def __init__(self):
        self.init_path()

    def init_path(self):
        """Initialize module path"""
        app_dir = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, app_dir)

    def init_logger(self):
        """Initialize logging"""
        from common.log import Log
        Log.create()

    def init_routes(self, subpackages=[]):
        """Initialize application routes"""
        import pkgutil
        from utils.decorators import route

        url_routes = []

        logging.info('sys.path=%s' % sys.path)
        cur_path, pkg_name = os.path.dirname(__file__), __package__
        for subpackage in subpackages:
            pkg_path = [os.path.join(cur_path, subpackage)]
            pkg_prefix = "%s.%s." % (pkg_name, subpackage)
            for importer, modname, ispkg in pkgutil.iter_modules(pkg_path, pkg_prefix):
                try:
                    logging.info('loading module %s' % modname)
                    __import__(modname)
                except ImportError, e:
                    logging.warn('%s: %s' % (self.__class__.__name__, e))
                except Exception, e:
                    logging.warn('%s: %s' % (self.__class__.__name__, e))

        url_routes.extend(route.get_routes())

        return url_routes

    def main(self):
        """Main routine of the application"""
        import tornado.httpserver
        import tornado.options
        import tornado.ioloop
        import tornado.web
        import config.options

        from tornado.options import options
        from common.mongodb import MongoDB
        from common.mysqldb import MysqlDB
        from common.request import NotFoundHandler
        from common.session import SessionManager

        # Parse configure file and command line
        cfg_path = os.path.join(os.path.dirname(__file__), "config/settings.py")
        tornado.options.parse_config_file(cfg_path)
        tornado.options.parse_command_line()

        # Initialize logger
        self.init_logger()

        # Create Mongo singleton
        MongoDB.create(
            host=options.mongodb_host,
            port=options.mongodb_port,
            username=options.mongodb_username,
            password=options.mongodb_password
        )
        # Create mysql singleton
        MysqlDB.create(
            host=options.mysqldb_host,
            port=options.mysqldb_port,
            username=options.mysqldb_username,
            password=options.mysqldb_password,
            database=options.mysqldb_database
        )
        # Create session manager
        SessionManager.create(
            secret=options.session_secret,
            backend=options.session_backend,
            timeout=options.session_timeout
        )

        # Initialize application url routes
        url_routes = self.init_routes(['api', 'dashboard'])

        # Apply application setting
        settings = dict(
            template_path = options.template_dir,
            static_path = options.static_path,
            cookie_secret = options.cookie_secret,
            login_url = '/dashboard/login',
            default_handler_class=NotFoundHandler,
            debug = options.debug
        )

        # Create tornado application and http server
        application = tornado.web.Application(url_routes, **settings)
        http_server = tornado.httpserver.HTTPServer(application)
        http_server.listen(options.port)

        logging.info("Ready and listening at %d" % options.port)

        # Start tornado ioloop service to handle http requests
        tornado.ioloop.IOLoop.current().start()


def main(argv=None):
    """Entry function of the application"""
    app = App()
    app.main()

if __name__ == "__main__":
    main()
