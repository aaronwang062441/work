#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

with open('README.rst') as readme_file:
    readme = readme_file.read()

with open('CHANGELOG.rst') as history_file:
    history = history_file.read()

requirements = [
]

test_requirements = [
    'mock',
    'nose',
    'unitest2',
    'docutils',
]

setup(
    name='aem_portal',
    version='0.1.0',
    description="AEM portal including open api and web dashboard",
    long_description=readme + '\n\n' + history,
    author="Gui Chen",
    author_email='gui.g.chen@gmail.com',
    url='https://gitlab.qiyi.domain/chengui/aem_portal',
    packages=find_packages(exclude=["*.tests", "*.tests.*", "tests.*", "tests"]),
    include_package_data=True,
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            'aem-portal = aem_portal.app:main'
        ]
    },
    zip_safe=False,
    keywords='aem_portal',
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        "Programming Language :: Python :: 2",
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
    ],
    test_suite='tests',
    tests_require=test_requirements
)
