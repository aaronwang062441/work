$(document).ready(function (){
    if (bootload.params === null) {
        var sdt = $.url.param('sdt');
        var edt = $.url.param('edt');
        var isp = $.url.param('isp');
        var prvn = $.url.param('prvn');
        var city = $.url.param('city');

        if (!!sdt && !!edt) {
            sdt = Date.strptime(sdt, '%Y%m%d%H%M%S');
            edt = Date.strptime(edt, '%Y%m%d%H%M%S');
            var params = {
                'sdt' : sdt,
                'edt' : edt,
                'isp' : isp || "0",
                'prvn': prvn || "0",
                'city': city || "0"
            };

            bootload.params = params;
        }
    }

    $('#submit').click(function (e) {
        e.preventDefault();

        var title = $('#table-panel').attr('data-title');
        var api = $('#table-panel').attr('data-url');

        var params = {
            'sdt':  $('#start-datetime').val(),
            'edt':  $('#end-datetime').val(),
            'isp':  $('#isp-select').val(),
            'prvn': $('#prvn-select').val(),
            'city': $('#city-select').val() || "0"
        };

        if (!params.sdt || !params.edt) {
            alert("请选择时间范围");
            return;
        }
        if (!params.isp) {
            alert("请选择运营商");
            return;
        }
        if (!params.prvn) {
            alert("请选择省份");
            return;
        }

        params.sdt = Date.strptime(params.sdt, '%Y-%m-%d %H:%M:%S');
        params.edt = Date.strptime(params.edt, '%Y-%m-%d %H:%M:%S');

        console.log('params=',params);
        ajax_datatable(api, title, params);
    });

    $('#msg-dialog').on('show.bs.modal', function (e) {
        var link = $(e.relatedTarget);
        $(this).find('.modal-title').text('详细信息');
        $(this).find('.modal-body').load(link.attr('href'), function (resp, status, xhr) {
            if (status == "success") {
                var data = JSON.parse(resp);
                $(this).html('<pre id="output">' + JSON.stringify(data, null, 2) + '</pre>');
            }
            if (status == "error") {
                alert('Error: ' + xhr.status + ', ' + xhr.statusText);
            }
        });
    });
});

function params_handler(params) {
    console.log('params=',params);
    $('#start-datetime').datetimepicker('setDate', params.sdt);
    $('#end-datetime').datetimepicker('setDate', params.edt);

    $.when($.get('/api/view/filter/isp.json')).done(function (_) {
        $('#isp-select').prop("value", params.isp);
    });
    $.when($.get('/api/view/filter/prvn.json')).done(function (_) {
        $('#prvn-select').prop("value", params.prvn);
        $('#prvn-select').trigger('change');
        $.when($.get('/api/view/filter/city.json')).done(function (_) {
            $('#city-select').prop("value", params.city);
            $('#city-select').trigger('change');
        });
    });

    var title = $('#table-panel').attr('data-title');
    var api = $('#table-panel').attr('data-url');

    console.log('title=',title,',api=',api,',params=',params);
    ajax_datatable(api, title, params);
}

function ajax_datatable(api, title, params) {
    var sdt = params.sdt.strftime('%Y%m%d%H%M%S');
    var edt = params.edt.strftime('%Y%m%d%H%M%S');

    var url = api + "?sdt=" + sdt + "&edt=" + edt;
    if (params.isp !== "0") {
        url += "&isp=" + major_isps[params.isp].name;
    }
    if (params.prvn !== "0") {
        url += "&prvn=" + china_zones[params.prvn].name;
    }
    if (params.city !== "0") {
        cities = china_zones[params.prvn].cities;
        url += "&city=" + cities[params.city].name;
    }
    url += "&u=1";
    console.log('url=',url);

    var dtable = $('#table-panel').DataTable({
        "destroy": true,
        "ajax": {
            "url": url,
            "type": "GET",
            "dataSrc": function (json) {
                return json;
            }
        },
        "order": [[5, "desc"]],
        "columnDefs": [
            {'width': "10%", 'title': "-",      'targets': 0},
            {'width': "20%", 'title': "UUID",   'targets': 1},
            {'width': "20%", 'title': "区域",   'targets': 2},
            {'width': "20%", 'title': "IP地址", 'targets': 3},
            {'width': "20%", 'title': "TVID",   'targets': 4},
            {'width': "10%", 'title': "总数",   'targets': 5}
        ],
        "columns": [
            {
                "orderable": false,
                "data": null,
                "defaultContent": ''
            },
            {
                "data": "_id",
                "render": function (data, type, row, meta) {
                    return '<a href="/dashboard/stuckquery/user?sdt=' + sdt + '&edt=' + edt + '&uuid='+ data +'">' + data + '</a>';
                }
            },
            {"data": "zone" },
            {
                "data": "ip",
                "render": function (data, type, row, meta) {
                    var inner_html = '<a href="/dashboard/stuckquery/user?sdt=' + sdt + '&edt=' + edt + '&ip=' + data[0] + '">' + data[0] + '</a>';
                    if (data.length > 1) {
                        var links = data.slice(1).map(function (item) {
                            return '<a href="/dashboard/stuckquery/user?sdt=' + sdt + '&edt=' + edt + '&ip=' + item + '">' + item + '</a>';
                        });
                        inner_html += '<a data-toggle="collapse" href="#ip-' + row._id + '"> ...</a>';
                        inner_html += '<div id="ip-' + row._id + '" class="collapse">' + links.join("<br>") + '</div>';
                    }
                    return inner_html;
                }
            },
            {
                "data": "tvid",
                "render": function (data, type, row, meta) {
                    var links = data.map(function (item) {
                        return '<a href="http://qipu.qiyi.domain/int/entity/nocache/'+item+'.json" data-remote="false" data-toggle="modal" data-target="#msg-dialog">'+item+'</a>';
                    });
                    return '<a data-toggle="collapse" href="#tvid-' + row._id + '">展开' + data.length + '条</a>' +
                        '<div id="tvid-' + row._id +'" class="collapse">' + links.join("<br>") + '</div>';
                }
            },
            {"data": "total"}
        ]
    });
}
