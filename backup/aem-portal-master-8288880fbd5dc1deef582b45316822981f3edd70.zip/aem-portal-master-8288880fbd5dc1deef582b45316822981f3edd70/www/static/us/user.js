$(document).ready(function (){
    if (bootload.params === null) {
        var sdt = $.url.param('sdt');
        var edt = $.url.param('edt');
        var ip = $.url.param('ip');
        var uuid = $.url.param('uuid');
        var tvid = $.url.param('tvid');

        if (!!sdt && !!edt) {
            sdt = Date.strptime(sdt, '%Y%m%d%H%M%S');
            edt = Date.strptime(edt, '%Y%m%d%H%M%S');
            var params = {
                'sdt' : sdt,
                'edt' : edt
            };

            if (!!uuid) {
                params.opt_k = "uuid";
                params.opt_v = uuid;
            } else if (!!ip) {
                params.opt_k = "ip";
                params.opt_v = ip;
            } else if (!!tvid) {
                params.opt_k = "tvid";
                params.opt_v = tvid;
            }

            bootload.params = params;
        }
    }

    $('#submit').click(function (e) {
        e.preventDefault();

        var title = $('#table-panel').attr('data-title');
        var api = $('#table-panel').attr('data-url');

        var params = {
            'sdt':   $('#start-datetime').val(),
            'edt':   $('#end-datetime').val(),
            'opt_k': $('#opt-select').val(),
            'opt_v': $('#opt-value').val(),
            'inc_22': $('#check-complete').prop('checked')
        };

        if (!params.sdt || !params.edt) {
            alert("请选择时间范围");
            return;
        }
        if (!params.opt_v) {
            alert("请填写查询值");
            return;
        }

        params.sdt = Date.strptime(params.sdt, '%Y-%m-%d %H:%M:%S');
        params.edt = Date.strptime(params.edt, '%Y-%m-%d %H:%M:%S');

        console.log('params=',params);
        ajax_datatable(api, title, params);
    });

    $('#msg-dialog').on('show.bs.modal', function (e) {
        var link = $(e.relatedTarget);
        $(this).find('.modal-title').text('详细信息');
        $(this).find('.modal-body').load(link.attr('href'), function (resp, status, xhr) {
            if (status == "success") {
                var data = JSON.parse(resp);
                $(this).html('<pre id="output">' + JSON.stringify(data, null, 2) + '</pre>');
            }
            if (status == "error") {
                alert('Error: ' + xhr.status + ', ' + xhr.statusText);
            }
        });
    });
});

function params_handler(params) {
    console.log('params=',params);
    $('#start-datetime').datetimepicker('setDate', params.sdt);
    $('#end-datetime').datetimepicker('setDate', params.edt);

    $('#opt-select').prop("value", params.opt_k);
    $('#opt-value').prop("value", params.opt_v);

    var title = $('#table-panel').attr('data-title');
    var api = $('#table-panel').attr('data-url');

    console.log('title=',title,',api=',api,',params=',params);
    ajax_datatable(api, title, params);
}

function ajax_datatable(api, title, params) {
    var sdt = params.sdt.strftime('%Y%m%d%H%M%S');
    var edt = params.edt.strftime('%Y%m%d%H%M%S');

    var url = api + "?sdt=" + sdt + "&edt=" + edt;
    url += "&" + params.opt_k + "=" + params.opt_v;
    if (!params.inc_22) {
        url += "&u=1";
    }

    console.log('url=',url);

    var dtable = $('#table-panel').DataTable({
        "destroy": true,
        "ajax": {
            "url": url,
            "type": "GET",
            "dataSrc": function (json) {
                return json;
            }
        },
        "order": [[0, "asc"]],
        "columnDefs": [
            {'title': "时间",     'targets': 0},
            {'title': "UUID",     'targets': 1},
            {'title': "区域",     'targets': 2},
            {'title': "IP地址",   'targets': 3},
            {'title': "TVID",     'targets': 4},
            {'title': "step",     'targets': 5, 'visible': false},
            {'title': "错误类型", 'targets': 6},
            {'title': "详细",     'targets': 7}
        ],
        "columns": [
          {"data": "actime"},
          {"data": "uid"},
          {"data": "zone"},
          {"data": "ip"},
          {
              "data": "stuckinfo.play_result.tvid",
              "render": function (data, type, row, meta) {
                  return '<a href="http://qipu.qiyi.domain/int/entity/nocache/' + data + '.json" data-remote="false" data-toggle="modal" data-target="#msg-dialog">' + data + '</a>';
              }
          },
          {
              "data": "stuckinfo.play_result.step",
              "render": function (data, type, row, meta) {
                  return data;
              }
          },
          {
              "data": null,
              "render": function (data, type, row, meta) {
                  var step = row.stuckinfo.play_result.step;
                  var label = (step == 22) ? 'success' : 'danger';
                  return '<span class="label label-' + label + '">' + step_types[step] + '</span>';
              }
          },
          {
              "data": "_id",
              "render": function (data, type, row, meta) {
                  var dt = Date.strptime(row.actime, '%Y-%m-%d %H:%M:%S').strftime('%Y%m%d%H%M%S');
                  var link = '/api/ndct/stuck/detail?dt=' + dt + '&id=' + data;
                  return '<a class="glyphicon glyphicon-zoom-in" href="' + link + '" data-remote="false" data-toggle="modal" data-target="#msg-dialog">' + data + '</a>';
              }
          }
        ]
    });
}
