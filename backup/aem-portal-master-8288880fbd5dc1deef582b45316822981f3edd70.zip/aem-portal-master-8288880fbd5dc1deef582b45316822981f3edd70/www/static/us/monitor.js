$(document).ready(function (){
    var chart = echarts.init(document.getElementById('chart-panel'));

    if (bootload.params === null) {
        var sdt = $.url.param('sdt');
        var edt = $.url.param('edt');
        var isp = $.url.param('isp');
        var prvn = $.url.param('prvn');
        var city = $.url.param('city');

        var date, time;
        var now = new Date();
        if (!edt) {
            edt = now;
        } else {
            edt = Date.strptime(edt, '%Y%m%d%H%M%S');
        }
        if (!sdt) {
            sdt = Date.timedelta(now, -24*60*60);
        } else {
            sdt = Date.strptime(sdt, '%Y%m%d%H%M%S');
        }

        var params = {
            'sdt' : sdt,
            'edt' : edt,
            'isp' : isp || "0",
            'prvn': prvn || "0",
            'city': city || ""
        };

        bootload.chart = chart;
        bootload.params = params;
    }

    chart.on('click', function(params) {
        console.log('echart.click: params=',params);

        var hrefs = {};
        $('input:checkbox[name="checkbox-type"]').each(function (i) {
            if (!!$(this).attr('data-url')) {
                hrefs[$(this).val()] = $(this).attr('data-url');
            }
        });

        if (params.seriesName in hrefs) {
            var sdt = Date.strptime(params.name, '%Y-%m-%d %H:%M:%S');
            var edt = Date.timedelta(sdt, 5*60);

            var isp = $('#isp-select').val();
            var prvn = $('#prvn-select').val();

            var url = hrefs[params.seriesName];
            url += "?sdt=" + sdt.strftime('%Y%m%d%H%M%S');
            url += "&edt=" + edt.strftime('%Y%m%d%H%M%S');

            if (!!isp && isp !== "0") {
                url += "&isp=" + isp;
            }
            if (!!prvn && prvn !== "0") {
                url += "&prvn=" + prvn;
            }
            console.log('echart.click: url=',url,',sdt=',sdt,',edt=',edt);

            location.href = url;
        }
    });

    $('#type-all').click(function (e) {
        $('input:checkbox[name="checkbox-type"]').prop('checked', $(this).prop("checked"));
    });

    $('#submit').click(function (e) {
        e.preventDefault();

        var title = $('#chart-panel').attr('data-title');
        var api = $('#chart-panel').attr('data-url');

        var params = {
            'sdt'  : $('#start-datetime').val(),
            'edt'  : $('#end-datetime').val(),
            'isp'  : $('#isp-select').val(),
            'prvn' : $('#prvn-select').val(),
            'city' : $('#city-select').val()
        };

        if (!params.sdt || !params.edt) {
            alert("请选择时间范围");
            return;
        }
        if (!params.isp) {
            alert("请选择运营商信息");
            return;
        }
        if (!params.prvn) {
            alert("请选择省份信息");
            return;
        }

        var columns = [];
        $('input:checkbox[name="checkbox-type"]:checked').each(function (i) {
            columns.push($(this).val());
        });
        if (columns.length === 0) {
            alert("请选择故障类型");
            return;
        }

        params.sdt = Date.strptime(params.sdt, '%Y-%m-%d %H:%M:%S');
        params.edt = Date.strptime(params.edt, '%Y-%m-%d %H:%M:%S');

        console.log('submit.click: title=',title,',api=',api,',columns=',columns,',params=',params);
        ajax_trend(chart, api, title, columns, params);
    });
});

function params_handler(params) {
    console.log('params_handler: params=',params);

    $('#start-datetime').datetimepicker('setDate', params.sdt);
    $('#end-datetime').datetimepicker('setDate', params.edt);

    $.when($.get('/api/view/filter/isp.json')).done(function (_) {
        $('#isp-select').prop("value", params.isp);
    });
    $.when($.get('/api/view/filter/prvn.json')).done(function (_) {
        $('#prvn-select').prop("value", params.prvn);
        $('#prvn-select').trigger('change');
    });
    $.when($.get('/api/view/filter/city.json')).done(function (_) {
        $('#city-select').prop("value", params.prvn);
    });

    $('#type-all').prop("checked", true);
    $('input:checkbox[name="checkbox-type"]').prop('checked', true);

    var title = $('#chart-panel').attr('data-title');
    var api = $('#chart-panel').attr('data-url');

    var columns = [];
    $('input:checkbox[name="checkbox-type"]').each(function (i) {
        if ($(this).val() !== "all") {
            columns.push($(this).val());
        }
    });

    console.log('params_handler: title=',title,',api=',api,',columns=',columns,',params=',params);
    ajax_trend(bootload.chart, api, title, columns, params);
}

function ajax_trend(chart, api, title, columns, params) {
    var sdt = params.sdt.strftime('%Y%m%d%H%M%S');
    var edt = params.edt.strftime('%Y%m%d%H%M%S');

    var url = api + "?sdt=" + sdt + "&edt=" + edt;
    if (params.isp !== "0") {
        url += "&isp=" + params.isp;
    }
    if (params.prvn !== "0") {
        url += "&prvn=" + params.prvn;
    }
    if (params.city !== "") {
        url += "&city=" + params.city;
    }
    url += "&grp=time";
    console.log('ajax_trend: url=',url);

    $.get(url, function (data) {
        console.log('ajax_trend: typeof data=',typeof data,',data=',data);
        if (data.error !== undefined) {
            alert("图表请求数据失败：" + data.error);
        } else {
            chart.setOption({
                title: {
                    left: 'center',
                    text: title
                },
                legend: {
                    top: '5%',
                    data: columns
                },
                tooltip: {
                    trigger: 'axis'
                },
                xAxis: {
                    data: data.map(function (item) {
                        return item.time;
                    }),
                    splitLine: {
                        show: false
                    }
                },
                yAxis: {
                    type: 'value',
                    splitLine: {
                        show: false
                    }
                },
                toolbox: {
                    top: '10%',
                    right: '5%',
                    orient: 'vertical',
                    feature: {
                        dataView: {
                            show: true
                        },
                        dataZoom: {
                            yAxisIndex: 'none'
                        },
                        restore: {
                            show: true
                        },
                        saveAsImage: {
                            show: true
                        }
                    }
                },
                dataZoom: [
                    {
                        type: 'slider',
                        show: true
                    },
                    {
                        type: 'inside'
                    }
                ],
                series: columns.map(function (col) {
                    return {
                        name: col,
                        type: 'line',
                        data: data.map(function (item) {
                              return item[col];
                        })
                    };
                })
            }, true);
        }
    });
}
