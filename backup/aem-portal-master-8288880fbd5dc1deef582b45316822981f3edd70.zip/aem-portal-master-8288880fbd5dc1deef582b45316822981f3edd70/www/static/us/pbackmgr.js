$(document).ready(function () {
    var url = '/api/probetest/list';
    var dtable = $('#table-panel').DataTable({
        "destroy": true,
        "ajax": {
            "url": url,
            "type": "GET",
            "dataSrc": function (json) {
                return json;
            }
        },
        "order": [[0, "asc"], [2, "desc"]],
        "columnDefs": [
            {"title": "序号",     "targets": 0},
            {"title": "探测对象", "targets": 1},
            {"title": "探测类型", "targets": 2},
            {"title": "监控频率", "targets": 3},
            {"title": "监控状态", "targets": 4},
            {"title": "探测QPS",  "targets": 5},
            {"title": "操作",     "targets": 6}
        ],
        "columns": [
          {"data": "id"},
          {"data": "url"},
          {"data": "type"},
          {"data": "rate"},
          {"data": "status"},
          {"data": "qps"},
          {
              "data": null,
              "render": function (data, type, row, meta) {
                  return '<a class="add_policy glyphicon glyphicon-pencil" href="#" title="添加监控策略">添加监控策略</a>' +
                         '&nbsp;<span class="divider">|</span>&nbsp;' +
                         '<a class="view_probe glyphicon glyphicon-zoom-in" href="#" title="查看">查看</a>' +
                         '&nbsp;<span class="divider">|</span>&nbsp;' +
                         '<a class="edit_probe glyphicon glyphicon-edit" href="#" title="编辑">编辑</a>' +
                         '&nbsp;<span class="divider">|</span>&nbsp;' +
                         '<a class="delete_probe glyphicon glyphicon-trash" href="#" title="删除">删除</a>';
              }
          }
        ]
    });

    $(document).on('click', '#table-panel a.add_policy', function (e) {
        location.href = '/dashboard/pingback/policy';
    });

    $(document).on('click', '#table-panel a.view_probe', function (e) {
        e.preventDefault();
        var row = $(this).parents('tr')[0];
        var data = dtable.row(row).data();
        ProbeModal.view_probe(data);
    });

    $(document).on('click', '#table-panel a.edit_probe', function (e) {
        var row = $(this).parents('tr')[0];
        var data = dtable.row(row).data();
        ProbeModal.edit_probe(data).on(function (e) {
            var data = {
                "name": $('#name').val(),
                "type": $('#type').val(),
                "url":  $('#url').val(),
                "rate": $('#rate').val()
            };
            $.post('/api/probetest/update', data, function (ret) {
                dtable.ajax.reload();
                console.log('return: ',ret);
            })
        });
    });

    $(document).on('click', '#table-panel a.delete_probe', function (e) {
        var row = $(this).parents('tr')[0];
        var data = dtable.row(row).data();
        ProbeModal.delete_probe().on(function (e) {
            if (!e) return;
            $.get('/api/probetest/delete', {'id': data.id}, function (e) {
                dtable.ajax.reload();
                console.log('return: ',ret);
            });
        });
    });

    $('#add_probe').click(function (e) {
        e.preventDefault();
        var row = $(this).parents('tr')[0];
        var data = dtable.row(row).data();
        ProbeModal.add_probe().on(function (e) {
            var data = {
                "name": $("#name").val(),
                "type": $("#type").val(),
                "url":  $("#url").val(),
                "rate": $("#rate").val()
            };
            $.post('/api/probetest/add', data, function (ret) {
                dtable.ajax.reload();
                console.log('return: ',rc);
            });
        });
    });
});

$(function () {
    window.ProbeModal = function () {
        var regex = new RegExp("\\[([^\\[\\]]*?)\\]", 'igm');
        var object = $('#probe-modal');
        var ohtml = object.html();

        var _add_probe = function () {
            object.html(ohtml);  // restore

            _dialog({
                title: "新增探测任务",
                message: "",
                btnok: "新增",
                btncancel: "取消"
            });

            return {
                on: function (callback) {
                    if (callback && callback instanceof Function) {
                        object.find('.ok').click(function() {callback(true); });
                    }
                }
            };
        };

        var _view_probe = function (data) {
            object.html(ohtml);
            object.find('.form-control').prop('disabled', 'disabled');
            object.find('.ok').addClass('hidden');


            _dialog({
                title: "查看探测任务",
                message: "",
                btnok: "确定",
                btncancel: "取消"
            });

            $('#name').prop('value', data.name);
            $('#type').prop('value', data.type);
            $('#url').prop('value', data.url);
            $('#rate').prop('value', data.rate);
        };

        var _edit_probe = function (data) {
            object.html(ohtml);  // restore

            _dialog({
                title: "更新探测任务",
                message: "",
                btnok: "更新",
                btncancel: "取消"
            });

            $('#name').prop('value', data.name);
            $('#type').prop('value', data.type);
            $('#url').prop('value', data.url);
            $('#rate').prop('value', data.rate);

            return {
                on: function (callback) {
                    if (callback && callback instanceof Function) {
                        object.find('.ok').click(function() {callback(true); });
                    }
                }
            };
        };

        var _delete_probe = function () {
            object.html(ohtml);  // restore
            object.find('.form-horizontal').addClass('hidden');

            _dialog({
                title: "删除探测任务",
                message: "确认删除该探测任务吗？",
                btnok: "确认",
                btncancel: "取消"
            });

            return {
                on: function (callback) {
                    if (callback && callback instanceof Function) {
                        object.find('.ok').click(function() {callback(true); });
                    }
                }
            };
        };

        var _dialog = function (options) {
            var opts = {
                title: "操作提示",
                message: "提示内容",
                btnok: "确定",
                btncancel: "取消"
            };

            $.extend(opts, options);

            var html = object.html().replace(regex, function (node, key) {
                return {
                    Title: opts.title,
                    Message: opts.message,
                    BtnOK: opts.btnok,
                    BtnCancel: opts.btncancel
                }[key];
            });

            object.html(html);
            object.modal({
                backdrop: 'static'
            });

        };

        return {
            add_probe: _add_probe,
            view_probe: _view_probe,
            edit_probe: _edit_probe,
            delete_probe: _delete_probe
        };
    }();
});
