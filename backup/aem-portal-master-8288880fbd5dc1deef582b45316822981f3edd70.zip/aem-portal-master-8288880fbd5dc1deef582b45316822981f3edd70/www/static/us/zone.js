$(document).ready(function (){
    var chart = echarts.init(document.getElementById('chart-panel'));

    if (bootload.params === null) {
        var sdt = $.url.param('sdt');
        var edt = $.url.param('edt');
        var isp = $.url.param('isp');
        var prvn = $.url.param('prvn');

        var date, time;
        var now = new Date();
        if (!edt) {
            edt = now;
        } else {
            edt = Date.strptime(edt, '%Y%m%d%H%M%S');
        }
        if (!sdt) {
            sdt = Date.timedelta(now, -24*60*60);
        } else {
            sdt = Date.strptime(sdt, '%Y%m%d%H%M%S');
        }

        var params = {
            'sdt' : sdt,
            'edt' : edt,
            'isp' : isp || "0",
            'prvn': prvn || "0"
        };

        bootload.chart = chart;
        bootload.params = params;
    }

    chart.on('click', function(params) {
        console.log('echart.click: params=',params);

        var is_china = null;
        for (var pn in china_zones) {
            if (china_zones[pn].text == params.name) {
                is_china = pn;
            }
        }

        if (!!is_china) {
            $.when($.get('/api/view/filter/prvn.json')).done(function (_) {
                $('#prvn-select').prop("value", is_china);
                $('#submit').trigger('click');
            });
        } else {
            var hrefs = {};
            $('input:radio[name="radio-type"]').each(function (i, item) {
                if (!!$(this).attr('data-url')) {
                    hrefs[$(this).val()] = $(this).attr('data-url');
                }
            });
            console.log(params);
            if (params.seriesName in hrefs) {
                var sdt = Date.strptime($('#start-datetime').val(), '%Y-%m-%d %H:%M:%S');
                var edt = Date.strptime($('#end-datetime').val(), '%Y-%m-%d %H:%M:%S');

                var isp = $('#isp-select').val();
                var prvn = $('#prvn-select').val();
                var city = params.data.id;

                var url = hrefs[params.seriesName];
                url += "?sdt=" + sdt.strftime('%Y%m%d%H%M%S');
                url += "&edt=" + edt.strftime('%Y%m%d%H%M%S');
                console.log('echart.click: url=',url,',sdt=',sdt,',edt=',edt);

                if (!!isp && isp !== "0") {
                    url += "&isp=" + isp;
                }
                if (!!prvn && prvn !== "0") {
                    url += "&prvn=" + prvn;
                }
                if (!!city && city !== "0") {
                    url += "&city=" + city;
                }
                console.log('echart.click: url=',url);

                location.href = url;
            }
        }
    });

    var all_types = [];
    $('input:radio[name="radio-type"]').each(function (i, item) {
        if($(this).val() !== "all") {
            all_types.push($(this).val());
        }
    });

    $('#submit').click(function (e) {
        e.preventDefault();

        var params = {
            'sdt'  : $('#start-datetime').val(),
            'edt'  : $('#end-datetime').val(),
            'isp'  : $('#isp-select').val(),
            'prvn' : $('#prvn-select').val()
        };

        if (!params.sdt || !params.edt) {
            alert("请选择时间范围");
            return;
        }
        if (!params.isp) {
            alert("请选择运营商信息");
            return;
        }
        if (!params.prvn) {
            alert("请选择省份信息");
            return;
        }

        if (params.prvn !== "0") {
            var cities = china_zones[params.prvn].cities;
            if (Object.keys(cities).length <= 1) {
                alert("选择为直辖市或特别行政区，没有城市信息");
                return;
            }
        }

        var columns = [];
        var err_type = $('input:radio[name="radio-type"]:checked').val();
        if (!err_type) {
            alert("请选择故障类型");
            return;
        } else if (err_type === "all") {
            columns = all_types;
        } else {
            columns = [err_type];
        }
        console.log('submit.click: columns=',columns);

        params.sdt = Date.strptime(params.sdt, '%Y-%m-%d %H:%M:%S');
        params.edt = Date.strptime(params.edt, '%Y-%m-%d %H:%M:%S');

        console.log('submit.click: columns=',columns,',params=',params);
        ajax_map(bootload.chart,
            $('#chart-panel').data('url'),
            $('#chart-panel').data('title'),
            columns, params);
        ajax_top(
            $('#top-isp-panel').data('url'),
            $('#top-isp-panel').data('title'),
            columns, params);
    });
});

function params_handler(params) {
    console.log('params_handler: params=',params);
    $('#start-datetime').datetimepicker('setDate', params.sdt);
    $('#end-datetime').datetimepicker('setDate', params.edt);

    $.when($.get('/api/view/filter/isp.json')).done(function (_) {
        $('#isp-select').prop("value", params.isp);
    });
    $.when($.get('/api/view/filter/prvn.json')).done(function (_) {
        $('#prvn-select').prop("value", params.prvn);
    });

    $('#type-all').prop("checked", true);
    $('input:checkbox[name="checkbox-type"]').prop('checked', true);

    var columns = [];
    $('input:radio[name="radio-type"]').each(function (i, item) {
        if ($(this).val() !== "all") {
            columns.push($(this).val());
        }
    });

    console.log('params_handler: columns=',columns,',params=',params);
    ajax_map(bootload.chart,
        $('#chart-panel').data('url'),
        $('#chart-panel').data('title'),
        columns, params);
    ajax_top(
        $('#top-isp-panel').data('url'),
        $('#top-isp-panel').data('title'),
        columns, params);
}

function ajax_map(chart, api, title, columns, params) {
    var sdt = params.sdt.strftime('%Y%m%d%H%M%S');
    var edt = params.edt.strftime('%Y%m%d%H%M%S');

    var url = api + "?sdt=" + sdt + "&edt=" + edt;
    if (params.isp !== "0") {
        url += "&isp=" + params.isp;
    }

    var zones, zone_name, map_type;
    if (params.prvn === "0") {
        url += "&grp=prvn";
        zones = china_zones;
        zone_name = 'prvn';
        map_type = 'china';
    } else {
        url += "&prvn=" + params.prvn + "&grp=city";
        zones = china_zones[params.prvn].cities;
        zone_name = 'city';
        map_type = 'city-map';

        // register city map
        var prvn_name = china_zones[params.prvn].name.toLowerCase();
        $.ajax({
            type: "GET",
            url: '/static/bower_components/echarts/map/json/province/'+prvn_name+'.json',
            success: function (geoJson) {
                echarts.registerMap('city-map', geoJson);
            },
            error: function (err) {
                console.lgo(err);
            }
        });
    }
    console.log('ajax_map: url=',url);

    $.get(url, function (data) {
        console.log('ajax_map: typeof data=',typeof data,'\ndata=',data);
        if (data.error !== undefined) {
            alert("图表请求数据失败：" + data.error);
        } else {
            var min_range = 0;
            var max_range = 1000;

            var map_data = {};
            for (var i = 0; i < data.length; i++) {
                var total = 0;
                for (var j = 0; j < columns.length; j++) {
                    var col = columns[j];
                    var id = data[i][zone_name].toString();
                    if (!(col in map_data)) {
                        map_data[col] = [];
                    }
                    if (id in zones) {
                        total += data[i][col];
                        map_data[col].push({
                            id: id,
                            name: zones[id].text,
                            value: data[i][col]
                        });
                    }
                }
                if (total > max_range) {
                    max_range = total;
                }
            }

            chart.setOption({
                title: {
                    left: 'center',
                    text: title
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    data: columns
                },
                tooltip: {
                    trigger: 'item',
                    formatter: function (params) {
                        var res = '';
                        var total = 0;
                        var myseries = chart.getOption().series;
                        for (var i = 0; i < myseries.length; i++) {
                            for (var j = 0; j < myseries[i].data.length; j++) {
                                if (myseries[i].data[j].name == params.name) {
                                    res += myseries[i].name + ' : ' + myseries[i].data[j].value + '</br>';
                                    total += myseries[i].data[j].value;
                                }
                            }
                        }
                        res += params.name + ' : ' + total + '</br>';
                        return res;
                    }
                },
                visualMap: {
                    min: min_range,
                    max: max_range,
                    left: 'left',
                    top: 'bottom',
                    text: ['高', '低'],
                    calculable: true
                },
                toolbox: {
                    show: true,
                    orient: 'vertical',
                    left: 'right',
                    top: 'center',
                    feature: {
                        mark: {
                            show: true
                        },
                        dataView: {
                            show: true
                        },
                        restore: {
                            show: true
                        },
                        saveAsImage: {
                            show: true
                        }
                    }
                },
                series: columns.map(function (column) {
                    return {
                        name: column,
                        type: 'map',
                        mapType: map_type,
                        mapLocation: {
                            x: 'left',
                            y: 'top'
                        },
                        selectedMode: 'single',
                        roam: false,
                        itemStyle: {
                            normal: {
                            },
                            emphasis: {
                            }
                        },
                        label: {
                            normal: {
                                show: true
                            },
                            emphasis: {
                                show: true
                            }
                        },
                        data: map_data[column]
                    };
                })
            }, true);
        }
    });
}

function ajax_top(api, title, columns, params) {
    var sdt = params.sdt.strftime('%Y%m%d%H%M%S');
    var edt = params.edt.strftime('%Y%m%d%H%M%S');

    var url = api + "?sdt=" + sdt + "&edt=" + edt;
    if (!!params.prvn && params.prvn !== "0") {
        url += "&prvn=" + params.prvn;
    }
    if (!!params.city && params.city !== "0") {
        url += "&city=" + params.city;
    }
    console.log('ajax_top.url=',url);

    columns = ['isp_cn', 'total'].concat(columns);

    $(document).on('preInit.dt', function (e, settings) {
        $('#table-title').html('<h4><b>' + title + '</b></h4>');
    });
    var dtable = $('#top-isp-panel').DataTable({
        "dom": '<"#table-title">ti',
        "destroy": true,
        "ajax": {
            "url": url,
            "type": "GET",
            "dataSrc": ""
        },
        "order": [[1, "desc"]],
        "columns": columns.map(function (item) {
            return {'title': item, 'data': item};
        })
    });
}
