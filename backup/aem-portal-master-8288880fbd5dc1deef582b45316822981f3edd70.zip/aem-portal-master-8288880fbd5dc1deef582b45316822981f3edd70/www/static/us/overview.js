$(document).ready(function (){
    var chart = echarts.init(document.getElementById('chart-panel'));
    var top_isp = echarts.init(document.getElementById('top-isp-panel'));
    var top_prvn = echarts.init(document.getElementById('top-prvn-panel'));
    var top_city = echarts.init(document.getElementById('top-city-panel'));

    window.onresize = function (e) {
        chart.resize();
        top_isp.resize();
        top_prvn.resize();
        top_city.resize();
    }

    if (bootload.params === null) {
        var sdt = $.url.param('sdt');
        var edt = $.url.param('edt');
        var isp = $.url.param('isp');
        var prvn = $.url.param('prvn');

        var now = new Date();
        if (!edt) {
            edt = now;
        } else {
            edt = Date.strptime(edt, '%Y%m%d%H%M%S');
        }
        if (!sdt) {
            sdt = Date.timedelta(now, -24*60*60);
        } else {
            sdt = Date.strptime(sdt, '%Y%m%d%H%M%S');
        }

        var params = {
            'sdt' : sdt,
            'edt' : edt,
            'isp' : isp || "0",
            'prvn': prvn || "0"
        };

        bootload.chart = chart;
        bootload.top_isp = top_isp;
        bootload.top_prvn = top_prvn;
        bootload.top_city = top_city;
        bootload.params = params;
    }

    chart.on('click', function(params) {
        console.log('echart.click: params=',params);

        var hrefs = {};
        $('input:checkbox[name="checkbox-type"]').each(function (i) {
            if (!!$(this).attr('data-url')) {
                hrefs[$(this).val()] = $(this).attr('data-url');
            }
        });

        if (params.seriesName in hrefs) {
            var sdt = Date.strptime(params.name, '%Y-%m-%d %H:%M:%S');
            var edt = Date.timedelta(sdt, 5*60);

            var isp = $('#isp-select').val();
            var prvn = $('#prvn-select').val();

            var url = hrefs[params.seriesName];
            url += "?sdt=" + sdt.strftime('%Y%m%d%H%M%S');
            url += "&edt=" + edt.strftime('%Y%m%d%H%M%S');

            if (!!isp && isp !== "0") {
                url += "&isp=" + isp;
            }
            if (!!prvn && prvn !== "0") {
                url += "&prvn=" + prvn;
            }
            console.log('echart.click: url=',url,',sdt=',sdt,',edt=',edt);

            location.href = url;
        }
    });

    $('#type-all').click(function (e) {
        $('input:checkbox[name="checkbox-type"]').prop('checked', $(this).prop("checked"));
    });

    $('#submit').click(function (e) {
        e.preventDefault();

        var params = {
            'sdt' : $('#start-datetime').val(),
            'edt' : $('#end-datetime').val(),
            'isp' : $('#isp-select').val(),
            'prvn': $('#prvn-select').val()
        };

        if (!params.sdt || !params.edt) {
            alert("请选择时间范围");
            return;
        }
        if (!params.isp) {
            alert("请选择运营商信息");
            return;
        }
        if (!params.prvn) {
            alert("请选择省份信息");
        }

        var columns = [];
        $('input:checkbox[name="checkbox-type"]:checked').each(function (i) {
            columns.push($(this).val());
        });
        if (columns.length === 0) {
            alert("请选择故障类型");
            return;
        }

        params.sdt = Date.strptime(params.sdt, '%Y-%m-%d %H:%M:%S');
        params.edt = Date.strptime(params.edt, '%Y-%m-%d %H:%M:%S');

        console.log('submit.click: columns=',columns,',params=',params);
        ajax_trend(bootload.chart,
            $('#chart-panel').data('url'),
            $('#chart-panel').data('title'),
            columns, params);
        ajax_top(bootload.top_isp,
            $('#top-isp-panel').data('label'),
            $('#top-isp-panel').data('url'),
            $('#top-isp-panel').data('title'),
            columns, params);
        ajax_top(bootload.top_prvn,
            $('#top-prvn-panel').data('label'),
            $('#top-prvn-panel').data('url'),
            $('#top-prvn-panel').data('title'),
            columns, params);
        ajax_top(bootload.top_city,
            $('#top-city-panel').data('label'),
            $('#top-city-panel').data('url'),
            $('#top-city-panel').data('title'),
            columns, params);
        });
});

function params_handler(params) {
    console.log('params=',params);
    $('#start-datetime').datetimepicker('setDate', params.sdt);
    $('#end-datetime').datetimepicker('setDate', params.edt);

    $.when($.get('/api/view/filter/isp.json')).done(function (_) {
        $('#isp-select').prop("value", params.isp);
    });
    $.when($.get('/api/view/filter/prvn.json')).done(function (_) {
        $('#prvn-select').prop("value", params.prvn);
    });

    $('#type-all').prop("checked", true);
    $('input:checkbox[name="checkbox-type"]').prop('checked', true);

    var title = $('#chart-panel').attr('data-title');
    var api = $('#chart-panel').attr('data-url');

    var columns = [];
    $('input:checkbox[name="checkbox-type"]').each(function (i) {
        if ($(this).val() !== "all") {
            columns.push($(this).val());
        }
    });

    ajax_trend(bootload.chart,
        $('#chart-panel').data('url'),
        $('#chart-panel').data('title'),
        columns, params);
    ajax_top(bootload.top_isp,
        $('#top-isp-panel').data('label'),
        $('#top-isp-panel').data('url'),
        $('#top-isp-panel').data('title'),
        columns, params);
    ajax_top(bootload.top_prvn,
        $('#top-prvn-panel').data('label'),
        $('#top-prvn-panel').data('url'),
        $('#top-prvn-panel').data('title'),
        columns, params);
    ajax_top(bootload.top_city,
        $('#top-city-panel').data('label'),
        $('#top-city-panel').data('url'),
        $('#top-city-panel').data('title'),
        columns, params);
}

function ajax_trend(chart, api, title, columns, params) {
    var sdt = params.sdt.strftime('%Y%m%d%H%M%S');
    var edt = params.edt.strftime('%Y%m%d%H%M%S');

    var url = api + "?sdt=" + sdt + "&edt=" + edt;
    if (params.isp !== "0") {
        url += "&isp=" + params.isp;
    }
    if (params.prvn !== "0") {
        url += "&prvn=" + params.prvn;
    }
    url += "&grp=time";
    console.log('ajax_trend: url=',url);

    $.get(url, function (data) {
        console.log('ajax_trend: typeof data=',typeof data,'\ndata=',data);
        if (data.error !== undefined) {
            alert("图表请求数据失败：" + data.error);
        } else {
            chart.setOption({
                title: {
                    left: 'center',
                    text: title
                },
                legend: {
                    top: '5%',
                    data: columns
                },
                // grid: {
                    // left: '3%',
                    // right: '3%',
                    // bottom: '3%',
                    // containLabel: true
                // },
                tooltip: {
                    trigger: 'axis'
                },
                xAxis: {
                    data: data.map(function (item) {
                        return item.time;
                    }),
                    splitLine: {
                        show: false
                    }
                },
                yAxis: {
                    type: 'value',
                    splitLine: {
                        show: false
                    }
                },
                toolbox: {
                    top: '10%',
                    right: '5%',
                    orient: 'vertical',
                    feature: {
                        dataView: {
                            show: true
                        },
                        dataZoom: {
                            yAxisIndex: 'none'
                        },
                        restore: {
                            show: true
                        },
                        saveAsImage: {
                            show: true
                        }
                    }
                },
                dataZoom: [
                    {
                        type: 'slider',
                        show: true
                    },
                    {
                        type: 'inside'
                    }
                ],
                series: columns.map(function (col) {
                    return {
                        name: col,
                        type: 'line',
                        data: data.map(function (item) {
                              return item[col];
                        })
                    };
                })
            }, true);
        }
    });
}

function ajax_top(chart, label, api, title, columns, params) {
    var sdt = params.sdt.strftime('%Y%m%d%H%M%S');
    var edt = params.edt.strftime('%Y%m%d%H%M%S');

    var url = api + "?sdt=" + sdt + "&edt=" + edt + "&limit=5";
    console.log('ajax_top: url=',url);

    $.get(url, function (data) {
        console.log('ajax_top.data=',data);
        if (data.error !== undefined) {
        } else {
            chart.setOption({
                title: {
                    show: true,
                    text: title
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                // legend: {
                    // data: columns
                // },
                grid: {
                    left: '10%',
                    right: '3%',
                    top: '20%',
                    bottom: '3%'
                },
                xAxis: [{
                    type: 'value',
                    show: false,
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    position: 'top',
                    boundaryGap: [0, 0]
                }],
                yAxis: [{
                    type: 'category',
                    show: true,
                    data: data.map(function (item) {
                        return item[label];
                    }).reverse(),
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        txtStyle: {
                            fontSize: '20'
                        }
                    }
                }],
                series: columns.map(function (col) {
                    return {
                        name: col,
                        type: 'bar',
                        stack: '总量',
                        barWidth: '80%',
                        label: {
                            normal: {
                                show: false
                            }
                        },
                        data: data.map(function (item) {
                            return item[col];
                        }).reverse()
                    };
                })
            }, true);
        }
    });
}
