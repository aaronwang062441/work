from __future__ import print_function
import re
import json
import datetime
import logging
import MySQLdb as mysql
from multiprocessing.dummy import Pool as ThreadPool

DEBUG = True

conn_opts = {
    'host': 'sjhl.netdoctor.w.qiyi.db',
    'port': 8498,
    'user': 'netdoctor',
    'password': '%ZjLUoTW',
    'database': 'netdoctor'
}

def enum(*seq, **named):
    enums = dict(zip(seq, range(len(seq))), **named)
    return type('Enum', (), enums)

Steps = enum(
    'ERROR_VIDTVID',
    'NETWORK_START',
    'NETWORK_FAILED',
    'NETWORK_OK',
    'USER_PREPAREBEGIN',
    'USER_PREPAREOK',
    'USER_PREPAREFAILED',
    'VRS_VIDBEGIN',
    'VRS_VIDOK',
    'VRS_VIDFAILD',
    'GET_KEYBEGIN',
    'GET_KEYOK',
    'GET_KEYFAILED',
    'GET_M3U8BEGIN',
    'GET_M3U8OK',
    'GET_M3U8FAILED',
    'AUT_BEGIN',
    'AUT_OK',
    'AUT_FAILED',
    'DOWNLOAD_BEGIN',
    'DOWNLOAD_FAILED',
    'DOWNLOAD_END',
    'COMPLETE',
    'VRS_URL_HIJACK',
    'PDATA_URL_HIJACK',
    'DOWNLOAD_URL_HIJACK',
    'GET_M3U8_URL_HIJACK',
)

Errcode = enum(
    'ERR_OK',
    'ERR_COMPLETE',
    'ERR_DOWNLOAD',
    'ERR_VRS_ACCESS',
    'ERR_PDATA_ACCESS',
)

Errtuple = [
    # TOTAL, OK, complete, download, vrs_acc, pdata_acc,
    (1, 1, 0, 0, 0, 0, 0, 0, 0, 0),
    (1, 0, 1, 0, 0, 0, 0, 0, 0, 0),
    (1, 0, 0, 1, 0, 0, 0, 0, 0, 0),
    (1, 0, 0, 0, 1, 0, 0, 0, 0, 0),
    (1, 0, 0, 0, 0, 1, 0, 0, 0, 0),
    (1, 0, 0, 0, 0, 0, 1, 0, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 1, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 0, 1, 0),
    (1, 0, 0, 0, 0, 0, 0, 0, 0, 1),
]

rules = [
    lambda p: p["step"] == Steps.COMPLETE and p["cache_status"]["avg_speed"] == 0 and Errcode.ERR_COMPLETE or Errcode.ERR_OK,
    lambda p: p["step"] == Steps.DOWNLOAD_FAILED and Errcode.ERR_DOWNLOAD or Errcode.ERR_OK,
    lambda p: (p["step"] == Steps.VRS_VIDFAILD or p["step"] == Steps.VRS_URL_HIJACK) and Errcode.ERR_VRS_ACCESS or Errcode.ERR_OK,
    lambda p: (p["step"] == Steps.AUT_FAILED or p["step"] == Steps.PDATA_URL_HIJACK) and Errcode.ERR_PDATA_ACCESS or Errcode.ERR_OK,
]

logger = None

def initlog(name):
    global logger
    logger = logging.getLogger(name)
    formatter = logging.Formatter('%(asctime)s %(message)s', '%Y-%m-%d %H:%M:%S',)
    file_handler = logging.FileHandler("%s.log" % name)
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.ERROR)
    logger.addHandler(file_handler)
    logger.setLevel(logging.ERROR)

def odbreq(sql):
    res = ()
    try:
        conn = mysql.connect(host=conn_opts['host'], port=conn_opts['port'], user=conn_opts['user'], passwd=conn_opts['password'], db=conn_opts['database'])
        cur = conn.cursor(cursorclass=mysql.cursors.DictCursor)
        cur.execute(sql)
        res = cur.fetchall()
        cur.close()
        conn.close()
    except Exception, e:
        if DEBUG: print(e)
    return res

def count(dct, tup):
    if not tup[0] in dct:
        dct[tup[0]] = tup[1]
    else:
        y = tup[1]
        x = dct[tup[0]]
        dct[tup[0]] = (x[0]+y[0], x[1]+y[1], x[2]+y[2], x[3]+y[3], x[4]+y[4], x[5]+y[5], x[6]+y[6], x[7]+y[7], x[8]+y[8], x[9]+y[9])
    return dct

def merge(dct1, dct2):
    dct = reduce(count, dct1.items() + dct2.items(), {})
    return dct

def hijack_url(idx, pres):
    if 'url_hijack' in pres['access_vrs']:
        return "%d %s %s" % (idx, pres['access_vrs']['url'], pres['access_vrs']['url_hijack'])
    if 'access_pdata' in pres and 'url_hijack' in pres['access_pdata']:
        return "%d %s %s" % (idx, pres['access_pdata']['url'], pres['access_pdata']['url_hijack'])
    if 'url_hijack' in pres['cache_status']:
        return "%d %s %s" % (idx, pres['cache_status']['url'], pres['cache_status']['url_hijack'])
    return None

def parse(item):
    stuckinfo = {}
    try:
        stuckinfo = json.loads(item['stuckinfo'])
    except ValueError, e:
        match, errmsg = None, str(e)
        if errmsg.startswith('No JSON'):
            pattern = re.compile(r'((tel=(\d+)?,)?cdnresult = |tel=(\d+)?,){')
            match = pattern.match(item['stuckinfo'])
            if match: stuckinfo = json.loads(item['stuckinfo'].replace(match.group(0), '{'))
        elif errmsg.startswith('Expecting , delimiter:'):
            pattern = re.compile(r'"return_data":\s*"{(.*)}",')
            match = pattern.match(item['stuckinfo'])
            if match: stuckinfo = json.loads(item['stuckinfo'].replace(match.group(1), ''))
        if not match and DEBUG: print(e, ', stuckinfo: ', item['num'])
    except Exception, e:
        if DEBUG: print(e, ', stuckinfo: ', item['num'])
    if 'play_result' not in stuckinfo:
        return (0, (1, 0, 0, 0, 0, 0, 0, 0, 0, 0))
    playresult = stuckinfo['play_result']
    idx = reduce(lambda x, y: x or y, map(lambda f: f(playresult), rules))
    info = hijack_url(idx, playresult)
    if info: logger.error(hijack_url(idx, playresult))
    return (item['platform'], Errtuple[idx])

def process(timepoint):
    begin = timepoint.strftime('%Y-%m-%d %H:%M:%S')
    end = (timepoint + datetime.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S')
    sql = "select * from ndct_client where access_time > '{begin}' and access_time <= '{end}'".format(begin=begin, end=end)
    resp = odbreq(sql)
    res = reduce(count, map(parse, resp), {})
    return (timepoint, res)

if __name__ == "__main__":
    initlog('hijack-url')
    # today = datetime.datetime.today()
    today = datetime.datetime.strptime('2016-05-22 05:00:00', '%Y-%m-%d %H:%M:%S')
    drange = [today - datetime.timedelta(minutes=x) for x in range(60, 0, -5)]

    pool = ThreadPool(10)
    res1 = pool.map(process, drange)
    pool.close()
    pool.join()

    print('\n'.join(map(lambda t: "%s = %s" % t, res1)))
    res2 = reduce(lambda x, y: ('', merge(x[1], y[1])), res1)
    print('Total = ', res2[1])
    res3 = dict([(k, map(lambda x: x / float(v[0]), v)) for (k, v) in res2[1].items()])
    print('Percent = ', res3)
