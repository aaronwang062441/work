from __future__ import print_function
import json
import datetime
import MySQLdb as mysql
from multiprocessing.dummy import Pool as ThreadPool

DEBUG = True

conn_opts = {
    'host': 'sjhl.netdoctor.w.qiyi.db',
    'port': 8498,
    'user': 'netdoctor',
    'password': '%ZjLUoTW',
    'database': 'netdoctor'
}

def enum(*seq, **named):
    enums = dict(zip(seq, range(len(seq))), **named)
    return type('Enum', (), enums)

Steps = enum(
    'ERROR_VIDTVID',
    'NETWORK_START',
    'NETWORK_FAILED',
    'NETWORK_OK',
    'USER_PREPAREBEGIN',
    'USER_PREPAREOK',
    'USER_PREPAREFAILED',
    'VRS_VIDBEGIN',
    'VRS_VIDOK',
    'VRS_VIDFAILD',
    'GET_KEYBEGIN',
    'GET_KEYOK',
    'GET_KEYFAILED',
    'GET_M3U8BEGIN',
    'GET_M3U8OK',
    'GET_M3U8FAILED',
    'AUT_BEGIN',
    'AUT_OK',
    'AUT_FAILED',
    'DOWNLOAD_BEGIN',
    'DOWNLOAD_FAILED',
    'DOWNLOAD_END',
    'COMPLETE',
    'VRS_URL_HIJACK',
    'PDATA_URL_HIJACK',
    'DOWNLOAD_URL_HIJACK',
    'GET_M3U8_URL_HIJACK',
)

Errcode = enum(
    'ERR_OK',
    'ERR_ZEROSPEED',
    'ERR_LOWSPEED',
    'ERR_HIGHSPEED',
    'ERR_UNDERRATE',
    'ERR_BEYONDRATE',
    'ERR_OTHER',
)

Errtuple = [
    # TOTAL, OK, 0, <=100, >100, <=rate, >rate,
    (1, 1, 0, 0, 0, 0, 0, 0, 0, 0),
    (1, 0, 1, 0, 0, 0, 0, 0, 0, 0),
    (1, 0, 0, 1, 0, 0, 0, 0, 0, 0),
    (1, 0, 0, 0, 1, 0, 0, 0, 0, 0),
    (1, 0, 0, 0, 0, 1, 0, 0, 0, 0),
    (1, 0, 0, 0, 0, 0, 1, 0, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 1, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 0, 1, 0),
    (1, 0, 0, 0, 0, 0, 0, 0, 0, 1),
]

rules = [
    lambda p: (p["cache_status"]["avg_speed"] == 0) and Errcode.ERR_ZEROSPEED or Errcode.ERR_OK,
    lambda p: (p["cache_status"]["avg_speed"] <= 100) and Errcode.ERR_LOWSPEED or Errcode.ERR_OK,
    lambda p: (p["cache_status"]["avg_speed"] > 100) and Errcode.ERR_HIGHSPEED or Errcode.ERR_OK,
    lambda p: (p["cache_status"]["avg_speed"] <= p["rate"]) and Errcode.ERR_UNDERRATE or Errcode.ERR_OK,
    lambda p: (p["cache_status"]["avg_speed"] > p["rate"]) and Errcode.ERR_BEYONDRATE or Errcode.ERR_OK,
]

def odbreq(sql):
    res = ()
    try:
        conn = mysql.connect(host=conn_opts['host'], port=conn_opts['port'], user=conn_opts['user'], passwd=conn_opts['password'], db=conn_opts['database'])
        cur = conn.cursor(cursorclass=mysql.cursors.DictCursor)
        cur.execute(sql)
        res = cur.fetchall()
        cur.close()
        conn.close()
    except Exception, e:
        if DEBUG: print(e)
    return res

def count(dct, tup):
    if not tup[0] in dct:
        dct[tup[0]] = tup[1]
    else:
        y = tup[1]
        x = dct[tup[0]]
        dct[tup[0]] = (x[0]+y[0], x[1]+y[1], x[2]+y[2], x[3]+y[3], x[4]+y[4], x[5]+y[5], x[6]+y[6], x[7]+y[7], x[8]+y[8], x[9]+y[9])
    return dct

def merge(dct1, dct2):
    dct = reduce(count, dct1.items() + dct2.items(), {})
    return dct

def parse(item):
    stuckinfo = {}
    try:
        if item['stuckinfo'].find('tel,cdnresult = ') != -1:
            item['stuckinfo'] = item['stuckinfo'].replace('tel,cdnresult = ', '')
        elif item['stuckinfo'].find('cdnresult = ') != -1:
            item['stuckinfo'] = item['stuckinfo'].replace('cdnresult = ', '')
        elif item['stuckinfo'].find('tel,{') != -1:
            item['stuckinfo'] = item['stuckinfo'].replace('tel,{', '{')
        stuckinfo = json.loads(item['stuckinfo'])
    except Exception, e:
        if DEBUG: print(e, ', stuckinfo: ', item['stuckinfo'])
    if 'play_result' not in stuckinfo:
        return (0, (1, 0, 0, 0, 0, 0, 0, 0, 0, 0))
    playresult = stuckinfo['play_result']
    if playresult['step'] not in (Steps.DOWNLOAD_BEGIN, Steps.DOWNLOAD_FAILED, Steps.DOWNLOAD_END, Steps.DOWNLOAD_URL_HIJACK, Steps.COMPLETE):
        return (0, (1, 0, 0, 0, 0, 0, 0, 0, 0, 0))
    if 'rate' in playresult:
        idx = reduce(lambda x, y: x or y, map(lambda f: f(playresult), rules))
    else:
        idx = reduce(lambda x, y: x or y, map(lambda f: f(playresult), rules[0:3]))
    return (playresult['step'], Errtuple[idx])

def process(timepoint):
    begin = timepoint.strftime('%Y-%m-%d %H:%M:%S')
    end = (timepoint + datetime.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S')
    sql = "select * from ndct_client where access_time > '{begin}' and access_time <= '{end}'".format(begin=begin, end=end)
    resp = odbreq(sql)
    res = reduce(count, map(parse, resp), {})
    return (timepoint, res)

if __name__ == "__main__":
    today = datetime.datetime.today()
    drange = [today - datetime.timedelta(minutes=x) for x in range(10, 0, -1)]

    pool = ThreadPool(8)
    res1 = pool.map(process, drange)
    for tup in res1:
        print(tup[0], '= ', tup[1])
    res2 = reduce(lambda x, y: ('', merge(x[1], y[1])), res1)
    print(res2[1])
