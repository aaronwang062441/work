#
#
# Performance in Intel Xeon E5-2650 8 cores (Pool Size From 1 to 16):
#   1: real    6m36.775s user    0m28.363s sys     0m0.170s
#   2: real    4m42.335s user    0m52.842s sys     0m11.544s
#   3: real    5m6.017s  user    0m56.381s sys     0m14.768s
#   4: real    4m7.879s  user    0m54.375s sys     0m12.191s
#   5: real    5m4.066s  user    0m58.695s sys     0m16.408s
#   6: real    4m4.841s  user    0m56.804s sys     0m16.630s
#   7: real    3m47.089s user    1m0.272s  sys     0m16.160s
#   8: real    4m13.601s user    1m1.865s  sys     0m18.817s
#   9: real    4m1.237s  user    0m58.449s sys     0m16.130s
#  10: real    2m32.906s user    1m3.000s  sys     0m18.423s
#  11: real    4m46.981s user    1m0.705s  sys     0m17.938s
#  12: real    4m18.927s user    0m59.609s sys     0m18.034s
#  13: real    3m14.807s user    1m0.180s  sys     0m18.438s
#  14: real    4m29.032s user    1m3.125s  sys     0m19.978s
#  15: real    4m39.258s user    1m2.272s  sys     0m20.179s
#  16: real    4m38.402s user    1m3.080s  sys     0m19.601s
from __future__ import print_function
import re
import json
import datetime
import MySQLdb as mysql
from multiprocessing.dummy import Pool as ThreadPool

DEBUG = True

conn_opts = {
    'host': 'sjhl.netdoctor.w.qiyi.db',
    'port': 8498,
    'user': 'netdoctor',
    'password': '%ZjLUoTW',
    'database': 'netdoctor'
}

def enum(*seq, **named):
    enums = dict(zip(seq, range(len(seq))), **named)
    return type('Enum', (), enums)

Steps = enum(
    'ERROR_VIDTVID',
    'NETWORK_START',
    'NETWORK_FAILED',
    'NETWORK_OK',
    'USER_PREPAREBEGIN',
    'USER_PREPAREOK',
    'USER_PREPAREFAILED',
    'VRS_VIDBEGIN',
    'VRS_VIDOK',
    'VRS_VIDFAILD',
    'GET_KEYBEGIN',
    'GET_KEYOK',
    'GET_KEYFAILED',
    'GET_M3U8BEGIN',
    'GET_M3U8OK',
    'GET_M3U8FAILED',
    'AUT_BEGIN',
    'AUT_OK',
    'AUT_FAILED',
    'DOWNLOAD_BEGIN',
    'DWONLOAD_FAILED',
    'DOWNLOAD_END',
    'COMPLETE',
    'VRS_URL_HIJACK',
    'PDATA_URL_HIJACK',
    'DOWNLOAD_URL_HIJACK',
    'GET_M3U8_URL_HIJACK',
)

Errcode = enum(
    'ERR_OK',
    'ERR_COMPLETE',
    'ERR_DOWNLOAD',
    'ERR_F4V_TIMEOUT',
    'ERR_VRS_ACCESS',
    'ERR_PDATA_ACCESS',
    'ERR_M3U8_TIMEOUT',
    'ERR_M3U8_ACCESS',
    'ERR_VIP_AUTH',
)

Errtuple = [
    # TOTAL, OK, COMPLETE, DOWNLOAD, F4V_TMO, VRS_AC, PDATA_AC, M3U8_TMO, M3U8_AC, VIP
    (1, 1, 0, 0, 0, 0, 0, 0, 0, 0),
    (1, 0, 1, 0, 0, 0, 0, 0, 0, 0),
    (1, 0, 0, 1, 0, 0, 0, 0, 0, 0),
    (1, 0, 0, 0, 1, 0, 0, 0, 0, 0),
    (1, 0, 0, 0, 0, 1, 0, 0, 0, 0),
    (1, 0, 0, 0, 0, 0, 1, 0, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 1, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 0, 1, 0),
    (1, 0, 0, 0, 0, 0, 0, 0, 0, 1),
]

rules = [
    lambda p: ((p["step"] == Steps.COMPLETE) and (p["cache_status"]["avg_speed"] == 0)) and Errcode.ERR_COMPLETE or Errcode.ERR_OK,
    lambda p: ((p["step"] == Steps.DWONLOAD_FAILED) and (p["cache_status"]["avg_speed"] == 0)) and Errcode.ERR_DOWNLOAD or Errcode.ERR_OK,
    lambda p: ((p["file_tpye"] == "F4V") and (p["step"] == Steps.NETWORK_FAILED or p["timeout"] == 1)) and Errcode.ERR_F4V_TIMEOUT or Errcode.ERR_OK,
    lambda p: ((p["file_tpye"] == "F4V") and (p["step"] == Steps.VRS_VIDFAILD or p["step"] == Steps.VRS_URL_HIJACK)) and Errcode.ERR_VRS_ACCESS or Errcode.ERR_OK,
    lambda p: ((p["file_tpye"] == "F4V") and (p["step"] == Steps.AUT_FAILED or p["step"] == Steps.PDATA_URL_HIJACK)) and Errcode.ERR_PDATA_ACCESS or Errcode.ERR_OK,
    lambda p: ((p["file_tpye"] == "M3U8") and (p["step"] == Steps.NETWORK_FAILED or p["timeout"] == 1)) and Errcode.ERR_M3U8_ACCESS or Errcode.ERR_OK,
    lambda p: ((p["file_tpye"] == "M3U8") and (p["step"] == Steps.VRS_VIDFAILD or p["step"] == Steps.GET_M3U8FAILED or p["step"] == Steps.AUT_FAILED)) and Errcode.ERR_M3U8_TIMEOUT or Errcode.ERR_OK,
    lambda p: (p["step"] == Steps.USER_PREPAREFAILED or p["step"] == Steps.GET_KEYFAILED) and Errcode.ERR_VIP_AUTH or Errcode.ERR_OK,
]

def odbreq(sql):
    res = ()
    try:
        conn = mysql.connect(host=conn_opts['host'], port=conn_opts['port'], user=conn_opts['user'], passwd=conn_opts['password'], db=conn_opts['database'])
        cur = conn.cursor(cursorclass=mysql.cursors.DictCursor)
        cur.execute(sql)
        res = cur.fetchall()
        cur.close()
        conn.close()
    except Exception, e:
        if DEBUG: print(e)
    return res

def parse(item):
    stuckinfo = {}
    try:
        stuckinfo = json.loads(item['stuckinfo'])
    except ValueError, e:
        match, errmsg = None, str(e)
        if errmsg.startswith('No JSON'):
            pattern = re.compile(r'((tel=(\d+)?,)?cdnresult = |tel=(\d+)?,){')
            match = pattern.match(item['stuckinfo'])
            if match: stuckinfo = json.loads(item['stuckinfo'].replace(match.group(0), '{'))
        elif errmsg.startswith('Expecting , delimiter:'):
            pattern = re.compile(r'"return_data":\s*"{(.*)}",')
            match = pattern.match(item['stuckinfo'])
            if match: stuckinfo = json.loads(item['stuckinfo'].replace(match.group(1), ''))
        if not match and DEBUG: print(e, ', stuckinfo: ', item['num'])
    except Exception, e:
        if DEBUG: print(e, ', stuckinfo: ', item['num'])
    if 'play_result' not in stuckinfo:
        return (item['platform'], (1, 0, 0, 0, 0, 0, 0, 0, 0, 0))
    playresult = stuckinfo['play_result']
    idx = 0
    if 'file_tpye' in playresult:
        idx = reduce(lambda x, y: x or y, map(lambda f: f(playresult), rules))
    return (item['platform'], Errtuple[idx])

def count(dct, tup):
    if not tup[0] in dct:
        dct[tup[0]] = tup[1]
    else:
        y = tup[1]
        x = dct[tup[0]]
        dct[tup[0]] = (x[0]+y[0], x[1]+y[1], x[2]+y[2], x[3]+y[3], x[4]+y[4], x[5]+y[5], x[6]+y[6], x[7]+y[7], x[8]+y[8], x[9]+y[9])
    return dct

def merge(dct1, dct2):
    dct = reduce(count, dct1.items() + dct2.items(), {})
    return dct

def process(timepoint):
    begin = timepoint.strftime('%Y-%m-%d %H:%M:%S')
    end = (timepoint + datetime.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S')
    sql = "select * from ndct_client where access_time > '{begin}' and access_time <= '{end}'".format(begin=begin, end=end)
    resp = odbreq(sql)
    res = reduce(count, map(parse, resp), {})
    return (timepoint, res)

if __name__ == "__main__":
    # today = datetime.datetime.today()
    today = datetime.datetime.strptime('2016-05-22 05:00:00', '%Y-%m-%d %H:%M:%S')
    drange = [today - datetime.timedelta(minutes=x) for x in range(60, 0, -5)]

    pool = ThreadPool(10)
    res1 = pool.map(process, drange)
    pool.close()
    pool.join()

    print('\n'.join(map(lambda t: "%s = %s" % t, res1)))
    res2 = reduce(lambda x, y: ('', merge(x[1], y[1])), res1)
    print('Total = ', res2[1])
    res3 = dict([(k, map(lambda x: x / float(v[0]), v)) for (k, v) in res2[1].items()])
    print('Percent = ', res3)
