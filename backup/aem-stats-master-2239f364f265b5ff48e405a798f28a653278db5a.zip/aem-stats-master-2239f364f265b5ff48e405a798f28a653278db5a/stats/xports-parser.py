#
#
# Performance in Intel Xeon E5-2650 8 cores (Pool Size From 1 to 16):
#   1: real    6m36.775s user    0m28.363s sys     0m0.170s
#   2: real    4m42.335s user    0m52.842s sys     0m11.544s
#   3: real    5m6.017s  user    0m56.381s sys     0m14.768s
#   4: real    4m7.879s  user    0m54.375s sys     0m12.191s
#   5: real    5m4.066s  user    0m58.695s sys     0m16.408s
#   6: real    4m4.841s  user    0m56.804s sys     0m16.630s
#   7: real    3m47.089s user    1m0.272s  sys     0m16.160s
#   8: real    4m13.601s user    1m1.865s  sys     0m18.817s
#   9: real    4m1.237s  user    0m58.449s sys     0m16.130s
#  10: real    2m32.906s user    1m3.000s  sys     0m18.423s
#  11: real    4m46.981s user    1m0.705s  sys     0m17.938s
#  12: real    4m18.927s user    0m59.609s sys     0m18.034s
#  13: real    3m14.807s user    1m0.180s  sys     0m18.438s
#  14: real    4m29.032s user    1m3.125s  sys     0m19.978s
#  15: real    4m39.258s user    1m2.272s  sys     0m20.179s
#  16: real    4m38.402s user    1m3.080s  sys     0m19.601s
from __future__ import print_function
import re
import json
import base64
import datetime
import logging
import MySQLdb as mysql
from multiprocessing.dummy import Pool as ThreadPool

DEBUG = False

conn_opts = {
    'host': 'sjhl.netdoctor.w.qiyi.db',
    'port': 8498,
    'user': 'netdoctor',
    'password': '%ZjLUoTW',
    'database': 'netdoctor'
}

logger = None

def initlog(name):
    global logger
    logger = logging.getLogger(name)
    formatter = logging.Formatter('%(asctime)s %(message)s', '%Y-%m-%d %H:%M:%S',)
    file_handler = logging.FileHandler("%s.log" % name)
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.ERROR)
    logger.addHandler(file_handler)
    logger.setLevel(logging.ERROR)

def odbreq(sql):
    ret, res = 0, ()
    try:
        conn = mysql.connect(host=conn_opts['host'], port=conn_opts['port'], user=conn_opts['user'], passwd=conn_opts['password'], db=conn_opts['database'])
        cur = conn.cursor()
        ret = cur.execute(sql)
        res = cur.fetchall()
        cur.close()
        conn.close()
    except Exception, e:
        if DEBUG: print(e)
    if DEBUG: print("Ret: ", ret, ", SQL: ", sql)
    return res

def parse(item):
    stuckinfo = {}
    try:
        stuckinfo = json.loads(item[7])
    except ValueError, e:
        match, errmsg = None, str(e)
        if errmsg.startswith('No JSON'):
            pattern = re.compile(r'((tel=(\d+)?,)?cdnresult = |tel=(\d+)?,){')
            match = pattern.match(item[7])
            if match: stuckinfo = json.loads(item[7].replace(match.group(0), '{'))
        elif errmsg.startswith('Expecting , delimiter:'):
            pattern = re.compile(r'"return_data":\s*"{(.*)}",')
            match = pattern.match(item[7])
            if match:
                newjstr = match.group(1).replace('"', '\\"')
                stuckinfo = json.loads(item[7].replace(match.group(1), newjstr))
        if not match and DEBUG: print(e, ', stuckinfo: ', item[0])
    except Exception, e:
        if DEBUG: print(e, ', stuckinfo: ', item[0])

    if 'play_result' not in stuckinfo:
        return None
    if 'access_pdata' not in stuckinfo['play_result']:
        return None
    if 'return_data' not in stuckinfo['play_result']['access_pdata']:
        return None
    jdata = stuckinfo['play_result']['access_pdata']['return_data'].strip()
    if len(jdata) == 0: return None

    ip = item[5].strip()
    pip = None
    try:
        if jdata.find('\\') == -1 and jdata.find('"') == -1:
            jdata = base64.decodestring(jdata)
        data = json.loads(jdata)
        pip = data['t'].split('-')[1].strip()
    except ValueError, e:
        if DEBUG: print("Invalid json: ", jdata)
    except Exception, e:
        if DEBUG: print(e, ', return_data: ', jdata)
    if not pip: return None
    if ip != pip: logger.error(">> (%s, %s)" % (ip, pip))
    return (ip==pip, 1)

def count(dct, tup):
    return dct.update({tup[0]: dct.get(tup[0], 0) + tup[1]}) or dct

def process(timepoint):
    begin = timepoint.strftime('%Y-%m-%d %H:%M:%S')
    end = (timepoint + datetime.timedelta(minutes=30)).strftime('%Y-%m-%d %H:%M:%S')
    sql = "select * from ndct_client where access_time > '{begin}' and access_time <= '{end}'".format(begin=begin, end=end)
    resp = odbreq(sql)
    res = reduce(count, filter(lambda x: x is not None, map(parse, resp)), {})
    return (timepoint, res)

if __name__ == "__main__":
    initlog('multi-exports')

    today = datetime.datetime.today()
    # today = datetime.datetime.strptime('2016-05-29 01:00:00', '%Y-%m-%d %H:%M:%S')
    drange = [today - datetime.timedelta(minutes=x) for x in range(24*60, 0, -30)]

    pool = ThreadPool(8)
    res1 = pool.map(process, drange)
    pool.close()
    pool.join()

    print('\n'.join(map(lambda t: "%s = %s" % t, res1)))
