from __future__ import print_function
import re
import json
import datetime
import MySQLdb as mysql
from multiprocessing import Pool as ThreadPool

DEBUG = True

conn_opts = {
    'host': 'sjhl.netdoctor.w.qiyi.db',
    'port': 8498,
    'user': 'netdoctor',
    'password': '%ZjLUoTW',
    'database': 'netdoctor'
}

domain_list = dict()

flatMap = lambda f, lst: reduce(lambda l, x: l + x, map(f, lst), [])

def odbreq(sql):
    ret, res = 0, []
    try:
        conn = mysql.connect(host=conn_opts['host'], port=conn_opts['port'], user=conn_opts['user'], passwd=conn_opts['password'], db=conn_opts['database'])
        cur = conn.cursor(cursorclass=mysql.cursors.DictCursor)
        ret = cur.execute(sql)
        res = cur.fetchall()
        cur.close()
        conn.close()
    except Exception, e:
        if DEBUG: print(e)
    if DEBUG: print("LEN: ", ret)
    return res

def odbgen(timepoint, hours=1):
    for tp in [timepoint - datetime.timedelta(hours=x) for x in xrange(hours, 0, -1)]:
        begin = tp.strftime('%Y-%m-%d %H:%M:%S')
        end = (tp + datetime.timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')
        sql = "select * from ndct_pingback where access_time > '{begin}' and access_time <= '{end}'".format(begin=begin, end=end)
        yield odbreq(sql)

def init_domain_list():
    global domain_list
    f = open('domain_ip.csv', 'r')
    for line in f.readlines():
        domain, code, isp, ip_list = line.split(',')
        domain_list[(domain, isp)] = ip_list.strip().split('|')
    return domain_list

def match(data, isp, prvn):
    if (data['url'], isp) not in domain_list:
        return (('None', 'None', 'None'), (1, 0, 0, 0))
    if data['ip'] == '0.0.0.0|':
        return ((data['url'], isp, prvn), (1, 1, 0, 0))
    ret_ip = data['ip'].split('|')
    chk_ip = domain_list[(data['url'], isp)]
    if set(ret_ip).issubset(set(chk_ip)):
        return ((data['url'], isp, prvn), (1, 0, 0, 1))
    return ((data['url'], isp, prvn), (1, 0, 1, 0))
   
def parse(item):
    pingback = {}
    try:
        pingback = json.loads(item['pingback'])
    except Exception, e:
        if DEBUG: print(e, ', pingback: ', item['num'])
    prvn, city, isp = item['zone'].split('-', 2)
    if 'dns_result' not in pingback:
        return [(('None', 'None', 'None'), (1, 0, 0, 0))]
    return map(lambda data: match(data, isp, prvn), pingback['dns_result']['data'])

def count(dct, tup):
    dct[tup[0]] = tuple(map(lambda x, y: x+y, dct.get(tup[0], (0, 0, 0, 0)), tup[1]))
    return dct

def merge(dct1, dct2):
    dct = reduce(count, dct1.items() + dct2.items(), {})
    return dct

def process(batch):
    return flatMap(parse, batch)

if __name__ == "__main__":
    init_domain_list() 

    timepoint = datetime.datetime.strptime('2016-05-26 15:00:00', '%Y-%m-%d %H:%M:%S')

    pool = ThreadPool(8)
    res = pool.map(process, odbgen(timepoint))
    pool.close()
    pool.join()

    #print('\n'.join(map(lambda t: "%s = %s" % t, res1)))
    #res2 = reduce(lambda x, y: ('', merge(x[1], y[1])), res1)
    #import pprint
    #pprint.pprint(res2[1])
    # res3 = dict([(k, map(lambda x: x / float(v[0]), v)) for (k, v) in res2[1].items()])
    # print('Percent = ', res3)
