#!/usr/bin/env python
#
# Copyright (c) 2016 iQIYI.com
# Author(s): Chen Gui <chengui@qiyi.com>
#
# This script is used to statistics the local DNS summary of all stuckinfo posted
# by NetDoctor client, the real-time infrastructure is supported by spark streaming,
# which is using Kafka messaging system as provider.
# NOTICE: to enable jdbc, spark needs extra configuration:
#   '--conf spark.driver.extraClassPath=./mysql-connector-java-5.1.38.jar
#    --conf spark.executor.extraClassPath=./mysql-connector-java-5.1.38.jar'

from __future__ import print_function
import sys
import time
import json
import datetime
import traceback

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import SQLContext, Row

APPNAME = "aem-dnsparser"

# Quorum of zoookeepers used by Kafka
zookeepers = [
    "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181",
]

def getSqlContext(sparkContext):
    """ Singleton of sqlContext """
    if 'sqlContextSingleton' not in globals():
        globals()['sqlContextSingleton'] = SQLContext(sparkContext)
    return globals()['sqlContextSingleton']

def safe_load(jstr):
    """ Wrapper of json.loads """
    try:
        return json.loads(jstr)
    except Exception, e:
        print("Invalid json format: ", jstr)
    return {}

def transform(jstr):
    """ Transform the original Kafka message to json string """
    jobj = safe_load(jstr)
    if not jobj.has_key('stuckinfo'):
        return jobj
    jstuck = safe_load(jobj["stuckinfo"])
    jstuck['uid'] = jobj['uid']
    jstuck['ver'] = jobj['ver']
    jstuck['plat'] = int(jobj['plat'])
    jstuck['ip'] = jobj['ip']
    jstuck['zone'] = jobj['zone']
    jstuck['isp'] = jobj['isp']
    jstuck['prvn'] = 'prvn' in jobj and jobj['prvn'] or jstuck['zone'].split('-')[0]
    jstuck['city'] = 'city' in jobj and jobj['city'] or jstuck['zone'].split('-')[1]
    return jstuck

def parse(now, jobj):
    """ Collect all dns info by parsing stuckinfo """
    if 'play_result' not in jobj:
        return None
    if 'dns' not in jobj['play_result']:
        return None
    if 'list' not in jobj['play_result']['dns']:
        return None
    if len(jobj['play_result']['dns']['list']) == 0:
        return None
    dns_list = filter(lambda x: x != '0.0.0.0' and not x.startswith('192.168'), jobj['play_result']['dns']['list'])
    if len(dns_list) == 0:
        return None
    return ((jobj['isp'], jobj['prvn'], jobj['city']), set(dns_list))

def convert(now, tup):
    """ Convert to pyspark.sql.Row """
    return Row(id=0, time=str(now), isp=tup[0][0], prvn=tup[0][1], city=tup[0][2], ldns=unicode('|'.join(tup[1])))

def process(time, rdd):
    """ Process RDDs in each DStream

    First decode json string from Kafka message, then collect all local dns info from it
    by key tuple (isp, province, city), finally insert the result to mysql database via jdbc.
    """
    print("========= %s %s==========" % (str(time), type(rdd)))
    # the message format from Kafka would be (None, u'{"uid":uid, "plat":plat, ..., "stuckinfo":str}')
    js_entry = rdd.map(lambda x: transform(x[1]))
    oj_rows = js_entry.map(lambda x: parse(time, x))
    oj_filtered = oj_rows.filter(lambda x: x is not None)
    cnt_merge = oj_filtered.reduceByKey(lambda x, y: x|y)
    cnt_rows = cnt_merge.map(lambda x: convert(time, x))

    try:
        sqlContext = getSqlContext(rdd.context)
        # Specify the columns order, otherwise jdbc will insert rows in alphabet-order-column
        columns = ['id', 'time', 'isp', 'prvn', 'city', 'ldns']
        dns_df = sqlContext.createDataFrame(cnt_rows)[columns]
        dns_df.write.jdbc(
            url = "jdbc:mysql://10.153.3.74:3306/aem_stats?user=netdoctor&password=123456",
            table = "dnsinfo_summary",
            mode = "append",
        )
    except Exception, e:
        print(">>> %s" % traceback.format_exc())

def utf8_decoder(s):
    """ Decode function for Kafka DStream """
    if s is None:
        return None
    try:
        return s.decode('utf-8')
    except UnicodeDecodeError, e:
        print(">>> ", s)
    return s

if __name__ == "__main__":
    sc = SparkContext()
    ssc = StreamingContext(sc, 3600) # 1hour for real-time analysis
    sqlContext = getSqlContext(sc)

    topics = {"aem_ndctinfo": 5}
    zk_quorum = ",".join(zookeepers)
    kfk_stream = KafkaUtils.createStream(ssc, zk_quorum, "aemdns-group", topics, keyDecoder=utf8_decoder, valueDecoder=utf8_decoder)

    # each partition is supposed to be separated by 'timepoint'
    kfk_stream.foreachRDD(process)

    ssc.start()
    ssc.awaitTermination()