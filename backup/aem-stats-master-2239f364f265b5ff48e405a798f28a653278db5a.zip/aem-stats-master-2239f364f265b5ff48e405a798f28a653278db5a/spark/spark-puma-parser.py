#!/usr/bin/env python
#
# Copyright (c) 2016 iQIYI.com
# Author(s): Chen Gui <chengui@qiyi.com>
# Author(s): Zhang Xianbao <zhangxianbao@qiyi.com>
#
# This script is used to statistics the real-time summary of all stuckinfo posted
# by Puma client, the real-time infrastructure is supported by spark streaming,
# which is using Kafka messaging system as provider.
# NOTICE: to enable jdbc, spark needs extra configuration:
#   '--conf spark.driver.extraClassPath=./mysql-connector-java-5.1.38.jar
#    --conf spark.executor.extraClassPath=./mysql-connector-java-5.1.38.jar'

from __future__ import print_function
import sys
import time
import json
import datetime
import traceback

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import SQLContext, Row

APPNAME = "aem-pumainfo"

# Define Enum type
def enum(*seq, **named):
    enums = dict(zip(seq, range(len(seq))), len=len(seq), **named)
    return type('Enum', (), enums)

# Definition of Constants
Steps = enum(
    'ERROR_VIDTVID',
    'NETWORK_START',
    'NETWORK_FAILED',
    'NETWORK_OK',
    'USER_PREPAREBEGIN',
    'USER_PREPAREOK',
    'USER_PREPAREFAILED',
    'VRS_VIDBEGIN',
    'VRS_VIDOK',
    'VRS_VIDFAILD',
    'GET_KEYBEGIN',
    'GET_KEYOK',
    'GET_KEYFAILED',
    'GET_M3U8BEGIN',
    'GET_M3U8OK',
    'GET_M3U8FAILED',
    'AUT_BEGIN',
    'AUT_OK',
    'AUT_FAILED',
    'DOWNLOAD_BEGIN',
    'DWONLOAD_FAILED',
    'DOWNLOAD_END',
    'COMPLETE',
    'VRS_URL_HIJACK',
    'PDATA_URL_HIJACK',
    'DOWNLOAD_URL_HIJACK',
    'GET_M3U8_URL_HIJACK',
)

# Error type:  OK, COMPLETE, DOWNLOAD, PDATA
Errcode = enum(
    'ERR_OK',
    'ERR_COMPLETE',
    'ERR_DOWNLOAD',
    'ERR_PDATA',
)

def rotate(l, n):
    """ Rotate tuple/list """
    return l[-n:] + l[:-n]

# Tuple definition: (TOTAL, OK, COMPLETE, DOWNLOAD, PDATA)
Errtuple = map(lambda i: tuple([1]+rotate([1]+[0]*(Errcode.len-1), i)), range(Errcode.len))

# Quorum of zoookeepers used by Kafka
zookeepers = [
    "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181",
]

# The defined rules to be classified
rules = [
    lambda p: ((p["cache_status"]["url"] != "") and (p["cache_status"]["avgspeed"] > 0)) and Errcode.ERR_COMPLETE or Errcode.ERR_OK,
    lambda p: ((p["cache_status"]["url"] != "") and (p["cache_status"]["avgspeed"] == 0)) and Errcode.ERR_DOWNLOAD or Errcode.ERR_OK,
    lambda p: (p["cache_status"]["url"] == "" ) and Errcode.ERR_PDATA or Errcode.ERR_OK,
]

def getSqlContext(sparkContext):
    """ Singleton of sqlContext """
    if 'sqlContextSingleton' not in globals():
        globals()['sqlContextSingleton'] = SQLContext(sparkContext)
    return globals()['sqlContextSingleton']

def safe_load(jstr):
    """ Wrapper of json.loads """
    try:
        return json.loads(jstr)
    except Exception, e:
        print(">>> ", e)
    return {}

def transform(jstr):
    """ Transform the original Kafka message to json string """
    jobj = safe_load(jstr)
    if 'plat' not in jobj:
        jobj['plat'] = 114
    if 'stuckinfo' not in jobj:
        return jobj
    jstuck = safe_load(jobj["stuckinfo"])
    jstuck['uid'] = jobj['uid']
    jstuck['ver'] = jobj['ver']
    jstuck['plat'] = int(jobj['plat'])
    jstuck['ip'] = jobj['ip']
    jstuck['zone'] = jobj['zone']
    jstuck['isp'] = jobj['isp']
    jstuck['prvn'] = 'prvn' in jobj and jobj['prvn'] or jobj['zone'].split('-')[0]
    jstuck['city'] = 'city' in jobj and jobj['city'] or jobj['zone'].split('-')[1]
    return jstuck

def parse(jobj):
    """ Classify each message by the defined rules """
    if 'play_process' not in jobj:
        return (jobj['plat'], tuple([1]+[0]*Errcode.len))
    if 'cache_status' in jobj['play_process'] and 'avgspeed' not in jobj['play_process']['cache_status']:
        jobj['play_process']['cache_status']['avgspeed'] = 0
    idx = reduce(lambda x, y: x or y, map(lambda f: f(jobj['play_process']), rules))
    return (jobj['plat'], Errtuple[idx])

def count(x, y):
    """ Count the '1' numbers by tuple """
    return tuple(map(lambda i, j: i + j, x, y))

def convert(now, tup):
    """ Convert tuple to pyspark.sql.Row """
    columns = ['id', 'plat', 'time', 'total', 'err_ok', 'err_complete', 'err_download', 'err_pdata']
    row = dict(zip(columns, [0, tup[0], str(now)] + list(tup[1])))
    return Row(**row)

def process(time, rdd):
    """ Process RDDs in each DStream

    First decode json string from Kafka message, then classify by the defined rules,
    and count the amount of each type error by 'plat' key, but it'd better convert
    the result to Row such that it can be inserted into mysql database by jdbc.
    """
    print("========= %s %s==========" % (str(time), type(rdd)))
    # the message format from Kafka would be (None, u'{"uid":uid, "plat":plat, ..., "stuckinfo":str}')
    js_entry = rdd.map(lambda x: transform(x[1]))
    oj_match = js_entry.map(parse)
    cnt_tup = oj_match.reduceByKey(lambda x, y: count(x, y))
    cnt_plat = cnt_tup.map(lambda x: convert(time, x))
    try:
        sqlContext = getSqlContext(rdd.context)
        # Specify the columns order, otherwise jdbc will insert rows in alphabet-order-column
        columns = ['id', 'plat', 'time', 'total', 'err_ok', 'err_complete', 'err_download', 'err_pdata']
        cnt_df = sqlContext.createDataFrame(cnt_plat)[columns]
        cnt_df.write.jdbc(
            url = "jdbc:mysql://10.153.3.74:3306/aem_stats?user=netdoctor&password=123456",
            table = "pumainfo_summary",
            mode = "append"
        )    
    except Exception, e:
        print('>>> ', e)

def utf8_decoder(s):
    """ Decode function for Kafka DStream """
    if s is None:
        return ""
    try:
        return s.decode('utf-8')
    except UnicodeDecodeError, e:
        print('>>> ', e)
    return s

if __name__ == "__main__":
    sc = SparkContext()
    ssc = StreamingContext(sc, 300) # 5min for real-time analysis
    sqlContext = getSqlContext(sc)

    topics = {"aem_pumainfo": 5}
    zk_quorum = ",".join(zookeepers)
    kfk_stream = KafkaUtils.createStream(ssc, zk_quorum, "aem-group", topics, keyDecoder=utf8_decoder, valueDecoder=utf8_decoder)

    # each partition is supposed to be separated by 'timepoint'
    kfk_stream.foreachRDD(process)

    ssc.start()
    ssc.awaitTermination()
