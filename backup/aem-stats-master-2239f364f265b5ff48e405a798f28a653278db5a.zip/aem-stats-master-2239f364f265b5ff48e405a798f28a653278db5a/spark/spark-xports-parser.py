#!/usr/bin/env python
#
# Copyright (c) 2016 iQIYI.com
# Author(s): zhang xianbao <zhangxianbao@qiyi.com>
#
# This script is used to statistics the real-time summary of all stuckinfo posted
# by NetDoctor client, the real-time infrastructure is supported by spark streaming,
# which is using Kafka messaging system as provider.
# NOTICE: to enable jdbc, spark needs extra configuration:
#   '--conf spark.driver.extraClassPath=./mysql-connector-java-5.1.38.jar'
# For iQIYI Spark service, aka Europa/Jupiter, you should add the following line
# in 'extraSparkConf' parameter:
#   spark.driver.extraClassPath=./mysql-connector-java-5.1.38.jar

from __future__ import print_function 
import sys
import time
import json
import datetime
import traceback
import csv
import base64
import re

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils

APPNAME = "aem-xports-parser"

# Quorum of zoookeepers used by Kafka.
zookeepers = [
    "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181"
]

def safe_load(jstr):
    """ Wrapper of json.loads. """
    jobj = {}
    try:
        jobj = json.loads(jstr)
    except Exception, e:
        print("Invalid json format: ", jstr)
    return jobj

def transform(jstr):
    """ Transform the original Kafka message to json string """
    jobj = safe_load(jstr)
    if not jobj.has_key('stuckinfo'):
        return jobj

    jstuck = {}
    try:
        jstuck = json.loads(jobj["stuckinfo"])
    except ValueError, e:
        match, errmsg = None, str(e)
        if errmsg.startswith('No JSON'):
            pattern = re.compile(r'((tel=(\d+)?,)?cdnresult = |tel=(\d+)?,){')
            match = pattern.match(jobj["stuckinfo"])
            if match: jstuck = json.loads(jobj["stuckinfo"].replace(match.group(0), '{'))
        elif errmsg.startswith('Expecting , delimiter:'):
            pattern = re.compile(r'"return_data":\s*"{(.*)}",')
            match = pattern.match(jobj["stuckinfo"])
            if match:
                newjstr = match.group(1).replace('"', '\\"')
                jstuck = json.loads(jobj["stuckinfo"].replace(match.group(1), newjstr))
        if not match: print(e, ', stuckinfo: ')
    except Exception, e:
        print(e, ', stuckinfo: ')

    jstuck['uid'] = jobj['uid']
    jstuck['ver'] = jobj['ver']
    jstuck['plat'] = jobj['plat']
    jstuck['ip'] = jobj['ip']
    jstuck['zone'] = jobj['zone']
    jstuck['isp'] = jobj['isp']
    jstuck['prvn'] = 'prvn' in jobj and jobj['prvn'] or jobj['zone'].split('-')[0]
    jstuck['city'] = 'city' in jobj and jobj['city'] or jobj['zone'].split('-')[1]
    return jstuck

def parse(jobj):
    """ Parse each message. """
    if 'play_result' not in jobj:
        return None
    if 'access_pdata' not in jobj['play_result']:
        return None
    if 'return_data' not in jobj['play_result']['access_pdata']:
        return None

    jdata = jobj['play_result']['access_pdata']['return_data']
    if len(jdata) == 0:
        return None

    pip = None
    pisp = None
    pprvn = None
    try:
        if jdata.find('\\') == -1 and jdata.find('"') == -1:
            jdata = base64.decodestring(jdata)
        data = safe_load(jdata)
        info = data['t'].split('-')
        pip = info[1].strip()
        pisp = info[0].split('|')[0].strip()
        pprvn = info[0].split('|')[1].strip()
    except ValueError, e:
        #print("Invalid json: ", jdata)
        return None
    except Exception, e:
        #print(e, ', return_data: ', jdata)
        return None
    if not pip and not pisp and not pprvn: return None
    key = jobj['prvn'] + '-' + jobj['isp'] + '-' + jobj['ip']
    val = pprvn + '-' + pisp + '-' + pip 
    return (key,[val])

def count(x, y):
    """ Put each item in one list. """
    for i in y:
        if i not in x:
            x.append(i)
    return x

def utf8_decoder(s):
    """ Decode function for Kafka DStream """
    if s is None:
        return None
    try:
        return s.decode('utf-8')
    except UnicodeDecodeError, e:
        print('>>> ', s)
    return s

if __name__ == "__main__":
    sc = SparkContext()
    ssc = StreamingContext(sc, 3600) # 1hour for real-time analysis 
    #sqlContext = getSqlContext(sc)
    
    topics = {"aem_ndctinfo": 5}
    zk_quorum = ",".join(zookeepers)
    kfk_stream = KafkaUtils.createStream(ssc, zk_quorum, "xports-group", topics, keyDecoder=utf8_decoder, valueDecoder=utf8_decoder)

    # the message format from Kafka would be (None, u'{"uid":uid, "plat":plat, ..., "stuckinfo":str}')
    js_entry = kfk_stream.map(lambda x : transform(x[1]))
    cnt = js_entry.map(parse).filter(lambda x:x is not None).reduceByKey(lambda x,y: count(x,y))
    cnt.saveAsTextFiles("xports")
    ssc.start()
    ssc.awaitTermination()
