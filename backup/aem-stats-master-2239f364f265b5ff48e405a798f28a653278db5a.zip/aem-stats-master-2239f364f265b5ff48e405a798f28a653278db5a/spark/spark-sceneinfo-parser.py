#!/usr/bin/env python
# encoding: utf-8
#
# Copyright (c) 2017 iQIYI.com
# Author(s): ChenGui <chengui@qiyi.com>
# Author(s): WangMinghui <wangminghui@qiyi.com>
#
#
# This script is used to statistics the local DNS summary of all stuckinfo posted
# by NetDoctor client, the real-time infrastructure is supported by spark streaming,
# which is using Kafka messaging system as provider.
# NOTICE: to enable jdbc, spark needs extra configuration:
#   '--conf spark.driver.extraClassPath=./mysql-connector-java-5.1.38.jar
#    --conf spark.executor.extraClassPath=./mysql-connector-java-5.1.38.jar'

from __future__ import print_function
from __future__ import with_statement
import os
import sys
import time
import json
import fcntl
import sched
import urllib
import datetime
import traceback
import threading

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import SQLContext, Row

# process safe to import ipresolver
LOCKFILE = os.path.join(os.getcwd(), 'lock')
with open(LOCKFILE, 'w') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    try:
        from ipresolver import ipresolver
        HAS_IPLIB = True
    except:
        HAS_IPLIB = False
    finally:
        fcntl.flock(lock, fcntl.LOCK_UN)
try:
    os.remove(LOCKFILE)
except:
    pass

# implict xhost_resolver
if HAS_IPLIB:
    xhost_resolver = ipresolver.HostIPResolver()
else:
    def xhost_resolver(ip):
        return "None", "None", "None"

APPNAME = "aem-scene"

# Geoinfo Code for ISP, PROVINCE, CITY
GEO_ISP_DICT   = dict()
GEO_PRVN_DICT  = dict()
GEO_CITY_DICT  = dict()

# VRS URLS
VRS_DNS  = ['cache.video.qiyi.com', 'cache.video.ptqy.gitv.tv']
# PDATA URLS
PDATA_DNS = ['data.video.qiyi.com', 'sf.video.qiyi.com', 'sf.video.ptqy.gitv.tv']
# BOSS URLS
BOSS_DNS = ['api.vip.iqiyi.com']

# Total URLS
TOTAL_DNS = VRS_DNS + PDATA_DNS + BOSS_DNS

# DOMAIN2IP dict, structure like {"cache.video.qiyi.com": ["10.77.44.219", "10.153.3.74"]}
DOMAIN_IP_DICT = dict()
# IP2ISP dict, structure like {"10.77.44.219": [CNC, default, AIPU]}
IP_ISP_DICT = dict()
# IP2DOMAIN dict, structure like {"10.77.44.219": "cache.video.qiyi.com"}
IP_DOMAIN_DICT = dict()

# VRS
VRS_IP_LIST = list()
# PDATA
PDATA_IP_LIST = list()
# BOSS
BOSS_IP_LIST = list()

# Quorum of zookeepers used by Kafka
zookeepers = [
    "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181",
]

DB_COLUMNS = [
    'id', 'time', 'isp', 'prvn', 'city', 'total', 'net_conn_error',
    'vrs_resolv_failed', 'vrs_conn_failed', 'vrs_dns_incorrect', 'vrs_dns_crossisp', 'vrs_http_3xx', 'vrs_http_zero', 'vrs_http_other', 'vrs_ret_sterror', 'vrs_ret_cderror', 'vrs_correct',
    'boss_resolv_failed', 'boss_conn_failed', 'boss_dns_incorrect', 'boss_dns_crossisp', 'boss_http_3xx', 'boss_http_zero', 'boss_http_other', 'boss_ret_incorrect', 'boss_correct', 'boss_total',
    'pdata_resolv_failed', 'pdata_conn_failed', 'pdata_dns_incorrect', 'pdata_dns_crossisp', 'pdata_http_3xx', 'pdata_http_zero', 'pdata_http_other', 'pdata_caddr_failed', 'pdata_correct',
    'cache_conn_failed', 'cache_http_3xx', 'cache_http_zero', 'cache_http_other', 'cache_speed_high', 'cache_speed_low', 'cache_correct',
]

USER_FIELDS  = {
    'isp': 0,
    'prvn': 1,
    'city': 2,
}

VRS_FIELDS   = {
    'vrs_resolv_failed': 0,
    'vrs_conn_failed': 1,

    'vrs_dns_incorrect': 2,
    'vrs_dns_crossisp': 3,

    'vrs_http_3xx': 4,
    'vrs_http_zero': 5,
    'vrs_http_other': 6,

    'vrs_ret_sterror': 7,
    'vrs_ret_cderror': 8,
    'vrs_correct': 9,
}

BOSS_FIELDS  = {
    'boss_resolv_failed': 0,
    'boss_conn_failed': 1,

    'boss_dns_incorrect': 2,
    'boss_dns_crossisp': 3,

    'boss_http_3xx': 4,
    'boss_http_zero': 5,
    'boss_http_other': 6,
    'boss_ret_incorrect': 7,
    'boss_correct': 8,
    'boss_total': 9,
}

PDATA_FIELDS = {
    'pdata_resolv_failed': 0,
    'pdata_conn_failed': 1,

    'pdata_dns_incorrect': 2,
    'pdata_dns_crossisp': 3,

    'pdata_http_3xx': 4,
    'pdata_http_zero': 5,
    'pdata_http_other': 6,
    'pdata_caddr_failed': 7,
    'pdata_correct': 8,
}

CACHE_FIELDS = {
    'cache_conn_failed': 0,

    'cache_http_3xx': 1,
    'cache_http_zero': 2,
    'cache_http_other': 3,
    'cache_speed_high': 4,
    'cache_speed_low': 5,
    'cache_correct': 6,
}

HTTP_FIELDS = {
    0: 1,
    1: 2,
    3: 0,
    4: 2,
    5: 2,
}

USER_FIELDS_NUM  = len(USER_FIELDS)
VRS_FIELDS_NUM   = len(VRS_FIELDS)
BOSS_FIELDS_NUM  = len(BOSS_FIELDS)
PDATA_FIELDS_NUM = len(PDATA_FIELDS)
CACHE_FIELDS_NUM = len(CACHE_FIELDS)

Row_DB = Row(*DB_COLUMNS)

zerotuple = lambda x: tuple([0]*x)

FUXI_API = "http://fuxi.qiyi.domain/?appkey=domainResolution&type=video&domain=%s&extends=1&recursion=1&account=netdoc&passwd=netdoc_dns"

def fetch_dnsinfo(url):
    """ Fetch dnsinfo from FUXI API query """
    f = urllib.urlopen(url=url)
    content = safe_load(f.read())
    if 'code' in content and content['code'] == 1:
        return content['data']
    return {}

def update_domain_dict():
    """ Update domain related dicts """
    global TOTAL_DNS, FUXI_API
    global DOMAIN_IP_DICT, IP_ISP_DICT, IP_DOMAIN_DICT
    global VRS_IP_LIST, BOSS_IP_LIST, PDATA_IP_LIST

    VRS_IP_LIST = []
    BOSS_IP_LIST = []
    PDATA_IP_LIST = []

    for domain in TOTAL_DNS:
        result = fetch_dnsinfo(FUXI_API % domain)
        DOMAIN_IP_DICT[domain] = list(set([i for key,value in result.iteritems() for i in value]))
        for ip in DOMAIN_IP_DICT[domain]:
            IP_ISP_DICT[ip] = list(set([key.split('|')[0] for key,value in result.iteritems() if ip in value]))
            IP_DOMAIN_DICT[ip] = domain
        if domain in VRS_DNS:
            VRS_IP_LIST += DOMAIN_IP_DICT.get(domain, [])
        if domain in BOSS_DNS:
            BOSS_IP_LIST += DOMAIN_IP_DICT.get(domain, [])
        if domain in PDATA_DNS:
            PDATA_IP_LIST += DOMAIN_IP_DICT.get(domain, [])

def load_geoinfo(isp_file, prvn_file, city_file):
    """ Load geoinfo to fulfill geoinfo code dict, which is used to encode geoinfo """
    global GEO_ISP_DICT, GEO_PRVN_DICT, GEO_CITY_DICT
    with open(isp_file, 'r') as f:
        for line in f.readlines():
            v, k, _, = line.split('|')
            GEO_ISP_DICT[k] = int(v)
    with open(prvn_file, 'r') as f:
        for line in f.readlines():
            v, k, _ = line.split('|')
            GEO_PRVN_DICT[k] = int(v)
    with open(city_file, 'r') as f:
        for line in f.readlines():
            v, _, k2, k1, _, _ = line.split('|')
            GEO_CITY_DICT["%s-%s" % (k1, k2)] = int(v)

def getSqlContext(sparkContext):
    """ Singleton of sqlContext """
    if 'sqlContextSingleton' not in globals():
        globals()['sqlContextSingleton'] = SQLContext(sparkContext)
    return globals()['sqlContextSingleton']

def host_resolver(ip):
    isp, prvn, xprvn = xhost_resolver(str(ip))
    return isp

def ip_identify(typ, user_ip, dns_ip):
    """ Check the user cross ip or not """
    if not user_ip and dns_ip:
        return "correct"
    if typ.upper() == "VRS":
        if dns_ip not in VRS_IP_LIST:
            return 'vrs_dns_incorrect'
        isp = host_resolver(user_ip)
        if isp not in IP_ISP_DICT[dns_ip]:
            return 'vrs_dns_crossisp'
    if typ.upper() == "PDATA":
        if dns_ip not in PDATA_IP_LIST:
            return 'pdata_dns_incorrect'
        isp = host_resolver(user_ip)
        if isp not in IP_ISP_DICT[dns_ip]:
            return 'pdata_dns_crossisp'
    if typ.upper() == "BOSS":
        if dns_ip not in BOSS_IP_LIST:
            return 'boss_dns_incorrect'
        isp = host_resolver(user_ip)
        if isp not in IP_ISP_DICT[dns_ip]:
            return 'boss_dns_crossisp'
    return 'correct'

def safe_load(jstr):
    """ Wrapper of json.loads """
    try:
        return json.loads(jstr)
    except Exception, e:
        print(">>> %s" % e)
    return {}

def transform(jstr):
    """ Transform the original Kafka message to json string """
    jobj = safe_load(jstr)

    if not jobj:
        return {}
    if 'sceneinfo' not in jobj:
        return {}

    if 'plat' not in jobj:
        jobj['plat'] = 99
    if isinstance(jobj["sceneinfo"], dict):
        jscene = jobj["sceneinfo"]
    else:
        jscene = safe_load(jobj["sceneinfo"])
    jscene['uid'] = jobj['uid']
    jscene['ver'] = jobj['ver']
    jscene['plat'] = int(jobj['plat'])
    jscene['ip'] = jobj['ip']
    jscene['zone'] = jobj['zone']
    jscene['isp'] = encode_isp(jobj['isp'])
    jscene['prvn'] = encode_prvn(jobj['prvn'])
    jscene['city'] = encode_city(jobj['prvn'], jobj['city'])
    return jscene

SCHEDULE = sched.scheduler(time.time, time.sleep)

def sched_task(func, args, delay=3600, interval=3600):
    def do_task(func, args, interval):
        SCHEDULE.enter(interval, 0, do_task, (func, args, interval))
        if callable(func): func(*args)
    SCHEDULE.enter(delay, 0, do_task, (func, args, interval))
    SCHEDULE.run()

def parse_vrs(jobj, user_ip):
    """ Collect vrs info by parsing json['fd']['puma'] section """
    if not jobj:
        return zerotuple(VRS_FIELDS_NUM)
    if 'vrs' not in jobj:
        return zerotuple(VRS_FIELDS_NUM)
    # TODO:
    # Can't use start-tick and establish-tick to distinguish
    # connection or vrs_resolv status for the two numbers are both -1

    # vrs_url
    if 'vu' not in jobj['vrs'] or not jobj['vrs']['vu']:
        return zerotuple(VRS_FIELDS_NUM)
    # vrs_ip
    if 'vi' not in jobj['vrs'] or not jobj['vrs']['vi']:
        return (1,) + zerotuple(VRS_FIELDS_NUM-1)
    # conn_tick and establish_tick
    if 'vcst' not in jobj['vrs'] or 'vcet' not in jobj['vrs'] \
            or not jobj['vrs']['vcst'].isdigit() or not jobj['vrs']['vcet'].isdigit() \
            or (int(jobj['vrs']['vcst']) != -1 and int(jobj['vrs']['vcet']) == -1):
        loc = VRS_FIELDS['vrs_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(VRS_FIELDS_NUM-loc-1)
    # user_ip dns check
    ret = ip_identify("VRS", user_ip, jobj['vrs']['vi'])
    if ret != 'correct':
        loc = VRS_FIELDS[ret]
        return zerotuple(loc) + (1,) + zerotuple(VRS_FIELDS_NUM-loc-1)
    # http
    if 'vfs' not in jobj['vrs'] or not jobj['vrs']['vfs'].isdigit():
        loc = VRS_FIELDS['vrs_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(VRS_FIELDS_NUM-loc-1)

    value = int(jobj['vrs']['vfs']) // 100
    if value != 2:
        loc = VRS_FIELDS['vrs_http_3xx'] + HTTP_FIELDS[value]
        tup = zerotuple(loc) + (1,) + zerotuple(VRS_FIELDS_NUM-loc-1)
        return tup
    # vrs_ret_code
    if 'vrc' not in jobj['vrs'] or jobj['vrs']['vrc'] != 'A00000':
        loc = VRS_FIELDS['vrs_ret_cderror']
        tup = zerotuple(loc) + (1,) + zerotuple(VRS_FIELDS_NUM-loc-1)
        return tup
    # vrs_ret_st
    if 'vrs' not in jobj['vrs'] or not jobj['vrs']['vrs'].isdigit() or (int(jobj['vrs']['vrs']) != 101 and int(jobj['vrs']['vrs']) != 200):
        loc = VRS_FIELDS['vrs_ret_sterror']
        tup = zerotuple(loc) + (1,) + zerotuple(VRS_FIELDS_NUM-loc-1)
        return tup
    # all correct
    loc = VRS_FIELDS['vrs_correct']
    tup = zerotuple(loc) + (1,)
    return tup

def parse_boss(jobj, user_ip):
    """ Collect boss info by parsing json['fd']['puma'] section """
    if not jobj:
        return zerotuple(BOSS_FIELDS_NUM)
    if 'boss' not in jobj:
        return zerotuple(BOSS_FIELDS_NUM)
    if 'bst' not in jobj['boss'] or not jobj['boss']['bst']:
        return zerotuple(BOSS_FIELDS_NUM)
    # boss url
    if 'bu' not in jobj['boss'] or not jobj['boss']['bu']:
        return zerotuple(BOSS_FIELDS_NUM)
    # boss ip
    if 'bi' not in jobj['boss'] or not jobj['boss']['bi']:
        return (1,) + zerotuple(BOSS_FIELDS_NUM-2) + (1,)
    # conn_tick and establish_tick
    if 'bcst' not in jobj['boss'] or 'bcet' not in jobj['boss'] \
            or not jobj['boss']['bcst'].isdigit() or not jobj['boss']['bcet'].isdigit() \
            or (int(jobj['boss']['bcst']) != -1 and int(jobj['boss']['bcet']) == -1):
        loc = BOSS_FIELDS['boss_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(BOSS_FIELDS_NUM-loc-2) + (1,)
    # user_ip dns check
    ret = ip_identify("BOSS", user_ip, jobj['boss']['bi'])
    if ret != 'correct':
        loc = BOSS_FIELDS[ret]
        return zerotuple(loc) + (1,) + zerotuple(BOSS_FIELDS_NUM-loc-2) + (1,)
    # http
    if 'bfs' not in jobj['boss'] or not jobj['boss']['bfs'].isdigit():
        loc = BOSS_FIELDS['boss_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(BOSS_FIELDS_NUM-loc-2) + (1,)

    value = int(jobj['boss']['bfs']) // 100
    if value != 2:
        loc = BOSS_FIELDS['boss_http_3xx'] + HTTP_FIELDS[value]
        tup = zerotuple(loc) + (1,) + zerotuple(BOSS_FIELDS_NUM-loc-2) + (1,)
        return tup
    # all correct and set total 1
    loc = BOSS_FIELDS['boss_correct']
    tup = zerotuple(loc) + (1,1)
    return tup

def parse_pdata(jobj, user_ip):
    """ Collect pdata info by parsing json['fd']['hcdn'] section """
    if not jobj:
        return zerotuple(PDATA_FIELDS_NUM)
    if 'disp' not in jobj:
        return zerotuple(PDATA_FIELDS_NUM)
    # disp_url
    if 'du' not in jobj['disp'] or not jobj['disp']['du']:
        return zerotuple(PDATA_FIELDS_NUM)
    # disp_ip
    if 'di' not in jobj['disp'] or not jobj['disp']['di']:
        return (1,) + zerotuple(PDATA_FIELDS_NUM-1)
    # conn_tick and establish_tick
    if 'dcst' not in jobj['disp'] or 'dcet' not in jobj['disp'] \
            or not jobj['disp']['dcst'].isdigit() or not jobj['disp']['dcst'].isdigit() \
            or (int(jobj['disp']['dcst']) != -1 and int(jobj['disp']['dcet']) == -1):
        loc = PDATA_FIELDS['pdata_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(PDATA_FIELDS_NUM-loc-1)
    # user_ip dns check
    ret = ip_identify("PDATA", user_ip, jobj['disp']['di'])
    if ret != 'correct':
        loc = PDATA_FIELDS[ret]
        return zerotuple(loc) + (1,) + zerotuple(PDATA_FIELDS_NUM-loc-1)
    # http
    if 'dfs' not in jobj['disp'] or not jobj['disp']['dfs'].isdigit():
        loc = PDATA_FIELDS['pdata_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(PDATA_FIELDS_NUM-loc-1)

    value = int(jobj['disp']['dfs']) // 100
    if value != 2:
        loc = PDATA_FIELDS['pdata_http_3xx'] + HTTP_FIELDS[value]
        tup = zerotuple(loc) + (1,) + zerotuple(PDATA_FIELDS_NUM-loc-1)
        return tup
    # addr resolve error
    if 'drd' not in jobj['disp'] or not jobj['disp']['drd']:
        loc = PDATA_FIELDS['pdata_caddr_failed'] + HTTP_FIELDS[value]
        tup = zerotuple(loc) + (1,) + zerotuple(PDATA_FIELDS_NUM-loc-1)
        return tup
    # all correct
    loc = PDATA_FIELDS['pdata_correct']
    tup = zerotuple(loc) + (1,)
    return tup

def parse_cache(jobj):
    """ Collect cache info by parsing json['fd']['hcdn'] section """
    if not jobj:
        return zerotuple(CACHE_FIELDS_NUM)
    if 'cache' not in jobj:
        return zerotuple(CACHE_FIELDS_NUM)
    # cache_url
    if 'cu' not in jobj['cache'] or not jobj['cache']['cu']:
        return zerotuple(CACHE_FIELDS_NUM)
    # cache_ip
    if 'ci' not in jobj['cache'] or not jobj['cache']['ci']:
        return (1,) + zerotuple(CACHE_FIELDS_NUM-1)
    # conn_tick and establish_tick
    if 'ccst' not in jobj['cache'] or 'ccet' not in jobj['cache'] \
            or not jobj['cache']['ccst'].isdigit() or not jobj['cache']['ccet'].isdigit() \
            or (int(jobj['cache']['ccst']) != -1 and int(jobj['cache']['ccet']) == -1):
        loc = CACHE_FIELDS['cache_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(CACHE_FIELDS_NUM-loc-1)
    # http
    if 'cfs' not in jobj['cache'] or not jobj['cache']['cfs'].isdigit():
        loc = CACHE_FIELDS['cache_conn_failed']
        return zerotuple(loc) + (1,) + zerotuple(CACHE_FIELDS_NUM-loc-1)

    value = int(jobj['cache']['cfs']) // 100
    if value != 2 and int(jobj['cache']['cfs']) != 302:
        loc = CACHE_FIELDS['cache_http_3xx'] + HTTP_FIELDS[value]
        tup = zerotuple(loc) + (1,) + zerotuple(CACHE_FIELDS_NUM-loc-1)
        return tup
    if int(jobj['cache']['cfs']) == 302 and 'cls' in jobj['cache'] \
            and jobj['cache']['cls'].isdigit() and (int(jobj['cache']['cls']) // 100) != 2:
        value = int(jobj['cache']['cls']) // 100
        loc = CACHE_FIELDS['cache_http_3xx'] + HTTP_FIELDS[value]
        tup = zerotuple(loc) + (1,) + zerotuple(CACHE_FIELDS_NUM-loc-2) + (1,)
        return tup
    # cache speed
    if 'cas' in jobj['cache'] and jobj['cache']['cas'].isdigit():
        loc = (CACHE_FIELDS['cache_speed_low'] if int(jobj['cache']['cas']) < 100 else CACHE_FIELDS['cache_speed_high'])
        tup = zerotuple(loc) + (1,) + zerotuple(CACHE_FIELDS_NUM-loc-2) + (1,)
        return tup
    # all correct
    loc = CACHE_FIELDS['cache_correct']
    tup = zerotuple(loc) + (1,)
    return tup


def parse(jobj):
    """ Collect all info by parsing fly_data """
    if 'fd' not in jobj:
        return ((0, 0, 0), (1, 1)+zerotuple(len(DB_COLUMNS)-7))
    if 'puma' not in jobj['fd']:
        return ((0, 0, 0), (1, 1)+zerotuple(len(DB_COLUMNS)-7))
    if 'hcdn' not in jobj['fd']:
        return ((0, 0, 0), (1, 1)+zerotuple(len(DB_COLUMNS)-7))

    puma = jobj['fd']['puma']
    hcdn = jobj['fd']['hcdn']

    user_ip = jobj['ip'] or ""
    ret_vrs = parse_vrs(puma, user_ip)

    ret_boss = zerotuple(BOSS_FIELDS_NUM)
    if puma.has_key('boss') and puma['boss'].has_key('bst') and puma['boss']['bst'] >= 0:
        ret_boss = parse_boss(puma, user_ip)
    else:
        ret_boss = parse_boss(hcdn, user_ip)
    ret_pdata = parse_pdata(hcdn, user_ip)
    ret_cache = parse_cache(hcdn)
    return ((jobj['isp'], jobj['prvn'], jobj['city']), (1, 0)+ret_vrs+ret_boss+ret_pdata+ret_cache)

def count(x, y):
    """ Count the '1' numbers by tuple """
    return tuple(map(lambda i, j: i + j, x, y))

encode_isp = lambda isp: isinstance(isp, int) and isp or GEO_ISP_DICT.get(isp, 0)
encode_prvn = lambda prvn: isinstance(prvn, int) and prvn or GEO_PRVN_DICT.get(prvn, 0)
encode_city = lambda prvn, city: isinstance(city, int) and city or GEO_CITY_DICT.get("%s-%s" %(prvn, city), 0)

def convert(now, tup):
    """ Convert to pyspark.sql.Row """
    coded_key = (encode_isp(tup[0][0]), encode_prvn(tup[0][1]), encode_city(tup[0][1], tup[0][2]))
    row = [0, str(now)] + list(coded_key + tup[1])
    return Row_DB(*row)

def process(time, rdd):
    """ Process RDDs in each DStream

    First decode json string from Kafka message, then parse all fly data from it
    by key tuple (isp, province, city), finally insert the result to mysql database via jdbc.
    """
    print("========= %s %s==========" % (str(time), type(rdd)))
    # the message format from Kafka would be (None, u'{"uid":uid, "plat":plat, ..., "fly_data":str}')
    js_entry = rdd.map(lambda x: transform(x[1]))
    oj_match = js_entry.map(parse)
    cnt_tup = oj_match.reduceByKey(lambda x, y: count(x, y))
    cnt_rows = cnt_tup.map(lambda x: convert(time, x))

    try:
        sqlContext = getSqlContext(rdd.context)
        # Specify the columns order, otherwise jdbc will insert rows in alphabet-order-column
        dns_df = sqlContext.createDataFrame(cnt_rows)
        dns_df.write.jdbc(
            url = "jdbc:mysql://10.153.3.74:3306/aem_stats?user=netdoctor&password=123456",
            table = "xsceneinfo_summary",
            mode = "append",
        )
    except Exception, e:
        print(">>> %s" % traceback.format_exc())

def utf8_decoder(s):
    """ Decode function for Kafka DStream """
    if s is None:
        return ""
    try:
        return s.decode('utf-8')
    except UnicodeDecodeError, e:
        print(">>> %s" % e)
    return s

if __name__ == "__main__":
    # load geoinfo from csv file
    load_geoinfo('isp.csv', 'prvn.csv', 'city.csv')
    s_thread = threading.Thread(target=sched_task, args=(update_domain_dict, (), 1800, 3600))
    s_thread.start()

    sc = SparkContext()
    ssc = StreamingContext(sc, 300) # 5min for real-time analysis
    sqlContext = getSqlContext(sc)

    topics = {"aem_sceneinfo": 5}
    zk_quorum = ",".join(zookeepers)
    kfk_stream = KafkaUtils.createStream(ssc, zk_quorum, "xaem-group", topics, keyDecoder=utf8_decoder, valueDecoder=utf8_decoder)

    # each partition is supposed to be separated by 'timepoint'
    kfk_stream.foreachRDD(process)

    ssc.start()
    ssc.awaitTermination()
