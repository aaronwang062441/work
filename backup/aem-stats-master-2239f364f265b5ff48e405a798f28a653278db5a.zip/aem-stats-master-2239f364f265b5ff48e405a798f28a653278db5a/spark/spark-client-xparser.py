#!/usr/bin/env python
#
# Copyright (c) 2016 iQIYI.com
# Author(s): Chen Gui <chengui@qiyi.com>
#
# This script is used to statistics the local DNS summary of all stuckinfo posted
# by NetDoctor client, the real-time infrastructure is supported by spark streaming,
# which is using Kafka messaging system as provider.
# NOTICE: to enable jdbc, spark needs extra configuration:
#   '--conf spark.driver.extraClassPath=./mysql-connector-java-5.1.38.jar
#    --conf spark.executor.extraClassPath=./mysql-connector-java-5.1.38.jar'

from __future__ import print_function
from __future__ import with_statement
import sys
import time
import json
import datetime
import traceback
import sched
import urllib
import threading

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import SQLContext, Row

APPNAME = "aem-ndctparser"

# Geoinfo Code for ISP, PROVINCE, CITY
GEO_ISP_DICT = dict()
GEO_PRVN_DICT = dict()
GEO_CITY_DICT = dict()

# Quorum of zoookeepers used by Kafka
zookeepers = [
    "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181",
]

# VRS domain urls
VRS_DNS = ['cache.video.qiyi.com', 'cache.video.ptqy.gitv.tv']

# PDATA domain urls
PDATA_DNS = ['data.video.qiyi.com', 'f.live.video.qiyi.com', 'pdata.video.qiyi.com', 'sf.video.qiyi.com', 'pdata.video.ptqy.gitv.tv']

DNS_DICT = {'VRS': [], 'PDATA': [], 'CACHE': []}

DNS_LIST = {'VRS': [], 'PDATA': [], 'CACHE': []}

DB_COLUMNS = [
    'id', 'time', 'isp', 'prvn', 'city', 'total', 'tmo_network', 'tmo_vrs', 'tmo_pdata', 'tmo_m3u8', 'tmo_vip',
    'vrs_code_zero', 'vrs_code_2xx', 'vrs_code_3xx', 'vrs_code_4xx', 'vrs_code_5xx', 'vrs_ip_absent', 'vrs_ip_present', 'vrs_ip_crossisp',
    'pdata_code_zero', 'pdata_code_2xx', 'pdata_code_3xx', 'pdata_code_4xx', 'pdata_code_5xx', 'pdata_ip_absent', 'pdata_ip_present', 'pdata_ip_crossisp',
    'cache_code_zero', 'cache_code_2xx', 'cache_code_3xx', 'cache_code_4xx', 'cache_code_5xx', 'cache_ip_absent', 'cache_ip_present', 'cache_ip_crossisp',
]

Row_DB = Row(*DB_COLUMNS)

# Define Enum type
def enum(*seq, **named):
    enums = dict(zip(seq, range(len(seq))), len=len(seq), **named)
    return type('Enum', (), enums)

# Definition of Constants
Steps = enum(
    # Network timeout
    'ERROR_VIDTVID', 'NETWORK_START', 'NETWORK_FAILED', 'NETWORK_OK', # 0-3
    # VIP TIMEOUT for non-bighero
    'USER_PREPAREBEGIN', 'USER_PREPAREOK', 'USER_PREPAREFAILED',      # 4-6
    # VRS TIMEOUT
    'VRS_VIDBEGIN', 'VRS_VIDOK', 'VRS_VIDFAILD',                      # 7-9
    # VIP TIMEOUT
    'GET_KEYBEGIN', 'GET_KEYOK', 'GET_KEYFAILED',                     # 10-12
    # M3U8 TIMEOUT
    'GET_M3U8BEGIN', 'GET_M3U8OK', 'GET_M3U8FAILED',                  # 13-15
    # PDATA TIMEOUT
    'AUT_BEGIN', 'AUT_OK', 'AUT_FAILED',                              # 16-18
    # Impossible, Network timeout
    'DOWNLOAD_BEGIN', 'DWONLOAD_FAILED', 'DOWNLOAD_END', 'COMPLETE',  # 19-22
    # Impossible for 25, 26 present
    'VRS_URL_HIJACK', 'PDATA_URL_HIJACK', 'DOWNLOAD_URL_HIJACK', 'GET_M3U8_URL_HIJACK', # 23-26
)

TIMEOUT_STEPS = {
    'TMO_NETWORK': (Steps.ERROR_VIDTVID, Steps.NETWORK_START, Steps.NETWORK_FAILED, Steps.NETWORK_OK),
    'TMO_VRS'    : (Steps.VRS_VIDBEGIN, Steps.VRS_VIDOK, Steps.VRS_VIDFAILD),
    'TMO_PDATA'  : (Steps.AUT_BEGIN, Steps.AUT_OK, Steps.AUT_FAILED),
    'TMO_M3U8'   : (Steps.GET_M3U8BEGIN, Steps.GET_M3U8OK, Steps.GET_M3U8FAILED),
    'TMO_VIP'    : (Steps.GET_KEYBEGIN, Steps.GET_KEYOK, Steps.GET_KEYFAILED),
    'VIP_OLD'    : (Steps.USER_PREPAREBEGIN, Steps.USER_PREPAREOK, Steps.USER_PREPAREFAILED),
}

STEPS_TIMEOUT = dict([(i, k) for k,v in TIMEOUT_STEPS.iteritems() for i in v])

def enumtuple(*seq, **named):
    rotate = lambda l, n: l[-n:] + l[:-n]
    tuples = map(lambda i: tuple(rotate([1]+[0]*(len(seq)-1), i)), range(len(seq)))
    return type('EnumTuple', (), dict(zip(seq, tuples), len=len(seq), **named))

# TIMEOUT, CODE_ZERO, CODE_2XX, CODE_3XX, CODE_4XX, CODE_5XX, IP_ABSENT, IP_PRESNET, IP_CROSSISP
zerotuple = lambda x: tuple([0]*x)
ETUP_TMO = enumtuple('TMO_NETWORK', 'TMO_VRS', 'TMO_PDATA', 'TMO_M3U8', 'TMO_VIP')
ETUP_CODE = enumtuple('CODE_ZERO', 'CODE_2XX', 'CODE_3XX', 'CODE_4XX', 'CODE_5XX')
ETUP_IP = enumtuple('IP_ABSENT', 'IP_PRESENT', 'IP_CROSSISP')

def load_geoinfo(isp_file, prvn_file, city_file):
    """ Load geoinfo to fulfill geoinfo code dict, which is used to encode geoinfo """
    global GEO_ISP_DICT, GEO_PRVN_DICT, GEO_CITY_DICT
    with open(isp_file, 'r') as f:
        for line in f.readlines():
            v, k, _, = line.split('|')
            GEO_ISP_DICT[k] = int(v)
    with open(prvn_file, 'r') as f:
        for line in f.readlines():
            v, k, _ = line.split('|')
            GEO_PRVN_DICT[k] = int(v)
    with open(city_file, 'r') as f:
        for line in f.readlines():
            v, _, k2, k1, _, _ = line.split('|')
            GEO_CITY_DICT["%s-%s" % (k1, k2)] = int(v)

def getSqlContext(sparkContext):
    """ Singleton of sqlContext """
    if 'sqlContextSingleton' not in globals():
        globals()['sqlContextSingleton'] = SQLContext(sparkContext)
    return globals()['sqlContextSingleton']

def safe_load(jstr):
    """ Wrapper of json.loads """
    try:
        return json.loads(jstr)
    except Exception, e:
        print(">>> %s" % e)
    return {}

FUXI_API = "http://fuxi.qiyi.domain/?appkey=domainResolution&type=video&domain=%s&extends=1&recursion=1&account=netdoc&passwd=netdoc_dns"

def fetch_dnsinfo(url):
    """ Fetch dnsinfo from FUXI API query """
    f = urllib.urlopen(url=url)
    content = safe_load(f.read())
    if 'code' in content and content['code'] == 1:
        return content['data']
    return {}

def update_dns_info():
    """ Update dns domain related infos """
    global DNS_LIST

    dns_vrs_list = []
    dns_vrs_dict = dict()
    dns_pdata_list = []
    dns_pdata_dict = dict()

    #update vrs
    for k in ['CT', 'CNC', 'CMNET', 'OTHER']:
        dns_vrs_dict[k] = []
        dns_pdata_dict[k] = []

    for domain in VRS_DNS:
        result = fetch_dnsinfo(FUXI_API % domain)

        for k in ['CT', 'CNC', 'CMNET']:
            dns_vrs_dict[k] += reduce(lambda x,y: x+y, [value for (key,value) in result.iteritems() if key.split('|')[0].upper()==k])

        dns_vrs_dict['OTHER'] += reduce(lambda x,y: x+y, [value for (key,value) in result.iteritems() if key.split('|')[0].upper() not in ['CT','CNC','CMNET']])

    for k in ['CT', 'CNC', 'CMNET', 'OTHER']:
        dns_vrs_dict[k] = list(set(dns_vrs_dict[k]))

    dns_vrs_list = [i for k,v in dns_vrs_dict.iteritems() for i in v]
    dns_vrs_list = list(set(dns_vrs_list))

    #update pdata
    for domain in PDATA_DNS:
        result = fetch_dnsinfo(FUXI_API % domain)

        for k in ['CT', 'CNC', 'CMNET']:
            dns_pdata_dict[k] += reduce(lambda x,y: x+y, [value for (key,value) in result.iteritems() if key.split('|')[0].upper()==k])

        dns_pdata_dict['OTHER'] += reduce(lambda x,y: x+y, [value for (key,value) in result.iteritems() if key.split('|')[0].upper() not in ['CT','CNC','CMNET']])

    for k in ['CT', 'CNC', 'CMNET', 'OTHER']:
        dns_pdata_dict[k] = list(set(dns_pdata_dict[k]))

    dns_pdata_list = [i for k,v in dns_pdata_dict.iteritems() for i in v]
    dns_pdata_list = list(set(dns_pdata_list))

    DNS_LIST.update({"VRS": dns_vrs_list})
    DNS_DICT.update({"VRS": dns_vrs_dict})
    DNS_LIST.update({"PDATA": dns_pdata_list})
    DNS_DICT.update({"PDATA": dns_pdata_dict})

SCHEDULE = sched.scheduler(time.time, time.sleep)

def sched_task(func, args, delay=3600, interval=3600):
    def do_task(func, args, interval):
        SCHEDULE.enter(interval, 0, do_task, (func, args, interval))
        if callable(func): func(*args)
    SCHEDULE.enter(delay, 0, do_task, (func, args, interval))
    SCHEDULE.run()

def transform(jstr):
    """ Transform the original Kafka message to json string """
    jobj = safe_load(jstr)
    if 'plat' not in jobj:
        jobj['plat'] = 99
    if 'stuckinfo' not in jobj:
        return jobj
    jstuck = safe_load(jobj["stuckinfo"])
    jstuck['uid'] = jobj['uid']
    jstuck['ver'] = jobj['ver']
    jstuck['plat'] = int(jobj['plat'])
    jstuck['ip'] = jobj['ip']
    jstuck['zone'] = jobj['zone']
    jstuck['isp'] = jobj['isp']
    jstuck['prvn'] = 'prvn' in jobj and jobj['prvn'] or jobj['zone'].split('-')[0]
    jstuck['city'] = 'city' in jobj and jobj['city'] or jobj['zone'].split('-')[1]
    return jstuck

def classify_code(code):
    CODE_LIST = ['CODE_ZERO', 'CODE_ZERO', 'CODE_2XX', 'CODE_3XX', 'CODE_4XX', 'CODE_5XX']
    return getattr(ETUP_CODE, CODE_LIST[int(code)/100] if int(code) < 600 else 'CODE_ZERO')

def classify_ip(typ, svr_ip, clt_isp):
    ip_list = svr_ip.split("|")
    if not set(ip_list).issubset(set(DNS_LIST[typ])):
        return ETUP_IP.IP_ABSENT
    if clt_isp not in DNS_DICT[typ]:
        clt_isp = "OTHER"
    if not set(ip_list).issubset(DNS_DICT[typ][clt_isp]):
        return ETUP_IP.IP_CROSSISP
    return ETUP_IP.IP_PRESENT

def parse_timeout(jobj):
    if 'timeout' not in jobj['play_result']:
        jobj['play_result']['timeout'] = 0
    if 'step' not in jobj['play_result']:
        jobj['play_result']['step'] = 0
    if int(jobj['play_result']['timeout']) == 0:
        return zerotuple(ETUP_TMO.len)
    step = int(jobj['play_result']['step'])
    if step < 0: return zerotuple(ETUP_TMO.len)
    if step >= Steps.DOWNLOAD_BEGIN:
        return ETUP_TMO.TMO_NETWORK
    if STEPS_TIMEOUT[step] == "VIP_OLD":
        if jobj['ver'].startswith('1.0.2.'):
            return ETUP_TMO.TMO_VIP
        else:
            return ETUP_TMO.NETWORK
    if STEPS_TIMEOUT[step] == "TMO_VIP":
        if jobj['ver'].startswith('1.0.2.'):
            return zerotuple(ETUP_TMO.len)
        else:
            return ETUP_TMO.TMO_VIP
    return getattr(ETUP_TMO, STEPS_TIMEOUT[step])

def parse_vrs(jobj):
    if 'access_vrs' not in jobj['play_result']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'url' not in jobj['play_result']['access_vrs'] or not jobj['play_result']['access_vrs']['url']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'code' not in jobj['play_result']['access_vrs'] or not str(jobj['play_result']['access_vrs']['code']).isdigit():
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'ip' not in jobj['play_result']['access_vrs'] or not jobj['play_result']['access_vrs']['ip']:
        jobj['play_result']['access_vrs']['ip'] = '0.0.0.0'
    ret_code = classify_code(jobj['play_result']['access_vrs']['code'])
    ret_ip = classify_ip('VRS', jobj['play_result']['access_vrs']['ip'], jobj['isp'])
    return ret_code + ret_ip

def parse_pdata(jobj):
    if 'access_pdata' not in jobj['play_result']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'url' not in jobj['play_result']['access_pdata'] or not jobj['play_result']['access_pdata']['url']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'code' not in jobj['play_result']['access_pdata'] or not str(jobj['play_result']['access_pdata']['code']).isdigit():
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'ip' not in jobj['play_result']['access_pdata'] or not jobj['play_result']['access_pdata']['ip']:
        jobj['play_result']['access_pdata']['ip'] = '0.0.0.0'
    ret_code = classify_code(jobj['play_result']['access_pdata']['code'])
    ret_ip = classify_ip('PDATA', jobj['play_result']['access_pdata']['ip'], jobj['isp'])
    return ret_code + ret_ip

def parse_cache(jobj):
    if 'cache_status' not in jobj['play_result']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'url' not in jobj['play_result']['cache_status'] or not jobj['play_result']['cache_status']['url']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'code' not in jobj['play_result']['cache_status'] or not str(jobj['play_result']['cache_status']['code']).isdigit():
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)

    if 'avg_speed' in jobj['play_result']['cache_status'] and int(jobj['play_result']['cache_status']['avg_speed']) > 0:
        ret_code = classify_code('200')
    elif str(jobj['play_result']['cache_status']['url']).find('.inter.iqiyi.com') != -1 \
            or str(jobj['play_result']['cache_status']['url']).find('.inter.qiyi.com') != -1:
        ret_code = classify_code('200')
    else:
        ret_code = classify_code(jobj['play_result']['cache_status']['code'])
    ret_ip = zerotuple(ETUP_IP.len) #classify_ip('CACHE', jobj['play_result']['cache_status']['ip'], jobj['isp'])
    return ret_code + ret_ip

def parse(jobj):
    """ Collect all dns info by parsing stuckinfo """
    if 'play_result' not in jobj:
        return (('None', 'None', 'None'), (1,)+zerotuple(ETUP_TMO.len+ETUP_CODE.len*3+ETUP_IP.len*3))
    if 'file_tpye' not in jobj['play_result']:
        jobj['play_result']['file_tpye'] = 'F4V'
    ret_tmo = parse_timeout(jobj)
    ret_vrs = parse_vrs(jobj)
    ret_pdata = parse_pdata(jobj)
    ret_cache = parse_cache(jobj)
    return ((jobj['isp'], jobj['prvn'], jobj['city']), (1,)+ret_tmo+ret_vrs+ret_pdata+ret_cache)

def count(x, y):
    """ Count the '1' numbers by tuple """
    return tuple(map(lambda i, j: i + j, x, y))

encode_isp = lambda isp: isinstance(isp, int) and isp or GEO_ISP_DICT.get(isp, 0)
encode_prvn = lambda prvn: isinstance(prvn, int) and prvn or GEO_PRVN_DICT.get(prvn, 0)
encode_city = lambda prvn, city: isinstance(city, int) and city or GEO_CITY_DICT.get("%s-%s" %(prvn, city), 0)

def convert(now, tup):
    """ Convert to pyspark.sql.Row """
    coded_key = (encode_isp(tup[0][0]), encode_prvn(tup[0][1]), encode_city(tup[0][1], tup[0][2]))
    row = [0, str(now)] + list(coded_key + tup[1])
    return Row_DB(*row)

def process(time, rdd):
    """ Process RDDs in each DStream

    First decode json string from Kafka message, then parse all stuck info from it
    by key tuple (isp, province, city), finally insert the result to mysql database via jdbc.
    """
    print("========= %s %s==========" % (str(time), type(rdd)))
    # the message format from Kafka would be (None, u'{"uid":uid, "plat":plat, ..., "stuckinfo":str}')
    js_entry = rdd.map(lambda x: transform(x[1]))
    oj_match = js_entry.map(parse)
    cnt_tup = oj_match.reduceByKey(lambda x, y: count(x, y))
    cnt_rows = cnt_tup.map(lambda x: convert(time, x))

    try:
        sqlContext = getSqlContext(rdd.context)
        # Specify the columns order, otherwise jdbc will insert rows in alphabet-order-column
        dns_df = sqlContext.createDataFrame(cnt_rows)[DB_COLUMNS]
        dns_df.write.jdbc(
            url = "jdbc:mysql://10.153.3.74:3306/aem_stats?user=netdoctor&password=123456",
            table = "xndctinfo_summary",
            mode = "append",
        )
    except Exception, e:
        print(">>> %s" % traceback.format_exc())

def utf8_decoder(s):
    """ Decode function for Kafka DStream """
    if s is None:
        return ""
    try:
        return s.decode('utf-8')
    except UnicodeDecodeError, e:
        print(">>> %s" % e)
    return s

if __name__ == "__main__":
    # load geoinfo from csv file
    load_geoinfo('isp.csv', 'prvn.csv', 'city.csv')
    s_thread = threading.Thread(target=sched_task, args=(update_dns_info, (), 0, 3600))
    s_thread.start()

    sc = SparkContext()
    ssc = StreamingContext(sc, 300) # 5min for real-time analysis
    sqlContext = getSqlContext(sc)

    topics = {"aem_ndctinfo": 5}
    zk_quorum = ",".join(zookeepers)
    kfk_stream = KafkaUtils.createStream(ssc, zk_quorum, "xaem-group", topics, keyDecoder=utf8_decoder, valueDecoder=utf8_decoder)

    # each partition is supposed to be separated by 'timepoint'
    kfk_stream.foreachRDD(process)

    ssc.start()
    ssc.awaitTermination()
