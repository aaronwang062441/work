#!/usr/bin/env python
#
# Copyright (c) 2016 iQIYI.com
# Author(s): Chen Gui <chengui@qiyi.com>
# Author(s): Zhang Xianbao <zhangxianbao@qiyi.com>
# Author(s): pengyajie <pengyajie@qiyi.com>
#
# This script is used to statistics the real-time summary of all pingback info posted
# by NetDoctor client, the real-time infrastructure is supported by spark streaming,
# which is using Kafka messaging system as provider.
# NOTICE: to enable jdbc, spark needs extra configuration:
#   '--conf spark.driver.extraClassPath=./mysql-connector-java-5.1.38.jar
#    --conf spark.executor.extraClassPath=./mysql-connector-java-5.1.38.jar'

from __future__ import print_function
from __future__ import with_statement
import os
import math
import json
import time
import fcntl
import sched
import threading
import urllib
import traceback

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import SQLContext, Row

URL_API     = "http://aem.qiyi.domain/api/prepare/url.json"

# process safe to import ipresolver
LOCKFILE = os.path.join(os.getcwd(), 'lock')
with open(LOCKFILE, 'w') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    try:
        from ipresolver import ipresolver
        HAS_IPLIB = True
    except:
        HAS_IPLIB = False
    finally:
        fcntl.flock(lock, fcntl.LOCK_UN)
try:
    os.remove(LOCKFILE)
except:
    pass

# implict xhost_resolver
if HAS_IPLIB:
    xhost_resolver = ipresolver.HostIPResolver()
else:
    def xhost_resolver(ip):
        return "None", "None", "None"

APPNAME = "aem-pingback"

# Define Enum type
def enum(*seq, **named):
    enums = dict(zip(seq, range(len(seq))), len=len(seq), **named)
    return type('Enum', (), enums)

# Result state: NO_RETURN, ERROR_RETURN, CORRECT_RETURN, HTTPCODE_ZERO, HTTPCODE_2XX, HTTPCODE_3XX, HTTPCODE_4XX, HTTPCODE_5XX, HTTPCODE_OTHER, OTHER
RState = enum(
    'NO_RETURN',
    'ERROR_RETURN',
    'CORRECT_RETURN',
    'HTTPCODE_ZERO',
    'HTTPCODE_2XX',
    'HTTPCODE_3XX',
    'HTTPCODE_4XX',
    'HTTPCODE_5XX',
    'HTTPCODE_OTHER',
    'OTHER'
)

def rotate(l, n):
    """ Rotate tuple/list """
    return l[-n:] + l[:-n]

# Result tuple definition: (TOTAL, NO_RETURN, ERROR_RETURN, CORRECT_RETURN, HTTPCODE_ZERO, HTTPCODE_2XX, HTTPCODE_3XX, HTTPCODE_4XX, HTTPCODE_5XX, HTTPCODE_OTHER, OTHER)
RTuple = map(lambda i: tuple([1]+rotate([1]+[0]*(RState.len-1), i)), range(RState.len))

# Quorum of zookeepers used by Kafka
zookeepers = [
    "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181",
    "hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181"
]

# Code dict for isp, province, city
GEO_ISP_DICT = dict()
GEO_PRVN_DICT = dict()
GEO_CITY_DICT = dict()

# Code dict for url which is being detected
URL_DICT = dict()

# Domain-to-ip dict for standard domain name resolution rules
DOMAIN_IP_DICT = dict()

encode_isp = lambda isp: isinstance(isp, int) and isp or GEO_ISP_DICT.get(isp, 0)
encode_prvn = lambda prvn: isinstance(prvn, int) and prvn or GEO_PRVN_DICT.get(prvn, 0)
encode_city = lambda prvn, city: isinstance(city, int) and city or GEO_CITY_DICT.get("%s-%s" % (prvn, city), 0)
encode_url = lambda url: isinstance(url, int) and url or URL_DICT.get(url, 0)


def safe_load(jstr):
    """ Wrapper of json.loads """
    try:
        return json.loads(jstr)
    except Exception, e:
        print(">>> %s" % e)
    return {}

def load_geoinfo(isp_file, prvn_file, city_file):
    """ Load geoinfo to fulfill geoinfo code dict, which is used to encode geoinfo """
    global GEO_ISP_DICT, GEO_PRVN_DICT, GEO_CITY_DICT
    with open(isp_file, 'r') as f:
        for line in f.readlines():
            v, k, _ = line.split('|')
            GEO_ISP_DICT[k.strip()] = int(v.strip())

    with open(prvn_file, 'r') as f:
        for line in f.readlines():
            v, k, _ = line.split('|')
            GEO_PRVN_DICT[k.strip()] = int(v.strip())
    with open(city_file, 'r') as f:
        for line in f.readlines():
            v, _, k2, k1, _, _ = line.split('|')
            GEO_CITY_DICT["%s-%s" % (k1.strip(), k2.strip())] = int(v.strip())

def load_urlinfo(url_file, url_api=URL_API):
    """ Load url info to fulfill url code dict """
    global URL_DICT
    try:
        f = urllib.urlopen(url=url_api)
        if f.getcode()/100 != 2:
            if not URL_DICT:
                raise Exception("Invalid API")
        else:
            res = safe_load(f.read())
            for v, k in res.iteritems():
                URL_DICT[k.strip()] = int(v)
    except Exception, e:
        print("exception occur %s" % e)
        with open(url_file, 'r') as f:
            for line in f.readlines():
                v, k = line.split('|')
                URL_DICT[k.strip()] = int(v.strip())

def host_resolver(ip):
    isp, prvn, xprvn = xhost_resolver(str(ip))
    return "%s|%s" % (isp, xprvn)

def transform(jstr):
    """ Transform the original Kafka message to json string """
    jobj = safe_load(jstr)
    if 'pingback' not in jobj:
        return {}
    if isinstance(jobj['pingback'], dict):
        jpback = jobj['pingback']
    else:
        jpback = safe_load(jobj['pingback'])
    jpback['xzone'] = host_resolver(jobj['ip'])
    jpback['isp'] = encode_isp(jobj['isp'])
    jpback['prvn'] = encode_prvn(jobj['prvn'])
    jpback['city'] = encode_city(jobj['prvn'], jobj['city'])
    jpback['pbtype'] = int(jobj['pbtype'])
    return jpback

def parse(jpback):
    """ Parse each message """
    if not jpback:
        return [((0, 0, 0, 0, 0), RTuple[RState.OTHER] +(0, 0, 0))]
    pbtype = jpback['pbtype']
    isp = jpback['isp']
    prvn = jpback['prvn']
    city = jpback['city']
    if pbtype == 3:
        if 'apk_result' not in jpback:
            return [((3, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))]
        if 'data' not in jpback['apk_result']:
            return [((3, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))]
        data = jpback['apk_result']['data']
        xzone = jpback['xzone']
        return map(lambda item: get_apk_res(item, xzone, isp, prvn, city), data)
    elif pbtype == 2:
        if 'dns_result' not in jpback:
            return [((2, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))]
        if 'data' not in jpback['dns_result']:
            return [((2, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))]
        data = jpback['dns_result']['data']
        xzone = jpback['xzone']
        return map(lambda item: get_dns_res(item, xzone, isp, prvn, city), data)
    elif pbtype == 1:
        if 'detection_result' not in jpback:
            return [((1, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))]
        if 'data' not in jpback['detection_result']:
            return [((1, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))]
        data = jpback['detection_result']['data']
        return map(lambda item: get_detection_res(item, isp, prvn, city), data)
    else:
        return [((pbtype, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))]

def get_apk_res(item, xzone, isp, prvn, city):
    """ Parse for download detection """
    rtype = 3
    try:
        if isp == 69 or prvn > 31 and prvn != 250:
            isp = 69
            prvn = 0
            city = 0
        coded_url = encode_url(item['dloadUrl'])
        speed = 0
        if 'useTime' in item and int(item['useTime']) != 0:
            speed = float(1048576) / int(item['useTime'])
        return ((rtype, coded_url, isp, prvn, city), RTuple[RState.OTHER] + (int(math.ceil(speed)), int(math.ceil(speed)), int(math.ceil(speed))))
    except Exception, e:
        print(traceback.format_exc())
        return ((rtype, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))

def get_dns_res(item, xzone, isp, prvn, city):
    """ Parse for domain name detection """
    rtype = 2
    try:
        if isp == 69 or prvn > 31 and prvn != 250:
            r_isp = 69
            r_prvn = 0
            r_city = 0
        else:
            r_isp = isp
            r_prvn = prvn
            r_city = city

        coded_url = 0
        if 'url' in item:
            coded_url = encode_url(item['url'])
        if coded_url not in DOMAIN_IP_DICT:
            return ((rtype, 0, r_isp, r_prvn, r_city), RTuple[RState.OTHER] + (0, 0, 0))
        if item['ip'] == '0.0.0.0|':
            return ((rtype, coded_url, r_isp, r_prvn, r_city), RTuple[RState.NO_RETURN] + (0, 0, 0))
        dnslist = []
        if xzone in DOMAIN_IP_DICT[coded_url]:
            dnslist = DOMAIN_IP_DICT[coded_url][xzone]
        elif isp in DOMAIN_IP_DICT[coded_url]:
            dnslist = DOMAIN_IP_DICT[coded_url][isp]
        else:
            return ((rtype, coded_url, r_isp, r_prvn, r_city), RTuple[RState.OTHER] + (0, 0, 0))
        iplist = item['ip'].split('|')
        if set(iplist).issubset(dnslist):
            return ((rtype, coded_url, r_isp, r_prvn, r_city), RTuple[RState.CORRECT_RETURN] + (0, 0, 0))
        else:
            return ((rtype, coded_url, r_isp, r_prvn, r_city), RTuple[RState.ERROR_RETURN] + (0, 0, 0))
    except Exception, e:
        print(traceback.format_exc())
        return ((rtype, 0, r_isp, r_prvn, r_city), RTuple[RState.OTHER] + (0, 0, 0))

CODE_LIST = ['HTTPCODE_ZERO', 'HTTPCODE_OTHER', 'HTTPCODE_2XX', 'HTTPCODE_3XX', 'HTTPCODE_4XX', 'HTTPCODE_5XX']

def classify_code(code):
    return getattr(RState, CODE_LIST[int(code)/100] if int(code) < 600 else 'HTTPCODE_OTHER')

def get_detection_res(item, isp, prvn, city):
    """ Parse for interface detection """
    rtype = 1
    try:
        if isp == 69 or prvn > 31 and prvn != 250:
            isp = 69
            prvn = 0
            city = 0
        coded_url = 0
        if 'url' in item:
            coded_url = encode_url(item['url'])
        retcode = classify_code(item['httpStatus'])
        return ((rtype, coded_url, isp, prvn, city), RTuple[retcode] + (0, 0, 0))
    except Exception, e:
        print(traceback.format_exc())
        return ((rtype, 0, isp, prvn, city), RTuple[RState.OTHER] + (0, 0, 0))

def count(x, y):
    """ Count the '1' numbers by tuple """
    speed_min = 0
    if x[-3] > 0 and y[-3] > 0:
        speed_min = min(x[-3], y[-3])
    else:
        speed_min = x[-3] + y[-3]
    speed_max = 0
    if x[-2] > 0 and y[-2] > 0:
        speed_max = max(x[-2], y[-2])
    else:
        speed_max = x[-2] + y[-2]
    return tuple(map(lambda i, j: i + j, x[:-3], y[:-3])) + (speed_min, speed_max, x[-1] + y[-1])

DB_COLUMNS = [
    'id', 'time', 'pbtype', 'url', 'isp', 'prvn', 'city', 'total',
    'no_return', 'error_return', 'correct_return',
    'http_zero', 'http_2xx', 'http_3xx', 'http_4xx', 'http_5xx', 'http_other',
    'other', 'speed_min', 'speed_max', 'speed_avg'
]
Row_DB = Row(*DB_COLUMNS)

def convert(now, tup):
    """ Convert tuple to pyspark.sql.Row """
    row = [0, str(now)] + list(tup[0] + tup[1][:-1] + (int(math.ceil(tup[1][-1]/tup[1][0])),))
    return Row_DB(*row)

def getSqlContext(sparkContext):
    """ Singleton of sqlContext """
    if 'sqlContextSingleton' not in globals():
        globals()['sqlContextSingleton'] = SQLContext(sparkContext)
    return globals()['sqlContextSingleton']

def process(time, rdd):
    """ Process RDDs in each DStream

    First decode json string from Kafka message, then classify by the defined states,
    and count the amount of each state by key tuple (pbtype, url, isp, province, city),
    finally insert the result into mysql database via jdbc
    """
    print("========= %s %s==========" % (str(time), type(rdd)))
    js_entry = rdd.map(lambda x: transform(x[1]))
    oj_match = js_entry.flatMap(parse)
    cnt_tup = oj_match.reduceByKey(lambda x, y: count(x, y))
    cnt_rows = cnt_tup.map(lambda x: convert(time, x))
    try:
        sqlContext = getSqlContext(rdd.context)
        cnt_df = sqlContext.createDataFrame(cnt_rows)
        cnt_df.write.jdbc(
            url = "jdbc:mysql://10.153.3.74:3306/aem_stats?user=netdoctor&password=123456",
            table = "pingback_summary",
            mode = "append",
        )
    except Exception, e:
        print(traceback.format_exc())

def utf8_decoder(s):
    """ Decode function for Kafka DStream """
    if s is None:
        return ""
    try:
        return s.decode('utf-8')
    except UnicodeDecodeError, e:
        print('>>> %s ' % e)
    return s

SCHEDULE = sched.scheduler(time.time, time.sleep)

def sched_task(func, args, delay=3600, interval=3600):
    """ Schedule timer task """
    def do_task(func, args, interval):
        SCHEDULE.enter(interval, 0, do_task, (func, args, interval))
        if callable(func): func(*args)
    SCHEDULE.enter(delay, 0, do_task, (func, args, interval))
    SCHEDULE.run()

def fetch_dnsinfo(url):
    """ Fetch dnsinfo from fuxi api query """
    f = urllib.urlopen(url=url)
    content = safe_load(f.read())
    if 'code' in content and content['code'] == 1:
        return content['data']
    return {}

FUXI_API = "http://fuxi.qiyi.domain/?appkey=domainResolution&type=video&domain=%s&extends=1&recursion=1&account=netdoc&passwd=netdoc_dns"

def load_dnsinfo(dns_file, domains):
    """ Load dnsinfo from local csv file and fuxi api query """
    global DOMAIN_IP_DICT
    with open(dns_file, 'r') as f:
        for line in f.readlines():
            dn, code, isp, iplist = line.split(',')
            dn = encode_url(dn.strip())
            isp = encode_isp(isp.strip())
            if dn not in DOMAIN_IP_DICT:
                DOMAIN_IP_DICT[dn] = {}
            DOMAIN_IP_DICT[dn][isp] = iplist.strip().split('|')
    for dn in domains:
        fx_dn = dn
        if dn.startswith('http'): continue
        if dn.find('admaster.com.cn') != -1:
            fx_dn = 'vadmaster.iqiyi.com'
        if dn.find('miaozhen.com') != -1:
            fx_dn = 'miaozhen.iqiyi.com'
        res = fetch_dnsinfo(FUXI_API % fx_dn)
        if len(res) != 0:
            dn = encode_url(dn)
            DOMAIN_IP_DICT[dn] = res

if __name__ == "__main__":
    # Load geoinfo, url info and standard domain name resolution rules
    load_geoinfo('isp.csv', 'prvn.csv', 'city.csv')
    load_urlinfo('url.csv')
    load_dnsinfo('domain_ip.csv', URL_DICT.keys())
    s_thread = threading.Thread(target=sched_task, args=(load_dnsinfo, ('domain_ip.csv', URL_DICT.keys()), 1800, 3600))
    s_thread.start()

    sc = SparkContext()
    ssc = StreamingContext(sc, 3600) # 1hour for real-time analysis
    sqlContext = getSqlContext(sc)

    topics = {"aem_pingback": 5}
    zk_quorum = ",".join(zookeepers)
    kfk_stream = KafkaUtils.createStream(ssc, zk_quorum, "pback-group", topics, keyDecoder=utf8_decoder, valueDecoder=utf8_decoder)
    kfk_stream.foreachRDD(process)

    ssc.start()
    ssc.awaitTermination()
