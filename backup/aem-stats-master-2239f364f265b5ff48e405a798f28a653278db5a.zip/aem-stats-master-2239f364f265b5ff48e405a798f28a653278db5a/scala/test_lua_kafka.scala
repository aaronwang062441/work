package com.iqiyi.jupiter.scala_exam

import org.apache.spark.SparkContext._
import org.apache.spark.streaming.{Seconds,StreamingContext}
import org.apache.spark.streaming.kafka._
import org.apache.spark.{SparkConf,SparkContext }
import net.sf.json.JSONObject
import java.sql.{DriverManager, PreparedStatement, Connection}
import java.text.SimpleDateFormat
import java.util.Date

object Scala2Mysql {

	def save2Mysql(iter:Iterator[(String,Int)]):Unit = {
		var conn:Connection = null
		var pst:PreparedStatement = null
		val sql = "insert into test_stuckinfo_step_result(access_time,step,count)values(?,?,?)"
		
		try{
			conn = DriverManager.getConnection("jdbc:mysql://10.11.68.51:3306/test1","root","")
			iter.foreach(item => {
				var df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				pst = conn.prepareStatement(sql)
				pst.setString(1,df.format(new Date()))
				pst.setString(2,item._1)
				pst.setInt(3,item._2)
				pst.executeUpdate()
			})
		} catch {
			case e: Exception => println("conn exception")	
		} finally {
			if(pst != null)
				pst.close()
			if(conn != null)
				conn.close()
		}
	}

	def main(args : Array[String]) : Unit = {
		val sparkConf = new SparkConf()
	    val ssc = new StreamingContext(sparkConf, Seconds(20))

    	val topicMap = Map("test_lua_kafka"->2)
	    val zkQuorum = "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181,hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181,hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181"
    	val messages = KafkaUtils.createStream(ssc, zkQuorum, "stuck_info_group", topicMap)

	    val values = messages.flatMap(item => {
			val data = JSONObject.fromObject(item._2)
			Some(data)	
		})
	    val verCounts = values.filter(x =>{x.containsKey("version") && x.getString("version") == "1.2.1"}).map(x => (x.getString("version"),1)).reduceByKey(_ + _)
		//verCounts.foreachRDD(iter => iter.foreachPartition(save2Mysql))
    	verCounts.print()
		
		
		val stuckinfos = values.map(x => x.getString("stuckinfo")).flatMap(x => {
			val data = JSONObject.fromObject(x)
			Some(data)
		})
		val stepCounts = stuckinfos.filter(x => x.getString("step") == "3").map(x => (x.getString("step"),1)).reduceByKey(_ + _)	
		stepCounts.foreachRDD(iter => iter.foreachPartition(save2Mysql))
		stepCounts.print()
		

		/*	
		val stuckinfos = values.map(x => (x.getString("version"),x.getString("stuckinfo"))).flatMap(x => {
			val data = JSONObject.fromObject(x._2)
			val item = (x._1,(data.getString("step")))
			Some(item)
		})
		val stepCounts = stuckinfos.map(x => (x,1)).reduceByKey(_ + _)	
		stepCounts.print()
		*/
    	ssc.start()
	    ssc.awaitTermination()
  	}
}
