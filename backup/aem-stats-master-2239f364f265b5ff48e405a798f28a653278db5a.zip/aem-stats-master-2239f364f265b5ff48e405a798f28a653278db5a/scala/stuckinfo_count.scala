package com.iqiyi.jupiter.scala_exam

import org.apache.spark.SparkContext._
import org.apache.spark.streaming.{Seconds,StreamingContext}
import org.apache.spark.streaming.kafka._
import org.apache.spark.{SparkConf,SparkContext }
import net.sf.json.JSONObject
import java.sql.{DriverManager, PreparedStatement, Connection}
import java.text.SimpleDateFormat
import java.util.Date

object StuckinfoCount {

	def save2Mysql(iter:Iterator[((String,String),Int)]):Unit = {
		var conn:Connection = null
		var pst:PreparedStatement = null
		val sql = "insert into ndct_stuckinfo_302_result(access_time,type,status,count)values(?,?,?,?)"
		
		try{
			conn = DriverManager.getConnection("jdbc:mysql://10.11.68.51:3306/test1","root","")
			iter.foreach(item => {
				pst = conn.prepareStatement(sql)
				var df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				pst.setString(1,df.format(new Date()))
				pst.setString(2,item._1._1)
				pst.setString(3,item._1._2)
				pst.setInt(4,item._2)
				pst.executeUpdate()
			})
		} catch {
			case e: Exception => println("conn exception")	
		} finally {
			if(pst != null)
				pst.close()
			if(conn != null)
				conn.close()
		}
	}

	def main(args : Array[String]) : Unit = {
		val sparkConf = new SparkConf()
	    val ssc = new StreamingContext(sparkConf, Seconds(300))

    	val topicMap = Map("ndct_clientinfo"->3)
	    val zkQuorum = "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181,hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181,hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181"
    	val messages = KafkaUtils.createStream(ssc, zkQuorum, "stuck_info_group", topicMap)

	    val values = messages.flatMap(item => {
			val data = JSONObject.fromObject(item._2)
			val stuckinfo = JSONObject.fromObject(data.getString("stuckinfo"))
			val playresult = JSONObject.fromObject(stuckinfo.getString("play_result"))
			Some(playresult)	
		})
		
		val vrsSet = values.filter(_.containsKey("access_vrs")).flatMap(item => {
			val vrsData = JSONObject.fromObject(item.getString("access_vrs"))
			Some(vrsdata)
		})

		val vrs302Cnt = vrsSet.filter(_.getString("code") == "302").map(x => (("vrs",x.getString("code")),1)).reduceByKey(_+_)
		vrs302Cnt.foreachRDD(iter => iter.foreachPartition(save2Mysql))	
		vrs302Cnt.print()

		val pdataSet = values.filter(_.containsKey("access_pdata")).flatMap(item => {
			val pdata = JSONObject.fromObject(item.getString("access_pdata"))
			Some(pdata)
		})
		val pdata302Cnt = pdataSet.filter(_.getString("code") == "302").map(x => (("pdata",x.getString("code")),1)).reduceByKey(_+_)
		pdata302Cnt.foreachRDD(iter => iter.foreachPartition(save2Mysql))
		pdata302Cnt.print()
		
    	ssc.start()
	    ssc.awaitTermination()
  	}
}
