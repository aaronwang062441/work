/**
 * Copyright (C) 2015 iQIYI.COM - All Rights Reserved
 * This file is part of Jupiter. Unauthorized copy of this file, via any
 * medium is strictly prohibited. Proprietary and Confidential.
 *
 * Author(s): Cloud Spark <cloud-spark@dev.qiyi.com>
 */
package com.iqiyi.jupiter.scala_exam

import org.apache.spark.SparkContext._
import org.apache.spark.streaming.{Seconds,StreamingContext}
import org.apache.spark.streaming.kafka._
import org.apache.spark.{SparkConf,SparkContext }

object DirectKafkaWordCount {
  def main(args : Array[String]) : Unit = {
    val sparkConf = new SparkConf().setAppName("DirectKafkaWordCount")
    val ssc = new StreamingContext(sparkConf, Seconds(20))
    val topics = "test_lua_kafka"
    val numThreads = 2

    // Create direct kafka stream with brokers and topics
    val topicMap = topics.split(",").map((_, numThreads.toInt)).toMap
    val zkQuorum = "hcdn-others-kafka-online001-bjdx.qiyi.virtual:2181,hcdn-others-kafka-online002-bjdx.qiyi.virtual:2181,hcdn-others-kafka-online003-bjdx.qiyi.virtual:2181"
    val messages = KafkaUtils.createStream(ssc, zkQuorum, "DirectKafkaWordCount", topicMap)

    // Get the lines, split them into words, count the words and print
    val lines = messages.map(_._2)
    val words = lines.flatMap(_.split(" "))
    val wordCounts = words.map(x => (x, 1L)).reduceByKey(_ + _)
    wordCounts.print()

    // Start the computation
    ssc.start()
    ssc.awaitTermination()
  }
}
