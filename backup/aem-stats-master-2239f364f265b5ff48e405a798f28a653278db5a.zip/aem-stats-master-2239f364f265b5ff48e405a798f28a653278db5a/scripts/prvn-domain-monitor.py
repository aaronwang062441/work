#!/usr/bin/python
#-*- coding: utf-8 -*-


from __future__ import print_function
from collections import defaultdict
import sys
import time
import numpy
import redis
import Queue
import datetime
import threading
import torndb
import requests


ISP = {26:"CT", 77:"CNC", 147:"CMNET"}
PRVN = dict()
DOMAIN = dict()

RESULT = defaultdict(list) #{"BEIJING|CT":[domain1, domain2]}
ERROR_RESULT = defaultdict(float) #{"BEIJING|CT|DOMAIN": 10.7%}

THREAD_NUM = 100
SHARE_DOMAIN_QUEUE = Queue.Queue()

END = datetime.datetime.now()
START = datetime.datetime.now() - datetime.timedelta(hours=6)

RLOCK = threading.RLock()

alerts = (
    "no_return",
    "error_return",
)

watchers = (
    100,
    100,
)

conn_opts = {
    'host': '10.153.3.74',
    'user': 'netdoctor',
    'password': '123456',
    'database': 'aem_stats'
}

def fetch_from_sql(sql):
    res = list()
    try:
        db = torndb.Connection(host=conn_opts['host'], user=conn_opts['user'], password=conn_opts['password'], database=conn_opts['database'])
        res = db.query(sql)
    except Exception, e:
        print(e)
    return res

def update_domain():
    global DOMAIN
    import os
    path = os.path.join('/root/plot', 'domain.csv')
    with open(path) as fd:
        for domain in fd.readlines():
            sql = "select id, url from url_info where url = '%s'" % domain.strip()
            res = fetch_from_sql(sql)
            for item in res:
                DOMAIN[int(item['id'])] = item['url']
    print(DOMAIN)

def update_prvn():
    global PRVN
    sql = "select id, prvn from prvn_info where id >= 1 and id <= 31"
    res = fetch_from_sql(sql)
    for item in res:
        PRVN[int(item['id'])] = item['prvn']

def update_message_queue():
    global SHARE_DOMAIN_QUEUE
    global PRVN, ISP, DOMAIN

    for prvn in PRVN.keys():
        for isp in ISP.keys():
            for domain in DOMAIN.keys():
                item = (prvn, isp, domain)
                SHARE_DOMAIN_QUEUE.put(item)

def send_email(notification):
    if notification is None:
        return
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.image import MIMEImage
    to_list = ['pangxiaofei', 'chengui', 'wangminghui']
    cc_list = []
    bcc_list = []
    msg = MIMEMultipart('related')
    msg["From"] = "no-reply@aem-domain"
    msg["To"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, to_list))
    msg["CC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, cc_list))
    msg["BCC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, bcc_list))
    msg["Subject"] = u"分区域域名探测实时报警"
    html_text = u"<html><body style='font-family:Times New Roman'><h1>区域和域名信息如下:</h1>%s</body></html>" % notification
    msg_text = MIMEText(html_text, 'html', 'utf-8')
    msg.attach(msg_text)
    import subprocess
    p = subprocess.Popen(["/usr/sbin/sendmail", "-t"], stdin=subprocess.PIPE)
    p.communicate(msg.as_string())

def update_redis():
    global RESULT
    pool = redis.ConnectionPool(host='localhost', port=6379, db=0)
    r = redis.Redis(connection_pool=pool)
    r.flushall()
    if not RESULT:
        return
    pipe = r.pipeline()
    for key, value in RESULT.iteritems():
        pipe.set(key, "|".join(value))
    pipe.execute()

def generate_report():
    global RESULT
    global ERROR_RESULT
    html_text = u""
    url_text  = u""
    info_text = u"<br><br><p><a href='http://aem.qiyi.domain/dashboard/pingback/dns' target='_blank'>欢迎访问AEM Dashboard</a></p>"
    flag = False
    if RESULT:
        html_text += u"<table border='1' width='100%' style='font-family:Times New Roman'>"
        html_text += u"""
                     <tr><td>区域</td><td>域名列表</td><td>错误率</td></tr>
                     """

        form       = u"""
                     <tr><td>{region}</td><td>{domain_list}</td><td>{error_list}</td></tr>
                     """

        for region, domain in RESULT.iteritems():
            rate = []
            for d in domain:
                key = "%s|%s" % (region, d)
                rate.append("%.2f%%" % ERROR_RESULT[key])

            rate = "|".join(rate)
            domain = "|".join(domain)
            html_text += form.format(region=region, domain_list=domain, error_list=rate)
            flag = True
        html_text += "</table>"
        html_text += u"<p></p>"
        html_text += u"<p></p>"
        html_text += u"<p>当前报警的策略为：当监控域名的错误值比5小时前上升%d，并且这5小时的统计偏差达到一定程度时，则认为出现异常。</p>" % (watchers[0]/5)
        html_text += info_text

    if flag:
        return html_text
    else:
        return None


class Monitor(object):
    def __init__(self, prvn, isp, domain, start, end):
        self.domain = domain
        self.prvn = prvn
        self.isp = isp
        self.start = start.strftime("%Y-%m-%d %H:00:00")
        self.end = end.strftime("%Y-%m-%d %H:00:00")

    def monitor(self):
        raise NotImplementedError

    def fetch(self):
        raise NotImplementedError


class DomainMonitor(Monitor):
    def __init__(self, prvn, isp, domain, start, end):
        self.sample  = list()
        self.observ  = tuple()
        self.zscores = dict()
        self.alerts  = dict()
        self.prvn    = prvn
        self.isp     = isp
        self.domain  = domain
        self.start = start.strftime("%Y-%m-%d %H:00:00")
        self.end = end.strftime("%Y-%m-%d %H:00:00")

        self.sql = "select url, time, sum(no_return) as no_return, \
                    sum(error_return) as error_return, \
                    sum(no_return+error_return+correct_return) as total from pingback_summary \
                    where time >= '%s' and time< '%s' and url = %d  and isp = %d and prvn = %d GROUP BY time" % (self.start, self.end, self.domain, self.isp, self.prvn)

    def fetch(self):
        res = fetch_from_sql(self.sql)
        if len(res) <= 2:
            return False

        self.sample, self.observ = map(lambda x: (x['no_return'], x['error_return'], x['total']), res[0:-1]), (res[-1]['no_return'], res[-1]['error_return'], res[-1]['total'])
        return True

    def monitor(self):
        if not self.fetch():
            return {}
        for i in xrange(len(self.observ) - 1):#exclude total item
            col_observ = float(self.observ[i])
            col_sample = map(lambda x: float(x[i]), self.sample)
            col_preobserv = col_sample[-1]
            col_presample = col_sample[:-1]
            if len(col_sample) <= 1: continue
            if numpy.std(col_sample) <= 0: continue
            if numpy.std(col_presample) <= 0: continue
            zscore = (col_observ - numpy.mean(col_sample)) / numpy.std(col_sample)
            zscore_pre = (col_preobserv - numpy.mean(col_presample)) / numpy.std(col_presample)
            if col_observ < watchers[i]:
                continue
            if (float(col_observ * 100) / self.observ[-1]) < 10:
                continue
            if abs(col_observ - col_sample[0]) < watchers[i]/5:
                continue
            if zscore >= 9:
                self.zscores[i] = zscore
                self.alerts[i] = self.observ[i]
            elif abs(zscore + zscore_pre) >= 9 and zscore > 0:
                self.zscores[i] = zscore + zscore_pre
                self.alerts[i] = self.observ[i]
        if self.alerts:
            self.alerts['total'] = self.observ[-1]
        return self.alerts

class MonitorThread(threading.Thread):
    def __init__(self, func):
        super(MonitorThread, self).__init__()
        self.func = func

    def run(self):
        self.func()

def worker():
    global SHARE_DOMAIN_QUEUE, DOMAIN
    global RESULT, START, END
    global PRVN, ISP, RLOCK
    while not SHARE_DOMAIN_QUEUE.empty():
        item = SHARE_DOMAIN_QUEUE.get()
        prvn, isp, domain = item[0], item[1], item[2]
        start, end = START, END
        domain_object = DomainMonitor(prvn, isp, domain, start, end)
        res = domain_object.monitor()
        rate = 0
        if res:
            if res['total']:
                for k, v in res.iteritems():
                    if k != 'total':
                        rate += v
            rate = float(rate * 100) / float(res['total'])
            key = "%s|%s" % (PRVN[prvn], ISP[isp])
            error_key = "%s|%s|%s" % (PRVN[prvn], ISP[isp], DOMAIN[domain])
            RLOCK.acquire()
            RESULT[key].append(DOMAIN[domain])
            ERROR_RESULT[error_key] = rate
            RLOCK.release()
        SHARE_DOMAIN_QUEUE.task_done()

def main():
    global SHARE_DOMAIN_QUEUE
    thread_list = list()
    update_domain()
    update_prvn()
    update_message_queue()

    for i in xrange(THREAD_NUM):
        thread = MonitorThread(worker)
        thread.start()
        thread_list.append(thread)
    for thread in thread_list:
        thread.join()

    update_redis()
    res = generate_report()
    if res:
        send_email(res)
    print("Success")

if __name__ == "__main__":
    main()
