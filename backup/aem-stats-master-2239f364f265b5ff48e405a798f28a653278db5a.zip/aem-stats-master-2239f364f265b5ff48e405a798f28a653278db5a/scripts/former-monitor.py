#!/usr/bin/python
#-*- coding: utf-8 -*-


from __future__ import print_function
import sys
import time
import numpy
import Queue
import datetime
import threading
import torndb
import requests


SHOW_URL_DNS  = u'http://aem.qiyi.domain/dashboard/pingback/dns?sdt={start}&edt={end}&url={url}'
SHOW_URL_HTTP = u'http://aem.qiyi.domain/dashboard/pingback/http?sdt={start}&edt={end}&url={url}'
DOMAIN   = dict()
RESULT   = list()
THREAD_NUM = 20
SHARE_DOMAIN_QUEUE = Queue.Queue()

alerts = (
    "no_return",
    "error_return",
)

watchers = (
    3000,
    4000,
)

former_point_watchers = (
    500,
    500,
)

former_day_watchers = (
    100,
    100,
)

conn_opts = {
    'host': '10.153.3.74',
    'user': 'netdoctor',
    'password': '123456',
    'database': 'aem_stats'
}

def fetch_from_sql(sql):
    res = list()
    try:
        db = torndb.Connection(host=conn_opts['host'], user=conn_opts['user'], password=conn_opts['password'], database=conn_opts['database'])
        res = db.query(sql)
    except Exception, e:
        print(e)
    return res

def update_domain():
    global DOMAIN
    global SHARE_DOMAIN_QUEUE
    import os
    path = os.path.join('/root/plot', 'domain.csv')
    with open(path) as fd:
        for domain in fd.readlines():
            sql = "select id, url from url_info where url = '%s'" % domain.strip()
            res = fetch_from_sql(sql)
            for item in res:
                DOMAIN[int(item['id'])] = item['url']
                SHARE_DOMAIN_QUEUE.put(int(item['id']))

def send_email(notification):
    if notification is None:
        return
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.image import MIMEImage
    to_list = ['pangxiaofei', 'chengui', 'wangminghui']
    cc_list = []
    bcc_list = []
    msg = MIMEMultipart('related')
    msg["From"] = "no-reply@aem-domain"
    msg["To"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, to_list))
    msg["CC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, cc_list))
    msg["BCC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, bcc_list))
    msg["Subject"] = u"域名探测实时报警-前时刻版本"
    html_text = u"<html><body style='font-family:Times New Roman'><h1>异常域名详细信息</h1>%s</body></html>" % notification
    msg_text = MIMEText(html_text, 'html', 'utf-8')
    msg.attach(msg_text)
    import subprocess
    p = subprocess.Popen(["/usr/sbin/sendmail", "-t"], stdin=subprocess.PIPE)
    p.communicate(msg.as_string())

def generate_report():
    global RESULT
    html_text = u""
    url_text  = u""
    info_text = u"<br><br><p><a href='http://aem.qiyi.domain/dashboard/pingback/dns' target='_blank'>欢迎访问AEM Dashboard</a></p>"
    flag = False
    if len(RESULT):
        html_text += u"<table border='1' width='100%' style='font-family:Times New Roman'>"
        html_text += u"""
                     <tr><td>域名</td><td>监控总量</td><td>错误比例</td><td>DNS无返回比例</td><td>DNS劫持比例</td></tr>
                     """

        form       = u"""
                     <tr><td><a href="{url}" target="_blank">{domain}</a></td><td>{total}</td><td><font color="{et_color}">{et_percent}</font></td><td><font color="{no_color}">{no_return_percent}</font></td><td><font color="{error_color}">{error_return_percent}</font></td></tr>
                     """

        for item in RESULT:
            domain = (DOMAIN[item.keys()[0]])
            total = (item.values()[0]).get("total", 0)
            if not total:
                continue
            no_return_count = (item.values()[0]).get(0, 0)
            error_return_count = (item.values()[0]).get(1, 0)
            error_total = no_return_count + error_return_count
            if not error_total:
                continue

            et_percent = float(error_total * 100) / float(total)
            no_return_percent = float(no_return_count * 100) / float(total)#"%.2f%%" % (no_return_count * 100 / float(error_total))
            error_return_percent = float(error_return_count * 100) / float(total)#"%.2f%%" % (error_return_count * 100 / float(error_total))

            no_color      = "black"
            error_color   = "black"
            et_color      = "black"

            if et_percent > 90.0:
                et_color    = "red"
            elif et_percent <= 90.0 and et_percent > 80.0:
                et_color    = "blue"

            if no_return_percent > 90.0:
                no_color    = "red"
            elif no_return_percent <= 90.0 and no_return_percent > 80.0:
                no_color    = "blue"

            if error_return_percent > 90.0:
                error_color = "red"
            elif error_return_percent <= 90.0 and error_return_percent > 80.0:
                error_color = "blue"

            if not no_return_count:
                no_return_count = ""
                no_return_percent = ""

            if not error_return_count:
                error_return_count = ""

            et_percent = "%.2f%%" % et_percent if et_percent else ""
            error_return_percent = "%.2f%%" % error_return_percent if error_return_percent else ""
            no_return_percent = "%.2f%%" % no_return_percent if no_return_percent else ""

            if no_return_count or error_return_count:
                ref       = SHOW_URL_DNS.format(end=datetime.datetime.now().strftime("%Y%m%d%H"), start=(datetime.datetime.now()-datetime.timedelta(hours=6)).strftime("%Y%m%d%H"), url=item.keys()[0])


            html_text    += form.format(domain=domain, url=ref, total=total, et_percent=et_percent, et_color=et_color, no_return_percent=no_return_percent, error_return_percent=error_return_percent, \
                                        no_color=no_color, error_color=error_color)
            flag = True

        html_text += "</table>"
        html_text += info_text

    if flag:
        return html_text
    else:
        return None

class Monitor(object):
    def __init__(self, domain):
        self.domain = domain

    def monitor(self):
        raise NotImplementedError

    def fetch(self):
        raise NotImplementedError

    def former_monitor(self):
        raise NotImplementedError


class DomainMonitor(Monitor):
    def __init__(self, domain):
        self.sample  = list()
        self.observ  = tuple()
        self.zscores = dict()
        self.alerts  = dict()
        self.domain  = domain
        self.end     = datetime.datetime.now()
        self.formerp = self.end - datetime.timedelta(hours=1) #former point
        self.formerd = self.end - datetime.timedelta(days=1) #former day
        self.start   = self.end - datetime.timedelta(hours=6)

        self.sql = "select url, time, sum(no_return) as no_return, \
                    sum(error_return) as error_return, \
                    sum(no_return+error_return+correct_return) as total from pingback_summary \
                    where time >= '%s' and time< '%s' and url = %d GROUP BY time" % (self.start.strftime("%Y-%m-%d %H:00:00"), self.end.strftime("%Y-%m-%d %H:00:00"), self.domain)

    def fetch(self):
        res = fetch_from_sql(self.sql)
        if len(res) == 0:
            return

        self.sample, self.observ = map(lambda x: (x['no_return'], x['error_return'], x['total']), res[0:-1]), (res[-1]['no_return'], res[-1]['error_return'], res[-1]['total'])

    def monitor(self):
        self.fetch()
        for i in xrange(len(self.observ) - 1):#exclude total item
            col_observ = float(self.observ[i])
            col_sample = map(lambda x: float(x[i]), self.sample)
            col_preobserv = col_sample[-1]
            col_presample = col_sample[:-1]
            if len(col_sample) <= 1: continue
            if numpy.std(col_sample) <= 0: continue
            if numpy.std(col_presample) <= 0: continue
            zscore = (col_observ - numpy.mean(col_sample)) / numpy.std(col_sample)
            zscore_pre = (col_preobserv - numpy.mean(col_presample)) / numpy.std(col_presample)
            if col_observ < watchers[i]:
                continue
            if (float(col_observ * 100) / self.observ[-1]) < 10:
                continue
            if abs(col_observ - col_sample[0]) < watchers[i]/2:
                continue
            if zscore >= 9:
                self.zscores[i] = zscore
                self.alerts[i] = self.observ[i]
            elif abs(zscore + zscore_pre) >= 9 and zscore > 0:
                self.zscores[i] = zscore + zscore_pre
                self.alerts[i] = self.observ[i]
            if self.alerts:
                self.alerts['total'] = self.observ[-1]
        return self.alerts

    def former_monitor(self):
        sql = "select url, time, sum(no_return) as no_return, \
               sum(error_return) as error_return, \
               sum(no_return+error_return+correct_return) as total from pingback_summary \
               where (time = '%s' or time = '%s' or time = '%s') and url = %d GROUP BY time" % (self.formerd.strftime("%Y-%m-%d %H:00:00"), self.formerp.strftime("%Y-%m-%d %H:00:00"), self.end.strftime("%Y-%m-%d %H:00:00"), self.domain)

        res  = fetch_from_sql(sql)
        if len(res) < 3:
            return

        former_day, former_point, current = (res[0]['no_return'], res[0]['error_return'], res[0]['total']), (res[1]['no_return'], res[1]['error_return'], res[1]['total']), (res[2]['no_return'], res[2]['error_return'], res[2]['total'])
        alerts = {}
        if int(current[2]) == 0:
            return alerts
        for i in xrange(len(current) - 1):
            if ((current[i] - former_day[i]) > former_day_watchers[i]) and ((current[i] - former_point[i]) > former_point_watchers[i]) and ((float(current[i]) * 100)/current[2] > 20):
                alerts[i] = current[i]
        if alerts:
            alerts['total'] = current[2]
        return alerts


class MonitorThread(threading.Thread):
    def __init__(self, func):
        super(MonitorThread, self).__init__()
        self.func = func

    def run(self):
        self.func()

def worker():
    global SHARE_DOMAIN_QUEUE
    global RESULT
    while not SHARE_DOMAIN_QUEUE.empty():
        domain = SHARE_DOMAIN_QUEUE.get()
        domain_object = DomainMonitor(domain)
        res = domain_object.former_monitor()
        if res:
            RESULT.append({domain:res})
        SHARE_DOMAIN_QUEUE.task_done()

def main():
    global SHARE_DOMAIN_QUEUE
    thread_list = list()
    update_domain()
    for i in xrange(THREAD_NUM):
        thread = MonitorThread(worker)
        thread.start()
        thread_list.append(thread)
    for thread in thread_list:
        thread.join()

    if len(RESULT):
        res = generate_report()
        if res:
            send_email(res)
        print("All tasks done")
    else:
        print("Everything OK")


if __name__ == "__main__":
    main()
