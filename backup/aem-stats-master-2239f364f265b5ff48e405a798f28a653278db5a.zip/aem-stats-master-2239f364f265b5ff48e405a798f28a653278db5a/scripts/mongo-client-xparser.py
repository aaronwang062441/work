#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2016 iQIYI.com
# Author(s): WangMinghui <wangminghuiui@qiyi.com>
#
# This script is used to load the local mongo stuckinfo posted
# by NetDoctor client into mysql.

from __future__ import print_function
from __future__ import with_statement
import sys
import time
import json
from datetime import datetime, date, time, timedelta
import traceback
import os
import urllib
import Queue
import threading
from pymongo import MongoClient
import logging
import pdb

LOG_PATH = os.path.join(os.path.dirname(sys.path[0]), "log", "mongo_ndct_queue.log")

SHARE_QUEUE = Queue.Queue()
_WORKER_THREAD_NUM = 20     #设置线程个数

class WorkerThread(threading.Thread):
    """
    Class of thread woker
    """
    def __init__(self, func, db, col, logger):
        super(WorkerThread, self).__init__()
        self.func = func
        self.col = col
        self.db = db
        self.logger = logger
        print("thread created!")

    def run(self):
        self.func(self.db, self.col, self.logger)


class Logger(object):
    """
    Class of log
    """
    def __init__(self, file_name):
        logger = logging.getLogger("log")
        logger.setLevel(logging.DEBUG)
        fh = logging.FileHandler(file_name)
        fh.setLevel(logging.DEBUG)
        formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        self.__logger = logger

    def debug(self, text):
        self.__logger.debug(text)

    def warn(self, text):
        self.__logger.warning(text)

    def info(self, text):
        self.__logger.info(text)

    def error(self, text):
        self.__logger.error(text)


# Geoinfo Code for ISP, PROVINCE, CITY
GEO_ISP_DICT = dict()
GEO_PRVN_DICT = dict()
GEO_CITY_DICT = dict()

# VRS domain urls
VRS_DNS  = ['cache.video.qiyi.com', 'cache.video.ptqy.gitv.tv']

DNS_VRS_DICT = {
    'CT'   : ['101.227.32.30', '101.227.32.31', '106.38.219.21', '106.38.219.22', '106.38.219.36', '116.211.189.128', u'116.211.189.129'],
    'CNC'  : ['123.125.111.111', '123.125.111.100', '119.188.147.91', '119.188.147.90'],
    'CMNET': ['106.38.219.36', '106.38.219.21', '106.38.219.22', '123.125.111.111', '123.125.111.100', '112.13.64.2', '223.99.245.246', '223.99.245.245'],
    'OTHER': ['106.38.219.36', '106.38.219.21', '106.38.219.22', '101.227.32.39', '124.192.153.13', '123.125.111.111', '123.125.111.100', '115.182.125.142', '43.247.220.76', '124.250.53.164', '223.99.245.246', '38.83.107.86', '223.99.245.245']
}

DNS_VRS_LIST = [i for k,v in DNS_VRS_DICT.iteritems() for i in v]

DNS_DICT = {'VRS': DNS_VRS_DICT, 'PDATA': [], 'CACHE': []}

DNS_LIST = {'VRS': DNS_VRS_LIST, 'PDATA': [], 'CACHE': []}

DB_COLUMNS = [
    'id', 'time', 'isp', 'prvn', 'city', 'total', 'tmo_network', 'tmo_vrs', 'tmo_pdata', 'tmo_m3u8', 'tmo_vip',
    'vrs_code_zero', 'vrs_code_2xx', 'vrs_code_3xx', 'vrs_code_4xx', 'vrs_code_5xx', 'vrs_ip_absent', 'vrs_ip_present', 'vrs_ip_crossisp',
    'pdata_code_zero', 'pdata_code_2xx', 'pdata_code_3xx', 'pdata_code_4xx', 'pdata_code_5xx', 'pdata_ip_absent', 'pdata_ip_present', 'pdata_ip_crossisp',
    'cache_code_zero', 'cache_code_2xx', 'cache_code_3xx', 'cache_code_4xx', 'cache_code_5xx', 'cache_ip_absent', 'cache_ip_present', 'cache_ip_crossisp',
]

# Define Enum type
def enum(*seq, **named):
    enums = dict(zip(seq, range(len(seq))), len=len(seq), **named)
    return type('Enum', (), enums)

# Definition of Constants
Steps = enum(
    # Network timeout
    'ERROR_VIDTVID', 'NETWORK_START', 'NETWORK_FAILED', 'NETWORK_OK', # 0-3
    # VIP TIMEOUT for non-bighero
    'USER_PREPAREBEGIN', 'USER_PREPAREOK', 'USER_PREPAREFAILED',      # 4-6
    # VRS TIMEOUT
    'VRS_VIDBEGIN', 'VRS_VIDOK', 'VRS_VIDFAILD',                      # 7-9
    # VIP TIMEOUT
    'GET_KEYBEGIN', 'GET_KEYOK', 'GET_KEYFAILED',                     # 10-12
    # M3U8 TIMEOUT
    'GET_M3U8BEGIN', 'GET_M3U8OK', 'GET_M3U8FAILED',                  # 13-15
    # PDATA TIMEOUT
    'AUT_BEGIN', 'AUT_OK', 'AUT_FAILED',                              # 16-18
    # Impossible, Network timeout
    'DOWNLOAD_BEGIN', 'DWONLOAD_FAILED', 'DOWNLOAD_END', 'COMPLETE',  # 19-22
    # Impossible for 25, 26 present
    'VRS_URL_HIJACK', 'PDATA_URL_HIJACK', 'DOWNLOAD_URL_HIJACK', 'GET_M3U8_URL_HIJACK', # 23-26
)

TIMEOUT_STEPS = {
    'TMO_NETWORK': (Steps.ERROR_VIDTVID, Steps.NETWORK_START, Steps.NETWORK_FAILED, Steps.NETWORK_OK),
    'TMO_VRS'    : (Steps.VRS_VIDBEGIN, Steps.VRS_VIDOK, Steps.VRS_VIDFAILD),
    'TMO_PDATA'  : (Steps.AUT_BEGIN, Steps.AUT_OK, Steps.AUT_FAILED),
    'TMO_M3U8'   : (Steps.GET_M3U8BEGIN, Steps.GET_M3U8OK, Steps.GET_M3U8FAILED),
    'TMO_VIP'    : (Steps.GET_KEYBEGIN, Steps.GET_KEYOK, Steps.GET_KEYFAILED),
    'VIP_OLD'    : (Steps.USER_PREPAREBEGIN, Steps.USER_PREPAREOK, Steps.USER_PREPAREFAILED),
}

STEPS_TIMEOUT = dict([(i, k) for k,v in TIMEOUT_STEPS.iteritems() for i in v])

def enumtuple(*seq, **named):
    rotate = lambda l, n: l[-n:] + l[:-n]
    tuples = map(lambda i: tuple(rotate([1]+[0]*(len(seq)-1), i)), range(len(seq)))
    return type('EnumTuple', (), dict(zip(seq, tuples), len=len(seq), **named))

# TIMEOUT, CODE_ZERO, CODE_2XX, CODE_3XX, CODE_4XX, CODE_5XX, IP_ABSENT, IP_PRESNET, IP_CROSSISP
zerotuple = lambda x: tuple([0]*x)
ETUP_TMO = enumtuple('TMO_NETWORK', 'TMO_VRS', 'TMO_PDATA', 'TMO_M3U8', 'TMO_VIP')
ETUP_CODE = enumtuple('CODE_ZERO', 'CODE_2XX', 'CODE_3XX', 'CODE_4XX', 'CODE_5XX')
ETUP_IP = enumtuple('IP_ABSENT', 'IP_PRESENT', 'IP_CROSSISP')

def load_geoinfo(isp_file, prvn_file, city_file):
    """ Load geoinfo to fulfill geoinfo code dict, which is used to encode geoinfo """
    global GEO_ISP_DICT, GEO_PRVN_DICT, GEO_CITY_DICT
    with open(isp_file, 'r') as f:
        for line in f.readlines():
            v, k, _, = line.split('|')
            GEO_ISP_DICT[k] = int(v)
    with open(prvn_file, 'r') as f:
        for line in f.readlines():
            v, k, _ = line.split('|')
            GEO_PRVN_DICT[k] = int(v)
    with open(city_file, 'r') as f:
        for line in f.readlines():
            v, _, k2, k1, _, _ = line.split('|')
            GEO_CITY_DICT["%s-%s" % (k1, k2)] = int(v)

def safe_load(jstr):
    """ Wrapper of json.loads """
    try:
        return json.loads(jstr)
    except Exception, e:
        print(">>> %s" % e)
    return {}

FUXI_API = "http://fuxi.qiyi.domain/?appkey=domainResolution&type=video&domain=%s&extends=1&recursion=1&account=netdoc&passwd=netdoc_dns"

def fetch_dnsinfo(url):
    """ Fetch dnsinfo from FUXI API query """
    f = urllib.urlopen(url=url)
    content = safe_load(f.read())
    if 'code' in content and content['code'] == 1:
        return content['data']
    return {}

def update_dns_info():
    """ Update dns domain related infos """
    global DNS_VRS_LIST, DNS_VRS_DICT, DNS_LIST

    DNS_VRS_LIST = []
    for k in ['CT', 'CNC', 'CMNET', 'OTHER']:
        DNS_VRS_DICT[k] = []

    for domain in VRS_DNS:
        result = fetch_dnsinfo(FUXI_API % domain)

        for k in ['CT', 'CNC', 'CMNET']:
            DNS_VRS_DICT[k] += reduce(lambda x,y: x+y, [value for (key,value) in result.iteritems() if key.split('|')[0].upper()==k])

        DNS_VRS_DICT['OTHER'] += reduce(lambda x,y: x+y, [value for (key,value) in result.iteritems() if key.split('|')[0].upper() not in ['CT','CNC','CMNET']])

    for k in ['CT', 'CNC', 'CMNET', 'OTHER']:
        DNS_VRS_DICT[k] = list(set(DNS_VRS_DICT[k]))

    DNS_VRS_LIST = [i for k,v in DNS_VRS_DICT.iteritems() for i in v]
    DNS_VRS_LIST = list(set(DNS_VRS_LIST))
    DNS_LIST.update({"VRS": DNS_VRS_LIST})

def transform(jstr):
    """ Transform the original Kafka message to json string """
    if isinstance(jstr, basestring):
        jobj = safe_load(jstr)
    else:
        jobj = jstr
    if 'stuckinfo' not in jobj:
        return jobj
    if 'plat' not in jobj:
        jobj['plat'] = 99
    if isinstance(jobj['stuckinfo'], dict):
        jstuck = jobj['stuckinfo']
    else:
        jstuck = safe_load(jobj["stuckinfo"])
    jstuck['uid'] = jobj['uid']
    jstuck['ver'] = jobj['ver']
    jstuck['plat'] = int(jobj['plat'])
    jstuck['ip'] = jobj['ip']
    jstuck['zone'] = jobj['zone']
    jstuck['isp'] = jobj['isp']
    jstuck['prvn'] = 'prvn' in jobj and jobj['prvn'] or jobj['zone'].split('-')[0]
    jstuck['city'] = 'city' in jobj and jobj['city'] or jobj['zone'].split('-')[1]
    return jstuck

def classify_code(code):
    CODE_LIST = ['CODE_ZERO', 'CODE_ZERO', 'CODE_2XX', 'CODE_3XX', 'CODE_4XX', 'CODE_5XX']
    return getattr(ETUP_CODE, CODE_LIST[int(code)/100] if int(code) < 600 else 'CODE_ZERO')

def classify_ip(typ, svr_ip, clt_isp):
    ip_list = svr_ip.split("|")
    if not (set(ip_list) & set(DNS_LIST[typ])):
            return ETUP_IP.IP_ABSENT
    if clt_isp not in DNS_DICT[typ]:
        clt_isp = "OTHER"
    if svr_ip not in DNS_DICT[typ][clt_isp]:
        return ETUP_IP.IP_CROSSISP
    return ETUP_IP.IP_PRESENT

def parse_timeout(jobj):
    if 'timeout' not in jobj['play_result']:
        jobj['play_result']['timeout'] = 0
    if 'step' not in jobj['play_result']:
        jobj['play_result']['step'] = 0
    if int(jobj['play_result']['timeout']) == 0:
        return zerotuple(ETUP_TMO.len)
    step = int(jobj['play_result']['step'])
    if step < 0: return zerotuple(ETUP_TMO.len)
    if step >= Steps.DOWNLOAD_BEGIN:
        return ETUP_TMO.TMO_NETWORK
    if STEPS_TIMEOUT[step] == "VIP_OLD":
        if jobj['ver'].startswith('1.0.2.'):
            return ETUP_TMO.TMO_VIP
        else:
            return ETUP_TMO.NETWORK
    if STEPS_TIMEOUT[step] == "TMO_VIP":
        if jobj['ver'].startswith('1.0.2.'):
            return zerotuple(ETUP_TMO.len)
        else:
            return ETUP_TMO.TMO_VIP
    return getattr(ETUP_TMO, STEPS_TIMEOUT[step])

def parse_vrs(jobj):
    if 'access_vrs' not in jobj['play_result']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'url' not in jobj['play_result']['access_vrs'] or not jobj['play_result']['access_vrs']['url']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'code' not in jobj['play_result']['access_vrs'] or not str(jobj['play_result']['access_vrs']['code']).isdigit():
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'ip' not in jobj['play_result']['access_vrs'] or not jobj['play_result']['access_vrs']['ip']:
        jobj['play_result']['access_vrs']['ip'] = '0.0.0.0'
    ret_code = classify_code(jobj['play_result']['access_vrs']['code'])
    ret_ip = classify_ip('VRS', jobj['play_result']['access_vrs']['ip'], jobj['isp'])
    return ret_code + ret_ip

def parse_pdata(jobj):
    if 'access_pdata' not in jobj['play_result']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'url' not in jobj['play_result']['access_pdata'] or not jobj['play_result']['access_pdata']['url']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'code' not in jobj['play_result']['access_pdata'] or not str(jobj['play_result']['access_pdata']['code']).isdigit():
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    ret_code = classify_code(jobj['play_result']['access_pdata']['code'])
    ret_ip = zerotuple(ETUP_IP.len) #classify_ip('PDATA', jobj['play_result']['access_pdata']['ip'], jobj['isp'])
    return ret_code + ret_ip

def parse_cache(jobj):
    if 'cache_status' not in jobj['play_result']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'url' not in jobj['play_result']['cache_status'] or not jobj['play_result']['cache_status']['url']:
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)
    if 'code' not in jobj['play_result']['cache_status'] or not str(jobj['play_result']['cache_status']['code']).isdigit():
        return zerotuple(ETUP_CODE.len + ETUP_IP.len)

    if 'avg_speed' in jobj['play_result']['cache_status'] and int(jobj['play_result']['cache_status']['avg_speed']) > 0:
        ret_code = classify_code('200')
    elif str(jobj['play_result']['cache_status']['url']).find('.inter.iqiyi.com') != -1 \
            or str(jobj['play_result']['cache_status']['url']).find('.inter.qiyi.com') != -1:
        ret_code = classify_code('200')
    else:
        ret_code = classify_code(jobj['play_result']['cache_status']['code'])
    ret_ip = zerotuple(ETUP_IP.len) #classify_ip('CACHE', jobj['play_result']['cache_status']['ip'], jobj['isp'])
    return ret_code + ret_ip

def parse(jobj):
    """ Collect all dns info by parsing stuckinfo """
    if 'play_result' not in jobj:
        return (('None', 'None', 'None'), (1,)+zerotuple(ETUP_TMO.len+ETUP_CODE.len*3+ETUP_IP.len*3))
    if 'file_tpye' not in jobj['play_result']:
        jobj['play_result']['file_tpye'] = 'F4V'
    ret_tmo = parse_timeout(jobj)
    ret_vrs = parse_vrs(jobj)
    ret_pdata = parse_pdata(jobj)
    ret_cache = parse_cache(jobj)
    return ((jobj['isp'], jobj['prvn'], jobj['city']), (1,)+ret_tmo+ret_vrs+ret_pdata+ret_cache)

def count(x, y):
    """ Count the '1' numbers by tuple """
    return tuple(map(lambda i, j: i + j, x, y))

def encode_isp(isp): return isinstance(isp, int) and isp or GEO_ISP_DICT.get(isp, 0)
def encode_prvn(prvn): return isinstance(prvn, int) and prvn or GEO_PRVN_DICT.get(prvn, 0)
def encode_city(prvn, city): return isinstance(city, int) and city or GEO_CITY_DICT.get("%s-%s" %(prvn, city), 0)

def process(start, end, mysql, mongo, logger):
    """According to the given time, summary a result and insert into mysqldatabase"""
    try:
        result = dict()
        print(start, end, mysql, mongo, logger)
        articles = mongo.find({'actime':{"$gte":start, "$lt":end}})
        for item in articles:
            print(item)
            json_str = transform(item)


            parse_value = parse(json_str)

            key = (encode_isp(parse_value[0][0]), encode_prvn(parse_value[0][1]), encode_city(parse_value[0][1], parse_value[0][2]))
            value = parse_value[1]

            if result.has_key(key):
                result[key] = count(value, result[key])
            else:
                result[key] = value

        for key, value in result.iteritems():
            insert_sql = "insert into do_not_remove_testing (time, isp, prvn, city, total, \
                          tmo_network, tmo_vrs, tmo_pdata, tmo_m3u8, tmo_vip,\
                          vrs_code_zero, vrs_code_2xx, vrs_code_3xx, vrs_code_4xx, vrs_code_5xx, vrs_ip_absent, vrs_ip_present, vrs_ip_crossisp,\
                          pdata_code_zero, pdata_code_2xx, pdata_code_3xx, pdata_code_4xx, pdata_code_5xx, pdata_ip_absent, pdata_ip_present, pdata_ip_crossisp, \
                          cache_code_zero, cache_code_2xx, cache_code_3xx, cache_code_4xx, cache_code_5xx, cache_ip_absent, cache_ip_present, cache_ip_crossisp)\
                          values ('{0}', {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17}, {18}, {19}, {20}, {21}, {22},\
                          {23}, {24}, {25}, {26}, {27}, {28}, {29}, {30}, {31}, {32}, {33})"\
                          .format(end.strftime("%Y-%m-%d %H:%M:%S"), key[0], key[1], key[2],\
                                  value[0],\
                                  value[1], value[2], value[3], value[4], value[5], value[6], value[7], value[8], value[9], value[10], value[11], value[12],\
                                  value[13], value[14], value[15], value[16], value[17], value[18], value[19], value[20], value[21], value[22], value[23], value[24],\
                                  value[25], value[26], value[27], value[28], value[29])

            logger.info(insert_sql)
            mysql.execute(insert_sql)

    except Exception, e:
        print(">>> %s" % traceback.format_exc())

def utf8_decoder(s):
    """ Decode function for Kafka DStream """
    if s is None:
        return ""
    try:
        return s.decode('utf-8')
    except UnicodeDecodeError, e:
        print(">>> %s" % e)
    return s

def summary(db, col, logger):
    global SHARE_QUEUE
    while not SHARE_QUEUE.empty():
        start = SHARE_QUEUE.get()
        logger.info("get start: %s" % start)
        end = start + timedelta(minutes=5)
        process(start, end, db, col, logger)
        SHARE_QUEUE.task_done()

if __name__ == "__main__":
    logger = Logger(LOG_PATH)
    path = os.path.join(os.path.dirname(sys.path[0]), "spark")
    load_geoinfo(os.path.join(path, 'isp.csv'), os.path.join(path, 'prvn.csv'), os.path.join(path, 'city.csv'))

    update_dns_info()

    import torndb
    db = torndb.Connection(host="10.153.3.74:3306", user="root", password="%ndct", database="aem_stats")

    client = MongoClient("aem-2.qiyi.mongo")
    database = client.aem_ndctinfo
    col = database['aem_ndctinfo_20170626']
    start = datetime(2017, 06, 26, 00, 00, 00)
    print("Begin to process!")
    thread_list = list()

    for i in xrange(288):
        s = start + timedelta(minutes=5*i)
        SHARE_QUEUE.put(s)

    for i in xrange(_WORKER_THREAD_NUM):
        thread = WorkerThread(summary, db, col, logger)
        thread.start()
        thread_list.append(thread)
    for t in thread_list:
        t.join()

    db.close()


