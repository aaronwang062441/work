#!/usr/bin/env python
# encoding: utf-8

# Author: WangMinghui<wangminghui@qiyi.com>
# This script extract data from local file and update them into mongo/mysql/url.csv

from pymongo import MongoClient
import sys
import os
import torndb
import commands
from datetime import datetime

# Today
today = datetime.today().strftime("%Y%m%d")
# Add path for url.csv
sys.path.append(sys.path[0])
# Mongo client
client = MongoClient("aem-2.qiyi.mongo")
collection = client.aem_probe['probes']
# Mysql client
db = torndb.Connection("10.153.3.74:3306", "aem_stats", user="root", password="%ndct")
# Operate file in current file path
sys.path.append(os.path.dirname(sys.path[0]))

class Update(object):
    """ class update mongo/mysql/csv using data from local csv"""
    def __init__(self, file_name, mongo, mysql, today):
        """ init function """
        self.file_name = file_name
        self.mongo = mongo
        self.mysql = mysql
        self.url_list = list()
        self.today = today

    def get_local_info(self):
        """ collect url from local file """
        """ File content format should be 'type|url\n' """
        with open(self.file_name) as fi:
            for line in fi.readlines():
                typ, url = line.strip().split("|")[0], line.strip().split("|")[1]
                self.url_list.append((typ, url))

    def generate_insert(self, database_type, pingback_type, value):
        """ Formator factory """
        insert_string = None

        # process mongo
        if database_type == "mongo":
            if int(pingback_type) == 1:
                insert_string = {\
                                "type" : 1.0, "policy" : {},\
                                "period" : {}, "reqs" : 20.0, "gap" : 1.0, "dlurl" : "%s" % value,\
                                "cmd" : {"type" : 1.0, "detection" : "%s" % value}\
                                }
            elif int(pingback_type) == 2:
                insert_string = {\
                                "type" : 2.0,\
                                "policy" : {},\
                                "period" : {},\
                                "reqs" : 20.0,\
                                "gap" : 1.0,\
                                "dlurl" : "%s" % value,\
                                "cmd" : { "type" : 2.0, "dns" : "%s" % value}\
                                }
            elif int(pingback_type) == 3:
                status, res = commands.getstatusoutput("curl -r 0-1048575 -o 1.zip {url}".format(url=value))
                # status 0 meaning success
                if not status:
                    status, res = commands.getstatusoutput("md5sum 1.zip")
                    mdsum = res.split()[0]
                else:
                    return None

                insert_string = {\
                                "type" : 3.0,\
                                "policy" : {},\
                                "period" : {},\
                                "reqs" : 1.0,\
                                "gap" : 15.0,\
                                "dlurl" : "%s" % value,\
                                "cmd" : {\
                                        "type" : 3.0,\
                                        "dload" : "{url}|{md5}|0|1048575".format(url=value, md5=mdsum)\
                                        }\
                                }
            else:
                return None

        # process mysql
        elif database_type == "mysql":
            if int(pingback_type) in [1, 2, 3]:
                max_id = db.query("SELECT max(id) FROM url_info")[0]['max(id)']
                insert_string = "INSERT INTO `aem_stats`.`url_info` (`id`, `url`, `qyid`, `vendor`) \
                                VALUES (\'{id}\', \'{url}\', \'0\', \'{vendor}\');".format(id=max_id+1, url=value, vendor=max_id+1)
            else:
                return None

        # invalid database type
        else:
            return None

        return insert_string

    def valid_url(self):
        if isinstance(self.url_list, list):
            for item in self.url_list:
                typ, value = item[0], item[1]
                sql = self.generate_insert("mysql", typ, value)
                mo = self.generate_insert("mongo", typ, value)
                if mo and sql is None:
                    return False
            return True
        return False

    def update_mysql(self):
        """ Update mysql from self.url_list """
        if isinstance(self.url_list, list):
            for item in self.url_list:
                typ, value = item[0], item[1]
                sql = self.generate_insert("mysql", typ, value)
                if sql:
                    self.mysql.execute(sql)
                else:
                    print("invalid sql query %s" % value)

    def update_mongo(self):
        """ Update Mongo """
        if isinstance(self.url_list, list):
            for item in self.url_list:
                typ, value = item[0], item[1]
                mo = self.generate_insert("mongo", typ, value)
                if isinstance(mo, dict):
                    self.mongo.insert_one(mo)
                else:
                    print("invalid mongo query %s" % value)

    def update_csv_file(self):
        """ Update csv file """
        commands.getstatusoutput("rm -rf {today}".format(today=self.today))
        commands.getstatusoutput("mkdir {today}".format(today=self.today))
        with open("{today}/url.csv".format(today=self.today), "w+") as output:
            res = self.mysql.query("SELECT id, url FROM url_info")
            for item in res:
                output.write("{id}|{value}\n".format(id=item['id'], value=item['url']))

    def restart_gateways(self):
        """ Restart all AEM servers """
        status, res = commands.getstatusoutput("ansible -s -m command -a 'service aem restart'")
        if not status:
            print("Gateway Servers has been restarted")
        else:
            print("Gateway Servers restart failed")

    def update(self):
        self.get_local_info()
        if not self.valid_url():
            print("You have invalid url in your file!")
            return
        self.update_mysql()
        self.update_mongo()
        self.update_csv_file()
        print("Update successfully! Output file path: {curr}/{today}/url.csv".format(today=self.today, curr=sys.path[0]))
        self.restart_gateways()


# main process
if __name__ == "__main__":
    # Add your file to file_name, content format should be "type|url\n"
    obj = Update(file_name="urls_to_add.csv", mongo=collection, mysql=db, today=today)
    obj.update()
