
DROP DATABASE IF EXISTS `aem_stats`;
CREATE DATABASE `aem_stats`;

DROP TABLE IF EXISTS `ndctinfo_summary`;
CREATE TABLE `ndctinfo_summary` (
  `id`                int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plat`              int(11) unsigned DEFAULT NULL,
  `time`              datetime DEFAULT NULL,
  `total`             int(11) unsigned DEFAULT NULL,
  `err_ok`            int(11) unsigned DEFAULT NULL,
  `err_complete`      int(11) unsigned DEFAULT NULL,
  `err_download`      int(11) unsigned DEFAULT NULL,
  `err_f4v_timeout`   int(11) unsigned DEFAULT NULL,
  `err_vrs_access`    int(11) unsigned DEFAULT NULL,
  `err_pdata_access`  int(11) unsigned DEFAULT NULL,
  `err_m3u8_timeout`  int(11) unsigned DEFAULT NULL,
  `err_m3u8_access`   int(11) unsigned DEFAULT NULL,
  `err_vip_auth`      int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `hcdninfo_summary`;
CREATE TABLE `hcdninfo_summary` (
  `id`                int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plat`              int(11) unsigned DEFAULT NULL,
  `time`              datetime DEFAULT NULL,
  `total`             int(11) unsigned DEFAULT NULL,
  `err_ok`            int(11) unsigned DEFAULT NULL,
  `err_complete`      int(11) unsigned DEFAULT NULL,
  `err_download`      int(11) unsigned DEFAULT NULL,
  `err_pdata`         int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `pumainfo_summary`;
CREATE TABLE `pumainfo_summary` (
  `id`                int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plat`              int(11) unsigned DEFAULT NULL,
  `time`              datetime DEFAULT NULL,
  `total`             int(11) unsigned DEFAULT NULL,
  `err_ok`            int(11) unsigned DEFAULT NULL,
  `err_complete`      int(11) unsigned DEFAULT NULL,
  `err_download`      int(11) unsigned DEFAULT NULL,
  `err_pdata`         int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `dnsinfo_summay`;
CREATE TABLE `dnsinfo_summary` (
  `id`                int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time`              datetime DEFAULT NULL,
  `isp`               char(16)  DEFAULT NULL,
  `prvn`              char(16) DEFAULT NULL,
  `city`              char(16) DEFAULT NULL,
  `ldns`              text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `xndctinfo_summary`;
CREATE TABLE `xndctinfo_summary` (
  `id`                int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time`              datetime NOT NULL DEFAULT now(),
  `isp`               int(10) unsigned NOT NULL DEFAULT 0,
  `prvn`              int(10) unsigned NOT NULL DEFAULT 0,
  `city`              int(10) unsigned NOT NULL DEFAULT 0,
  `total`             int(10) unsigned NOT NULL DEFAULT 0,
  # timeout stats
  `tmo_network`       int(10) unsigned NOT NULL DEFAULT 0,
  `tmo_vrs`           int(10) unsigned NOT NULL DEFAULT 0,
  `tmo_pdata`         int(10) unsigned NOT NULL DEFAULT 0,
  `tmo_m3u8`          int(10) unsigned NOT NULL DEFAULT 0,
  `tmo_vip`           int(10) unsigned NOT NULL DEFAULT 0,
  # vrs stats
  `vrs_code_zero`     int(10) unsigned NOT NULL DEFAULT 0,
  `vrs_code_2xx`      int(10) unsigned NOT NULL DEFAULT 0,
  `vrs_code_3xx`      int(10) unsigned NOT NULL DEFAULT 0,
  `vrs_code_4xx`      int(10) unsigned NOT NULL DEFAULT 0,
  `vrs_code_5xx`      int(10) unsigned NOT NULL DEFAULT 0,
  `vrs_ip_absent`     int(10) unsigned NOT NULL DEFAULT 0,
  `vrs_ip_present`    int(10) unsigned NOT NULL DEFAULT 0,
  `vrs_ip_crossisp`   int(10) unsigned NOT NULL DEFAULT 0,
  # pdata stats
  `pdata_code_zero`   int(10) unsigned NOT NULL DEFAULT 0,
  `pdata_code_2xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `pdata_code_3xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `pdata_code_4xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `pdata_code_5xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `pdata_ip_absent`   int(10) unsigned NOT NULL DEFAULT 0,
  `pdata_ip_present`  int(10) unsigned NOT NULL DEFAULT 0,
  `pdata_ip_crossisp` int(10) unsigned NOT NULL DEFAULT 0,
  # cache stats
  `cache_code_zero`   int(10) unsigned NOT NULL DEFAULT 0,
  `cache_code_2xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `cache_code_3xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `cache_code_4xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `cache_code_5xx`    int(10) unsigned NOT NULL DEFAULT 0,
  `cache_ip_absent`   int(10) unsigned NOT NULL DEFAULT 0,
  `cache_ip_present`  int(10) unsigned NOT NULL DEFAULT 0,
  `cache_ip_crossisp` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  INDEX `geoinfo` (`isp`, `prvn`, `city`)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;
