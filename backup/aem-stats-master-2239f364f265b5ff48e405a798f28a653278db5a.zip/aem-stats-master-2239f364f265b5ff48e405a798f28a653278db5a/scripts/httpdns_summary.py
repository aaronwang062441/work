#!/usr/bin/env python
# encoding: utf-8

# Author(s): WangMinghui<wangminghui@qiyi.com>

# This file process data from mongo and summary http_dns condition

from pymongo import MongoClient
from datetime import datetime, date, time, timedelta
import urllib
import json
import sys
import re
import os
import sched
import threading
from collections import defaultdict
import pdb

sys.path.append(os.path.dirname(os.getcwd()))
# Add path for utils
from utils.common import Logger
# logger
logger = Logger(os.path.dirname(os.getcwd()) + "/log/httpdns.txt")
# Mongo
client = MongoClient("aem-2.qiyi.mongo")
database = client.aem_pingback
# Yesterday
today = (date.today() - timedelta(days=1)).strftime("%Y%m%d")
# Collection
col_name = "aem_pingback_" + today
collection = database[col_name]
# Domain
DOMAIN = (
    "v.admaster.com.cn",
    "viqiyi.admaster.com.cn",
    "iqiyi.m.cn.miaozhen.com",
    "g.cn.miaozhen.com",
    "www.iqiyi.com",
    "pdata.video.qiyi.com",
    "api.cupid.iqiyi.com",
    "msg.71.am",
    "tyaqy.m.cn.miaozhen.com",
    "sf.video.qiyi.com",
    "t7z.cupid.iqiyi.com",
    "ty.viqiyi.admaster.com.cn",
    "vtyqy.admaster.com.cn",
    "397c0.admaster.com.cn",
    "v2a.qbt.iqiyi.com",
    "msg2.video.qiyi.com",
    "msg2.video.ptqy.gitv.tv",
    "msga.71.am",
    "msga.ptqy.gitv.tv",
    "flux.hcdn.ptqy.gitv.tv",
    "flux.hcdn.ppstream.com",
    "flux.hcdn.qiyi.com",
    "http://msg.video.qiyi.com/vodpb.gif?t=check&rec=msglostrate",
    "msg2.cupid.iqiyi.com",
    "msga.cupid.iqiyi.com",
    "iface.iqiyi.com",
    "iface2.iqiyi.com",
)

# FUXI API
FUXI_API = "http://fuxi.qiyi.domain/?appkey=domainResolution&type=video&domain=%s&extends=1&recursion=1&account=netdoc&passwd=netdoc_dns"

# FUXI_DICT
FUXI_DICT = dict()

# Local DNS Result
LocalResult = dict()

# HTTP DNS Result
HTTPDNSResult = defaultdict(int)

# Safe load json string
def safe_load(json_str):
    try:
        return json.loads(json_str)
    except Exception, e:
        logger.debug("load json error: %s" % e)
        return {}

# Fetch info from fuxi, result is a list of all ip
def fetch_dnsinfo(url):
    if not url:
        return []
    f = urllib.urlopen(url=url)
    content = safe_load(f.read())
    result = list()
    if 'code' in content and content['code'] == 1:
        for key, val in content['data'].iteritems():
            result = result + val
        result = list(set(result))
        return result
    return []

def get_result_from_mongo(collection):
    if not collection:
        return
    return collection.find({"ver":re.compile("^1.0.10.*")}, {"_id": 0, "pingback": 1, "ip": 1})

def httpdns_summary(pingback):
    if not pingback:
        logger.info("pingback is null")
        return None

    local_dict = defaultdict(int)

    for item in pingback:
        try:
            user_ip = item['ip']
            data = item['pingback']['dns_result']['data']
            if data is None:
                continue
            for info in data:
                url = info.get("url", None)
                client = info.get("httpdnsClient", None) # HTTPDNSClientIP
                httpdns_ip = info.get("httpdnsIp", None)

                if user_ip != client:
                    logger.info("user ip and httpdns client ip not equal")
                    continue

                if url not in DOMAIN:
                    logger.info("invalid url")
                    continue

                fuxi_list = FUXI_DICT.get(url, None) or fetch_dnsinfo(FUXI_API % url)
                FUXI_DICT[url] = fuxi_list
                if httpdns_ip == "0.0.0.0|":
                    local_dict[httpdns_ip] += 1
                elif not httpdns_ip:
                    local_dict["None"] += 1
                elif set(httpdns_ip.split(";")).issubset(fuxi_list):
                    local_dict["Correct"] += 1
                else:
                    local_dict["Incorrect"] += 1
                    warn = "url is '{url}', httpdnsip is '{http}', fuxi_list is '{fuxi}'".format(url=url, http=httpdns_ip, fuxi=fuxi_list)
                    logger.info(warn)

        except Exception, e:
            logger.debug("exception e: %s" % e)
            continue

    return local_dict

def format_message(result):
    if result is None or not isinstance(result, dict):
        return

    htm_text = u'<p>统计结果</p>'
    htm_text += u'<table border="1" width="50%">'
    htm_text += u'<tbody><tr><td><em>类型</em></td><td><em>数量</em></td></tr>'
    for key, value in result.iteritems():
        fmt = u'<tr><td>{typ}</td><td>{score}</td></tr>'
        htm_text += fmt.format(typ=key, score=value)
    htm_text += u'</tbody></table>'
    return htm_text


def send_message(result):
    if result is None:
        return

    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.image import MIMEImage
    to_list = ['wangminghui']
    cc_list = []
    bcc_list = []
    msg = MIMEMultipart('related')
    msg["From"] = "daily-http-dns-summary@aem"
    msg["To"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, to_list))
    msg["CC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, cc_list))
    msg["BCC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, bcc_list))
    msg["Subject"] = u"HTTPDNS 1.0.10版本解析统计报表"
    html_text = u"<html><body>%s</body></html>" % result
    msg_text = MIMEText(html_text, 'html', 'utf-8')
    msg.attach(msg_text)
    import subprocess
    p = subprocess.Popen(["/usr/sbin/sendmail", "-t"], stdin=subprocess.PIPE)
    p.communicate(msg.as_string())


if __name__ == "__main__":
    logger.info("%s start" % col_name)
    result = get_result_from_mongo(collection)
    HTTPDNSResult = httpdns_summary(result)
    message = format_message(HTTPDNSResult)
    send_message(message)
