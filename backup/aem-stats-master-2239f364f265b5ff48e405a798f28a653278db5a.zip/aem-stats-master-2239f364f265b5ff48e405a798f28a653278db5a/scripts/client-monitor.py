#!/usr/bin/python
#-*- coding: utf-8 -*-
from __future__ import print_function
import sys
import time
import numpy
import datetime
import MySQLdb as mysql

MONITOR_FIFO = "/var/run/client-monitor.fifo"
KEYS_FIFO = "/var/run/error-keys.fifo"
tbl_columns = (
    'id',
    'isp',
    'time',
    'network_timeout',
    'vrs_error',
    'boss_error',
    'pdata_error',
    'cache_error',
)

watchers = (
    0,
    0,
    0,
    1000,
    4000,
    1000,
    6000,
    3000,
)

error_columns = {
    '3': ('tmo_network',),
    '4': ('tmo_vrs', 'vrs_code_zero', 'vrs_code_3xx', 'vrs_code_4xx', 'vrs_code_5xx', 'vrs_ip_absent', 'vrs_ip_crossisp'),
    '5': ('tmo_vip',),
    '6': ('tmo_pdata', 'pdata_code_zero', 'pdata_code_3xx', 'pdata_code_4xx', 'pdata_code_5xx', 'pdata_ip_absent', 'pdata_ip_crossisp'),
    '7': ('cache_code_zero', 'cache_code_3xx', 'cache_code_4xx', 'cache_code_5xx', 'cache_ip_absent', 'cache_ip_crossisp'),
}

error_description = {
    '3': (u'用户网络超时',),
    '4': (u'VRS超时', u'VRS服务器无响应', u'HTTP劫持', u'用户请求错误', u'服务器内部错误', u'DNS劫持', u'跨运营商访问'),
    '5': (u'鉴权超时',),
    '6': (u'调度超时', u'调度服务器无响应', u'HTTP劫持', u'用户请求错误', u'服务器内部错误', u'DNS劫持', u'跨运营商访问'),
    '7': (u'服务器无响应', u'HTTP劫持', u'用户请求错误', u'服务器内部错误', u'DNS劫持', u'跨运营商访问'),
}

error_name = {
    '3': 'Network',
    '4': 'VRS',
    '5': 'Boss',
    '6': 'Pdata',
    '7': 'Cache',
}

error_urls = {
    '3': '',
    '4': 'http://aem.qiyi.domain/dashboard/stuckzone/vrs?sdt=%s&edt=%s',
    '5': '',
    '6': 'http://aem.qiyi.domain/dashboard/stuckzone/pdata?sdt=%s&edt=%s',
    '7': 'http://aem.qiyi.domain/dashboard/stuckzone/cache?sdt=%s&edt=%s',
}

conn_opts = {
    'host': '10.153.3.74',
    'user': 'netdoctor',
    'password': '123456',
    'database': 'aem_stats'
}

def odbreq(sql):
    res = ()
    try:
        conn = mysql.connect(conn_opts['host'], conn_opts['user'], conn_opts['password'], conn_opts['database'])
        cur = conn.cursor()
        cur.execute(sql)
        res = cur.fetchall()
        cur.close()
        conn.close()
    except mysql.Error, e:
        print(e)
    return res

class Monitor(object):
    def __init__(self, sample, observ):
        self.sample = sample
        self.observ = observ

    def monitor(self):
        raise NotImplementedError

    def report(self):
        raise NotImplementedError

class UTestMonitor(Monitor):
    def __init__(self, sample, observ):
        pass
    def monitor(self):
        pass
    def report(self):
        pass

class RangeMonitor(Monitor):
    def __init__(self, sample, observ):
        pass
    def monitor(self):
        pass
    def report(self):
        pass

class ZScoreMonitor(Monitor):
    def __init__(self, sample, observ):
        self.sample = sample
        self.observ = observ
        self.zscores = {}
        self.alerts = {}

    def monitor(self):
        for i in xrange(3, len(tbl_columns)):
            col_observ = float(self.observ[i])
            col_sample = map(lambda x: float(x[i]), self.sample)
            col_preobserv = col_sample[-1]
            col_presample = col_sample[:-1]
            if len(col_sample) <= 1: continue
            if numpy.std(col_sample) <= 0: continue
            if numpy.std(col_presample) <= 0: continue
            zscore = (col_observ - numpy.mean(col_sample)) / numpy.std(col_sample)
            zscore_pre = (col_preobserv - numpy.mean(col_presample)) / numpy.std(col_presample)
            if col_observ < watchers[i]:
                continue
            if abs(col_observ - col_sample[0]) < watchers[i]/3:
                continue
            if zscore >= 8.4:
                self.zscores[i] = zscore
                self.alerts[i] = i
            elif abs(zscore + zscore_pre) >= 8.4 and zscore > 0:
                self.zscores[i] = zscore + zscore_pre
                self.alerts[i] = i
        return len(self.alerts) > 0

    def report(self):
        if len(self.alerts) == 0:
            return None
        htm_text = u''
        htm_text += u'<p>注意：当数据和之前一小时的统计偏差达到一定程度时，则认为是异常点；如偏差的趋势是向上的，则异常指数标为上升箭头。</p>'
        htm_text += u'<p><b>异常上升的卡顿类型</b></p>'
        htm_text += u'<table border="1" width="50%" style="font-family:Times New Roman">'
        htm_text += u'<tbody><tr><td><em>类型</em></td><td><em>异常指数</em></td><td><em>实际值</em></td><td><em>时间</em></td></tr>'
        normal_fmt = u'<tr><td>{type}</td><td>{zscore}</td><td>{observ}</td><td>{actime}</td></tr>'
        critical_fmt = u'<tr><td>{type}</td><td><font color="red">{zscore}</td><td>{observ}</td><td>{actime}</td></tr>'
        percent = lambda i: u'%.2f ' % (100*(1-self.zscores[i]**-2)) + (u'&#8679;' if self.alerts[i] > 0 else u'&#8681;')
        for k in self.alerts:
            if (100*(1-self.zscores[k]**-2)) >= 90:
                htm_text += critical_fmt.format(type=tbl_columns[k], zscore=percent(k), observ=self.observ[k], actime=self.observ[2])
            else:
                htm_text += normal_fmt.format(type=tbl_columns[k], zscore=percent(k), observ=self.observ[k], actime=self.observ[2])
        htm_text += u'</tbody></table>'
        return htm_text

class ThresholdMonitor(Monitor):
    def __init__(self, sample, observes):
        # ERR_COMPLETE, ERR_DOWNLOAD, ERR_F4V_TIMEOUT, ERR_VRS_ACCESS, ERR_PDATA_ACCESS, ERR_M3U8_TIMEOUT, ERR_M3U8_ACCESS, ERR_VIP_AUTH
        self.threshold = (1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000)
        # self.threshold = (1000, 1000, 8000, 6000, 1000, 1000, 1000, 5000)
        self.actime = observes[2]
        self.observes = observes[5:]
        self.alerts = []

    def monitor(self):
        for i in range(len(self.threshold)):
            if self.observes[i] > self.threshold[i]:
                self.alerts.append(i)
        return len(self.alerts) > 0

    def report(self):
        if len(self.alerts) == 0:
            return None
        htm_text = u'<h2>阈值监控（Threshold Monitor）</h2>'
        htm_text += u'<p>超过阈值设定的卡顿错误</p>'
        htm_text += u'<table border="1" width="50%">'
        htm_text += u'<tbody><tr><td><em>类型</em></td><td><em>阈值</em></td><td><em>实际值</em></td><td><em>时间</em></td></tr>'
        fmt = u'<tr><td>{type}</td><td>{threshold}</td><td>{observe}</td><td>{actime}</td></tr>'
        htm_text += ''.join(map(lambda i: fmt.format(type=tbl_columns[i+5], threshold=self.threshold[i], observe=self.observes[i], actime=self.actime), self.alerts))
        htm_text += '</tbody></table>'
        return htm_text

class DetailsMonitor(Monitor):
    def __init__(self, value, columns, name, description):
        self.columns = columns
        self.description = description
        self.name = name
        self.score = {}
        self.observ = value

    def monitor(self):
        if not self.observ:
            return
        for i in xrange(len(self.columns)):
            self.score[i] = 100*self.observ[i]/self.observ[-1]

    def report(self):
        if not self.score:
            return None
        htm_text = u'<p style="font-family:Times New Roman"><b>{name}异常详细信息</b></p>'.format(name=self.name)
        htm_text += u'<table border="1" width="50%" style="font-family:Times New Roman">'
        htm_text += u'<tbody><tr><td><em>类型</em></td><td><em>占比</em></td><td><em>实际值</em></td><td><em>错误描述</em></td></tr>'
        fmt = u'<tr><td>{type}</td><td>{score}</td><td>{observ}</td><td>{description}</td></tr>'
        for i in xrange(len(self.columns)):
            if self.score[i] >= 10:
                htm_text += fmt.format(type=self.columns[i], score=('%.2f%%' % self.score[i]), observ=self.observ[i], description=self.description[i])
        htm_text += u'</tbody></table>'
        return htm_text

def attach_urls(keys, start, end):
    if set(keys).issubset([3, 5]):
        return ''
    htm_text = u'<p style="font-family:Times New Roman">详细信息请访问Dashboard</p>'
    fmt = u'<p style="font-family:Times New Roman">{type}: {url} </p>'
    for i in keys:
        if i in [3, 5]:
            continue
        htm_text += fmt.format(type=error_name[str(i)], url=(error_urls[str(i)] % (start, end)))
    return htm_text

def notify(notification):
    if notification is None:
        return
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.image import MIMEImage
    to_list = ['tuohu', 'pangxiaofei', 'chengui', 'pengyajie', 'qinjianhua', 'qiaojun', 'zhaoshuli', 'zhuyabing']
    cc_list = ['tp_support', 'jk']
    bcc_list = ['yueli']
    msg = MIMEMultipart('related')
    msg["From"] = "no-reply@aem"
    msg["To"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, to_list))
    msg["CC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, cc_list))
    msg["BCC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, bcc_list))
    msg["Subject"] = u"AEM实时分析报警 - 内部测试"
    html_text = u"<html><body><h1>AEM实时分析报警</h1>%s</body></html>" % notification
    msg_text = MIMEText(html_text, 'html', 'utf-8')
    msg.attach(msg_text)
    import subprocess
    p = subprocess.Popen(["/usr/sbin/sendmail", "-t"], stdin=subprocess.PIPE)
    p.communicate(msg.as_string())

def notify2(notification):
    if not notification:
        return
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.image import MIMEImage
    to_list = ['tuohu', 'pangxiaofei', 'chengui', 'pengyajie', 'qinjianhua', 'qiaojun', 'zhaoshuli', 'zhuyabing']
    cc_list = ['tp_support', 'jk']
    bcc_list = ['yueli']
    msg = MIMEMultipart('related')
    msg["From"] = "aem_alert <hcdn-autosentder@qiyi.com>"
    msg["To"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, to_list))
    msg["CC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, cc_list))
    msg["BCC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, bcc_list))
    msg["Subject"] = u"[AEM报警] 播放故障实时报警"
    html_text = u"<html><body><h1>AEM实时分析报警</h1>%s</body></html>" % notification
    msg_text = MIMEText(html_text, 'html', 'utf-8')
    msg.attach(msg_text)

    import smtplib
    fro = "HCDN-AutoSender@qiyi.com"
    to = map(lambda name: "%s@qiyi.com" % name, to_list)
    smtp = smtplib.SMTP('10.121.86.154')
    smtp.login('HCDN-AutoSender', 'at&HGWJP97')
    smtp.sendmail(fro, to, msg.as_string())
    smtp.close()

    
def notify3(notification):
    if notification is None:
        return
    import requests
    import json

    to_list = ['tuohu', 'pangxiaofei', 'chengui', 'pengyajie', 'qinjianhua', 'qiaojun', 'zhaoshuli', 'zhuyabing']
    cc_list = ['tp_support', 'jk']
    data = {
        'topic_id': 1157,
        'secret_key': "c59eaa48-66eb-4179-aca2-46921a7b6b51",
        'data': json.dumps({'content': notification, 'email_subject': u'[AEM报警] 播放故障报警'}),
        'users': ','.join(to_list),
        'email_enabled': 1,
    }
    return requests.post('http://alert.qiyi.domain/event/create/', data=data)

if __name__ == "__main__":
    lasttick = 0
    try:
        with open(MONITOR_FIFO, "r") as fp:
            lasttick = int(fp.read())
    except:
        lasttick = 0
    sql = "SELECT max(time) from xndctinfo_summary"
    res = odbreq(sql)
    updatetick = int(time.mktime(res[0][0].timetuple()))
    if updatetick <= lasttick:
        print('no update!!!')
        sys.exit(1)


    with open(MONITOR_FIFO, "w") as fp:
        fp.write("%d" % updatetick)

    now = datetime.datetime.now()
    # now = datetime.datetime.strptime('2017-08-17 15:56:00', '%Y-%m-%d %H:%M:%S')
    halfhour = now - datetime.timedelta(minutes=30)
    sql = "select count(id), count(isp), time, sum(tmo_network) as network_timeout \
            , sum(tmo_vrs) + sum(vrs_code_zero) + sum(vrs_code_3xx) + sum(vrs_code_4xx) + sum(vrs_code_5xx) + sum(vrs_ip_absent) + sum(vrs_ip_crossisp) as vrs_error \
            , sum(tmo_vip) as boss_error \
            , sum(tmo_pdata) + sum(pdata_code_zero) +  sum(pdata_code_3xx) + sum(pdata_code_4xx) + sum(pdata_code_5xx) + sum(pdata_ip_absent) + sum(pdata_ip_crossisp) as pdata_error \
            , sum(cache_code_zero) + sum(cache_code_3xx) + sum(cache_code_4xx) + sum(cache_code_5xx) + sum(cache_ip_absent) + sum(cache_ip_crossisp) as cache_error \
            , sum(tmo_vrs), sum(vrs_code_zero), sum(vrs_code_3xx), sum(vrs_code_4xx), sum(vrs_code_5xx), sum(vrs_ip_absent), sum(vrs_ip_crossisp) \
            , sum(tmo_pdata), sum(pdata_code_zero),  sum(pdata_code_3xx), sum(pdata_code_4xx), sum(pdata_code_5xx), sum(pdata_ip_absent), sum(pdata_ip_crossisp) \
            , sum(cache_code_zero), sum(cache_code_3xx), sum(cache_code_4xx), sum(cache_code_5xx), sum(cache_ip_absent), sum(cache_ip_crossisp) \
            from xndctinfo_summary where time>='%s' and time<'%s' group by time" % (halfhour, now)
    res = odbreq(sql)
    if len(res) == 0:
        sys.exit(1)
    sample, observ = map(lambda x: x[0:8], res[:-1]), res[-1][0:8]
    error_observ = dict()
    error_observ['3'] = [res[-1][3], res[-1][3]]
    error_observ['4'] = list(res[-1][8:15]) + [res[-1][4],]
    error_observ['5'] = [res[-1][5], res[-1][5]]
    error_observ['6'] = list(res[-1][15:22]) + [res[-1][6],]
    error_observ['7'] = list(res[-1][22:]) + [res[-1][7],]

    if now - observ[2] > datetime.timedelta(minutes=10):
        sys.exit(1)

    monitors = map(lambda m: m(sample, observ), [ZScoreMonitor,])
    map(lambda m: m.monitor(), monitors)
    reports = filter(lambda x: x is not None, map(lambda m: m.report(), monitors))
    total = ("" if not reports else reports[0])

    keys, lasttick = [], 0
    try:
        with open(KEYS_FIFO, "r") as fp:
            line = fp.readline().strip().split(",")
            keys, lasttick = line[:-1], int(line[-1])
    except:
        keys, lasttick = [], 0

    currenttick = int(time.mktime(observ[2].timetuple()))

    error_keys = reduce(lambda m, n: m + n, map(lambda m: m.alerts.keys(), monitors))
    if not error_keys:
        sys.exit(1)

    if (currenttick - lasttick <= 1800) and (set(map(lambda x: str(x), error_keys)) == set(keys)):
        sys.exit(1)

    with open(KEYS_FIFO, "w") as fp:
        fp.write("%s" % (",".join(map(lambda x: str(x), error_keys)) + "," + str(currenttick)))

    for item in error_keys:
        col = error_columns[str(item)]
        description = error_description[str(item)]
        name = error_name[str(item)]
        monitor = DetailsMonitor(error_observ[str(item)], col, name, description)
        monitor.monitor()
        report = monitor.report()
        total += (report if report else '')

    total += attach_urls(error_keys, halfhour.strftime("%Y%m%d%H%M%S"), observ[2].strftime("%Y%m%d%H%M%S"))
    if len(total) != 0:
        #print(''.join(reports))
        notify2(total)
