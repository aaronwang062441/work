#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import datetime
import MySQLdb as mysql
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import matplotlib.dates as dates

html_template = u"""
<html>
<body>
<h1>AEM数据统计报表 {today}</h1>
<p>本报表为AEM系统实时分析模块针对客户端APP投递上来的卡顿数据进行统计的统计报表。</p>
<p>说明：由于HCDN和PUMA格式不同，目前报表只展示了NetDoctor-SDK的分析数据。目前ND-SDK的数据只包含PC、TV和Game平台。</p>
<p>关于本报表中出现的错误类型说明如下：</p>
<table border="1">
<tbody>
<tr><td> <em>类型</em>    </td><td> <em>备注</em>                 </td></tr>
<tr><td> total            </td><td> 投递数据的总量                </td></tr>
<tr><td> correct          </td><td> 访问正常的比例                </td></tr>
<tr><td> network_timeout  </td><td> 用户网络超时的比例            </td></tr>
<tr><td> vrs_error        </td><td> VRS错误比例                   </td></tr>
<tr><td> boss_error       </td><td> 鉴权错误的比例                </td></tr>
<tr><td> pdata_error      </td><td> 调度错误的比例                </td></tr>
<tr><td> cache_error      </td><td> Cache错误的比例               </td></tr>
</tbody>
</table>

<h2>各类卡顿错误统计趋势</h2>
<p>当天卡顿错误数量趋势图和比例趋势图（{today}）</p>
<p><img alt="卡顿错误统计趋势" src="cid:image2" /></p>

<h2>各类卡顿错误分布情况</h2>
<ol>
<li>当天总卡顿错误比例分布图及趋势图（{today}）</li>
<p><img alt="卡顿错误比例分布" src="cid:image1" /></p>
<li>当天总卡顿错误数量统计表（{today}）</li>
<table border="1" width="50%">
<tbody>
<tr><td><em>类型</em></td><td><em>数量</em></td><td><em>比例</em></td></tr>
{tbl_data}
</tbody>
</table>
</ol>



<p> 本邮件由Python脚本自动生成，请勿回复。如有任何问题，请联系陈归(chengui@qiyi.com)。</p>
</body>
</html>
"""

tbl_columns = (
    'id',
    'isp',
    'time',
    'total',
    'correct',
    'network_timeout',
    'vrs_error',
    'boss_error',
    'pdata_error',
    'cache_error',
)

conn_opts = {
    'host': '10.153.3.74',
    'user': 'netdoctor',
    'password': '123456',
    'database': 'aem_stats'
}

workdir = '/root/plot'

def odbreq(sql):
    res = ()
    try:
        conn = mysql.connect(conn_opts['host'], conn_opts['user'], conn_opts['password'], conn_opts['database'])
        cur = conn.cursor()
        cur.execute(sql)
        res = cur.fetchall()
        cur.close()
        conn.close()
    except mysql.Error, e:
        print e
    return res

def plot_and_email():
    today = datetime.datetime.now()
    today = today.strftime('%Y-%m-%d')

    now = datetime.datetime.now()
    oneday = now - datetime.timedelta(days=1)
    oneday = oneday.strftime('%Y-%m-%d %H:%M:%S')
    sql = "SELECT count(id), count(isp), time \
           , sum(tmo_network) + sum(tmo_vrs) + sum(vrs_code_zero) + sum(vrs_code_3xx) + sum(vrs_code_4xx) + sum(vrs_code_5xx) + sum(vrs_ip_absent) + sum(vrs_ip_crossisp) \
             + sum(tmo_vip) + sum(tmo_pdata) + sum(pdata_code_zero) +  sum(pdata_code_3xx) + sum(pdata_code_4xx) + sum(pdata_code_5xx) + sum(pdata_ip_absent) + sum(pdata_ip_crossisp) \
             + sum(cache_code_zero) + sum(cache_code_3xx) + sum(cache_code_4xx) + sum(cache_code_5xx) + sum(cache_ip_absent) + sum(cache_ip_crossisp) \
             + sum(vrs_code_2xx) + sum(vrs_ip_present) + sum(pdata_code_2xx) + sum(pdata_ip_present) + sum(cache_code_2xx) + sum(cache_ip_present) as total \
           , sum(vrs_code_2xx) + sum(vrs_ip_present) + sum(pdata_code_2xx) + sum(pdata_ip_present) + sum(cache_code_2xx) + sum(cache_ip_present) as correct \
           , sum(tmo_network) as network_timeout \
           , sum(tmo_vrs) + sum(vrs_code_zero) + sum(vrs_code_3xx) + sum(vrs_code_4xx) + sum(vrs_code_5xx) + sum(vrs_ip_absent) + sum(vrs_ip_crossisp) as vrs_error \
           , sum(tmo_vip) as boss_error \
           , sum(tmo_pdata) + sum(pdata_code_zero) +  sum(pdata_code_3xx) + sum(pdata_code_4xx) + sum(pdata_code_5xx) + sum(pdata_ip_absent) + sum(pdata_ip_crossisp) as pdata_error \
           , sum(cache_code_zero) + sum(cache_code_3xx) + sum(cache_code_4xx) + sum(cache_code_5xx) + sum(cache_ip_absent) + sum(cache_ip_crossisp) as cache_error \
           FROM xndctinfo_summary WHERE time>'%s' group by time" % oneday
    res = odbreq(sql)
    if not res:
        return

    sum_all = map(lambda i: reduce(lambda x, y: x + y, map(lambda c: int(c[i]), res)), range(3, len(tbl_columns)))
    sum_error = reduce(lambda x, y: x + y, sum_all[2:])

    # set up datetime formatter and locator
    x_datetime = map(lambda x: x[2], res)
    fmt_xdtime = dates.DateFormatter('%H:%M\n%m-%d')
    loc_major = dates.HourLocator(interval=2)
    loc_minor = dates.HourLocator(interval=1)

    # generate pie figure
    pct_err = map(lambda i: 100*sum_all[i]/float(sum_error), range(2, len(sum_all)))
    y_percent = map(lambda x: 100*float(x[3]-x[4])/int(x[3]), res)
    fig_sum = plt.figure(figsize=(20, 10), dpi=50)
    ax_dat = fig_sum.add_subplot(121)
    ax_dat.plot(x_datetime, y_percent, label='Error Ratio')
    ax_dat.xaxis.set_major_formatter(fmt_xdtime)
    ax_dat.xaxis.set_major_locator(loc_major)
    ax_dat.xaxis.set_minor_locator(loc_minor)
    plt.yticks(range(0, 80, 20))
    plt.ylabel('Ratio of Stuck Error (%)')
    plt.title("Stuck-Errors Flow In One Day")
    ax_pie = fig_sum.add_subplot(122)
    ax_pie.pie(pct_err, labels=tbl_columns[5:], autopct='%1.1f%%')
    plt.title("Stuck-Errors Statistics In One Day")
    plt.savefig(os.path.join(workdir, '{today}-pie.png'.format(today=today)))

    # generate count flow figure
    fig_cnt = plt.figure(figsize=(20, 10), dpi=50)
    ax_cnt = fig_cnt.add_subplot(121)
    map(lambda i: ax_cnt.plot(x_datetime, map(lambda x: x[i], res), label=tbl_columns[i]), range(5, len(tbl_columns)))
    ax_cnt.xaxis.set_major_formatter(fmt_xdtime)
    ax_cnt.xaxis.set_major_locator(loc_major)
    ax_cnt.xaxis.set_minor_locator(loc_minor)
    plt.legend(loc="upper left")
    plt.yticks([-500, 0] + range(2500, 10000, 2500))
    plt.ylabel('Number of Stuck Error')
    plt.title("Each Stuck-Error Type Flow In One Day")
    ax_rat = fig_cnt.add_subplot(122)
    map(lambda i: ax_rat.plot(x_datetime, map(lambda x: 100*int(x[i])/float(x[3]), res), label=tbl_columns[i]), range(5, len(tbl_columns)))
    ax_rat.xaxis.set_major_formatter(fmt_xdtime)
    ax_rat.xaxis.set_major_locator(loc_major)
    ax_rat.xaxis.set_minor_locator(loc_minor)
    plt.legend(loc="upper left")
    plt.yticks([-1, 0] + range(5, 20, 5))
    plt.ylabel('Ratio of Stuck Error (%)')
    plt.title("Each Stuck-Error Type Flow In One Day")
    plt.savefig(os.path.join(workdir, '{today}-count.png'.format(today=today)))

    # generate summary table
    fmt_table = '<tr><td>{type:^18}</td><td>{count:^10}</td><td>{ratio:^8.2%}</td></tr>\n'
    lst_table = map(lambda i: fmt_table.format(type=tbl_columns[i+3], count=sum_all[i], ratio=sum_all[i]/float(sum_all[0])), range(0, len(sum_all)))
    html_table = "".join(lst_table)
    html_text = html_template.format(today=today, tbl_data=html_table)

    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.image import MIMEImage
    to_list = ['zhaoshuli', 'zhuyabing', 'fangying', 'maliheng', 'heguang', 'sunyue', 'xuminming', 'zhaodongguo', 'haozhaojun', 'qinjianhua', 'tianjun', 'dengzhimin']
    cc_list = ['liuwenfeng', 'tuohu', 'yuanpeng', 'pangxiaofei', 'xiaojian', 'xuxiaoyi', 'chengjiangang', 'wangpeng', 'chengui', 'pengyajie', 'wangminghui', 'sunjunxiang', 'wenjiaqi', 'fengzhu', 'chensong']
    bcc_list = []
    msg = MIMEMultipart('related')
    msg["From"] = "no-reply@aem"
    msg["To"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, to_list))
    msg["CC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, cc_list))
    msg["BCC"] = ';'.join(map(lambda name: "%s@qiyi.com" % name, bcc_list))
    msg["Subject"] = u"AEM实时数据统计报表 {today}".format(today=today)
    msg_text = MIMEText(html_text, 'html', 'utf-8')
    msg.attach(msg_text)
    pictures = map(lambda p: '{today}-{png}'.format(today=today, png=p), ['pie.png', 'count.png'])
    for i, png in zip(range(1, 1+len(pictures)), pictures):
        img = open(os.path.join(workdir, png), 'rb').read()
        msg_image = MIMEImage(img, 'png')
        msg_image.add_header('Content-ID', '<image%d>' % i)
        msg_image.add_header('Content-Disposition', 'inline', filename=png)
        msg.attach(msg_image)
    import subprocess
    p = subprocess.Popen(["/usr/sbin/sendmail", "-t"], stdin=subprocess.PIPE)
    p.communicate(msg.as_string())

if __name__ == "__main__":
    plot_and_email()
