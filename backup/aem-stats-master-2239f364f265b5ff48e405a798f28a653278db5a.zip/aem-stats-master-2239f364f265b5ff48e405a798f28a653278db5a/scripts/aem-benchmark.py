import sys
import time
import json
import random
import threading
import requests
import optparse

sample = """
{
    "play_result":  {
        "timeout":      0,
        "version":      "1.0.3.0224",
        "vip_res":      0,
        "vip_user":     0,
        "vid":  "3d05e2c0a2007be3b3fcbf07407155b4",
        "tvid": "448636100",
        "bid":  "",
        "aid":  "202277101",
        "cid":  "2",
        "file_tpye":    "F4V",
        "rate": 70,
        "timepoint":    2636,
        "network_duration":     15,
        "vip_duration": 0,
        "get_key_succ": 0,
        "auth_succ":    1,
        "step": 22,
        "access_vrs":   {
            "url":  "http://cache.video.qiyi.com/vps?tvid=448636100&vid=3d05e2c0a2007be3b3fcbf07407155b4&v=0&k_uid=&src=01012001020000000000&t=20160303170242&k_ver=5.2.16.2233&k_from=5&k_tag=1&vf=9211e36a026f001bb53e5ba41abd70f0",
            "code": 200,
            "duration":     125,
            "ip":   "123.125.111.111",
            "return_data":  ""
        },
        "access_pdata": {
            "url":  "http://data.video.qiyi.com/videos/v0/20160222/22/4e/4da4e1ea22943adbcd602e49a10bb1bd.f4v?qd_tvid=448636100&qd_vipres=0&qd_index=2&qd_aid=202277101&qd_stert=360000&qd_scc=05d9c23a6174934db882d495141402a4&qd_sc=7de75b3efc82b1eef0b12b8ea3be2360&qd_src=01012001020000000000&qd_ip=ca6c0ef0&qd_uid=0&qd_tm=1456995787000&qd_vip=0&qypid=wcb75nayrncstgtco2ebjezpcuivgbn2",
            "ip":   "111.206.13.3",
            "return_data":  "eyJ0IjoiQ05DfFFpWWktMjAyLjEwOC4xNC4yNDAiLCJ6IjoiemlibzVfY25jIiwiaCI6Ii03NzEiLCJsIjoiaHR0cDovLzYwLjIxMC4xNi4zL3ZpZGVvcy92MC8yMDE2MDIyMi8yMi80ZS80ZGE0ZTFlYTIyOTQzYWRiY2Q2MDJlNDlhMTBiYjFiZC5mNHY/a2V5PTA4OTg0NGVmOTgxYmUxNjgzNTg1YmQ0OTU5MTQxMmFiMyZzcmM9aXFpeWkuY29tJnFkX3R2aWQ9NDQ4NjM2MTAwJnFkX3ZpcHJlcz0wJnFkX2luZGV4PTImcWRfYWlkPTIwMjI3NzEwMSZxZF9zdGVydD0zNjAwMDAmcWRfc2NjPTA1ZDljMjNhNjE3NDkzNGRiODgyZDQ5NTE0MTQwMmE0JnFkX3NjPTdkZTc1YjNlZmM4MmIxZWVmMGIxMmI4ZWEzYmUyMzYwJnFkX3NyYz0wMTAxMjAwMTAyMDAwMDAwMDAwMCZxZF9pcD1jYTZjMGVmMCZxZF91aWQ9MCZxZF90bT0xNDU2OTk1Nzg3MDAwJnFkX3ZpcD0wJnF5cGlkPXdjYjc1bmF5cm5jc3RndGNvMmViamV6cGN1aXZnYm4yJnV1aWQ9Y2E2YzBlZjAtNTZkN2ZkY2ItOGIiLCJlIjoiMCJ9",
            "code": 200,
            "duration":     0
        },
        "access_vip":   {
            "url":  "",
            "ip":   "",
            "return_data":  "",
            "duration":     0
        },
        "cache_status": {
            "host": "60.210.16.3",
            "url":  "http://60.210.16.3/videos/v0/20160222/22/4e/4da4e1ea22943adbcd602e49a10bb1bd.f4v?key=089844ef981be1683585bd49591412ab3&src=iqiyi.com&qd_tvid=448636100&qd_vipres=0&qd_index=2&qd_aid=202277101&qd_stert=360000&qd_scc=05d9c23a6174934db882d495141402a4&qd_sc=7de75b3efc82b1eef0b12b8ea3be2360&qd_src=01012001020000000000&qd_ip=ca6c0ef0&qd_uid=0&qd_tm=1456995787000&qd_vip=0&qypid=wcb75nayrncstgtco2ebjezpcuivgbn2&uuid=ca6c0ef0-56d7fdcb-8b",
            "code": 302,
            "duration":     0,
            "conn_duration":        0,
            "url_hijack":   "http://10.1.244.102/flvfiles/11460000000045ED/111.206.23.132/videos/v0/20160222/22/4e/4da4e1ea22943adbcd602e49a10bb1bd.f4v",
            "avg_speed":    48591,
            "max_speed":    50515,
            "state":        0,
            "ping": {
                    "req_cnt":      0,
                    "lost_cnt":     0,
                    "lost_rate":    0,
                    "avg_rtt":      0,
                    "max_rtt":      0,
                    "min_rtt":      0,
                    "dst":  ""
            },
            "tracert":      {
                    "dst":  "",
                    "hop_list":     []
            }
        },
        "dns":  {
            "dns_rtt":      0,
            "list": ["10.11.50.65", "10.11.50.66"]
        }
    }
}
"""

def fake_int(beg=0, end=0):
    return random.randint(beg, end)

def fake_uuid():
    return "".join(random.sample('abcde01234', 8))

def fake_status():
    choices = [200, 302, 403, 503]
    map(lambda p: choices.append(200), range(7))
    return random.choice(choices)

def fake_ip():
    iplist = []
    map(lambda p: iplist.append(str(random.randint(0, 255))), range(4))
    return ".".join(iplist)

def fake_ver():
    verlist = ["1"]
    verlimit = [1, 10, 100]
    map(lambda p: verlist.append(str(random.randint(0, verlimit[p]))), range(3))
    return ".".join(verlist)

def fake_url():
    return "http://www.iqiyi.com"
    
def fake_json():
    return '{"key": "value"}'

class FakeResult(object):
    """Fake PlayResult"""
    def __init__(self):
        self.result = json.loads(sample)
        self.result['play_result']['step'] = fake_int(0, 26)
        self.result['play_result']['access_vrs']['code'] = fake_status()
        self.result['play_result']['access_pdata']['code'] = fake_status()
        self.result['play_result']['cache_status']['code'] = fake_status()

    def __str__(self):
        return json.dumps(self.result)

class Tester(threading.Thread):
    """Benchmark tester"""
    def __init__(self, url, reqnum, interval):
        super(Tester, self).__init__()
        self.url = url
        self.reqnum = reqnum
        self.interval = interval

    def post(self, i):
        play_result = FakeResult()
        params = {
            'uid' : fake_uuid(),
            'plat': fake_int(0, 3),
            'ver' : fake_ver(),
            'ip'  : fake_ip()
        }
        req = requests.post(self.url, data=str(play_result), params=params)
        print "resp ", i, ": ", req.status_code

    def run(self):
        for i in range(self.reqnum):
            self.post(i)
            time.sleep(self.interval)

def sched(url, num_thread, num_request, interval):
    threads = []
    for i in range(num_thread):
        thread = Tester(url, num_request, interval)
        threads.append(thread)
        thread.start()

if __name__ == "__main__":
    usage = "usage: %prog [options] url"
    parser = optparse.OptionParser(usage=usage)
    parser.add_option('-n', action="store", type="int", default=1, dest="number",  help="total number of requests")
    parser.add_option('-c', action="store", type="int", default=1, dest="concurr", help="concurrency requests per thread")
    # parser.add_option('-l', action="store", type="int", default=1, dest="howlong", help="how long to last by seconds")
    parser.add_option('-t', action="store", type="int", default=1, dest="intval",  help="interval time between two requests per thread")

    options, args = parser.parse_args()
    if options.number <=0 or options.concurr <=0 or options.intval <= 0:
        parser.error("invalid option value")
    elif len(args) > 1:
        parser.error("invalid number of arguments")
    elif len(args) == 0:
        args.append("http://10.77.44.219/send_stuckinfo")

    sched(args[0], options.number/options.concurr, options.concurr, options.intval)