# Spark Streaming开发指南 #

## Spark Streaming介绍 ##
Spark Streaming是Spark核心API的一个扩展，它对实时流式数据的处理具有可扩展性、高吞吐量、可容错性等特点。我们可以从kafka、flume、Twitter、ZeroMQ、等获取数据，也可以通过高阶函数map、reduce、join、window等组成的复杂算法计算出数据。最后，处理后的数据可以推送到文件系统、数据库、实时仪表盘上。在内部，Spark Streaming接收实时的输入数据流，然后将这些数据切分为批数据供Spark引擎处理，Spark引擎将数据生成最终的结果。Spark Streaming支持一个高层的抽象，叫做离散流（DStream），DStream可以利用输入数据流创建，也可以由DStream转换而来，DStream由一系列弹性分布式数据集（RDD）组成。

## Spark Streaming程序开发流程 ##
AEM中的Spark Streaming创建流程如下：

1.创建Spark Streaming的启动环境，设置统计数据的时间跨度，单位为秒。

    ```
    sc = SparkContext()
    ssc = StreamingContext(sc, 300) # 5min for real-time analysis
    sqlContext = getSqlContext(sc)
    ```
2.组装kafka主题列表，关联数据源和用户组，接收kafka中的数据，创建DStream。

    ```
    topics = {"aem_sceneinfo": 5}
    zk_quorum = ",".join(zookeepers)
    kfk_stream = KafkaUtils.createStream(ssc, zk_quorum, "xaem-group", topics, keyDecoder=utf8_decoder, valueDecoder=utf8_decoder)
    ```
3.使用DStream的原始API，针对从流中生成的每个RDD应用处理函数，然后把数据发送给外部系统。AEM中是将数据发送到MySQL，process函数是针对DStream的处理函数，DStream包含多个RDD，每个RDD包含若干个数据分区或者数据（比如partition1， partition2...），所以内部还需要使用RDD.map（function）。使用foreachRDD有一个弊端，有可能需要针对每个DStream需要创建和断开连接，带来一定的资源消耗，使用连接池可以降低资源消耗。

    ```
    kfk_stream.foreachRDD(process)
    ```
4.启动Spark Streaming系统

    ```
    ssc.start()
    ssc.awaitTermination()
    ```
5.DStream处理函数解析

官方的一些例子

	```
    针对每个数据进行处理，这种方法会耗费较多连接资源
	def sendRecord(record):
	    connection = createNewConnection()
	    connection.send(record)
	    connection.close()
	
	dstream.foreachRDD(lambda rdd: rdd.foreach(sendRecord))


    针对每个分区进行处理
	def sendPartition(iter):
	    connection = createNewConnection()
	    for record in iter:
	        connection.send(record)
	    connection.close()

	dstream.foreachRDD(lambda rdd: rdd.foreachPartition(sendPartition))


    使用连接池，降低连接创建和断开的消耗
	def sendPartition(iter):
	    # ConnectionPool is a static, lazily initialized pool of connections
	    connection = ConnectionPool.getConnection()
	    for record in iter:
	        connection.send(record)
	    # return to the pool for future reuse
	    ConnectionPool.returnConnection(connection)
	
	dstream.foreachRDD(lambda rdd: rdd.foreachPartition(sendPartition))
	```

AEM中使用的处理

	```
	def process(time, rdd):
	    """ Process RDDs in each DStream
	
	    First decode json string from Kafka message, then parse all fly data from it
	    by key tuple (isp, province, city), finally insert the result to mysql database via jdbc.
	    """
	    print("========= %s %s==========" % (str(time), type(rdd)))
	    # the message format from Kafka would be (None, u'{"uid":uid, "plat":plat, ..., "fly_data":str}')
	    js_entry = rdd.map(lambda x: transform(x[1]))
	    oj_match = js_entry.map(parse)
        # aggregate the result by key， the key is (prvn, city, isp)
	    cnt_tup = oj_match.reduceByKey(lambda x, y: count(x, y))
	    cnt_rows = cnt_tup.map(lambda x: convert(time, x))
	
	    try:
	        sqlContext = getSqlContext(rdd.context)
	        # Specify the columns order, otherwise jdbc will insert rows in alphabet-order-column
	        dns_df = sqlContext.createDataFrame(cnt_rows)
	        dns_df.write.jdbc(
	            url = "jdbc:mysql://10.153.3.74:3306/aem_stats?user=netdoctor&password=123456",
	            table = "xsceneinfo_summary",
	            mode = "append",
	        )
	    except Exception, e:
	        print(">>> %s" % traceback.format_exc())
	```

## Spark Streaming和AEM的流程关系 ##

![](http://i.imgur.com/5s8nAp8.png)