更新IPResolver模块的步骤：
1.使用新版本替换ipresolver.py
2.然后python setup.py bdist_egg，此处需要注意所在的目录为utils下（setup.py ipresolver文件夹）, python版本2.6
3.生成dist/ipresolver-0.3.2-py2.7-linux-x86_64.egg
4.在Python安装项(pip list)比较少的环境下easy_install ipresolver-0.3.2-py2.7-linux-x86_64.egg
5.在Python中测试：
from ipresolver import ipresolver
xhost_resolver = ipresolver.HostIPResolver()
print xhost_resolver('10.77.55.219')
此处应该得到('CNC', 'QiYi', 'QiYi')
print xhost_resolver('183.23.17.50')
此处应该得到('CT', 'GuangDong', 'GuangDong_DongGuan')
6.更新到爱奇艺云上

需要特别注意的地方：
1.ipresolver.py文件中有一个设置PYTHON_EGG_CACHE环境变量的地方，不可以删除
import os
os.environ['PYTHON_EGG_CACHE'] = os.getcwd()
2.可以把云端的Python环境认为是一个没有安装任何依赖的，所以如果ipresolver有新import，需要将源码放到ipresolver目录下，参考request。
