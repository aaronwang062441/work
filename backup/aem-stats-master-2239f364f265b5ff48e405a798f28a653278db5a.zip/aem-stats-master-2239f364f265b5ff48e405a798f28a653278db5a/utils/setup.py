#!/usr/bin/env python
from setuptools import setup, Extension, find_packages


setup(
    name="ipresolver",
    version="0.3.3",
    description="ip resolve library using patricia",
    url="http://sys.qiyi.domain/gerrit/QData/ipresolver",
    packages=find_packages(),
    ext_modules=[
        Extension("ipresolver/pytricia", ["ipresolver/pytricia.c","ipresolver/patricia.c"]),
    ],
    entry_points={
        'console_scripts': ['ipresolver=ipresolver:main'],
    },
)
