#!/bin/env python
#encoding=utf-8

import getpass

def get_login_user():
    """ Get current login user name"""

    return getpass.getuser()
