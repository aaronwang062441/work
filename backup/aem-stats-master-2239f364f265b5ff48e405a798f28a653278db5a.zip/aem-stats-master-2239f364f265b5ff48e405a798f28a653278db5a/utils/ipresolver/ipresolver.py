#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
os.environ['PYTHON_EGG_CACHE'] = os.getcwd()
import json
import ipaddr
import argparse
import pytricia
import requests
import threading
import radix
from datetime import datetime
from datetime import timedelta
from collections import defaultdict

__all__ = [
    'is_private',
    'host_resolver',
    'idc_resolver',
    'vidc_resolver',
]


class IPv4Container(object):

    def __init__(self, nets):
        self.rtree = radix.Radix()
        for net in nets:
            self.rtree.add(net)

    def __contains__(self, ip):
        if self.rtree.search_best(ip):
            return True
        else:
            return False


_IPV4_PRIVATES = [
    "10.0.0.0/8",
    "100.64.0.0/10",
    "127.0.0.0/8",
    "169.254.0.0/16",
    "172.16.0.0/12",
    "192.168.0.0/16",
]

IPV4_PRIVATES = IPv4Container(_IPV4_PRIVATES)


def is_private(ip):
    return ip in IPV4_PRIVATES


class IPResolver(object):

    _not_found_msg = 'unknown'
    _kv_separator = ':'  # key-value separator
    _vv_separator = '|'  # value-value separator
    _mutex = threading.Lock()

    def __init__(self):
        self._reader_path = ''
        self._reader_url = ''
        self._reader_url_get_timeout = 10
        self._reader_cache_max_age = 6 * 3600

        self._patricia = None
        self._reader_raw_cache = None
        self._has_network = True

    def __call__(self, key):
        return self.__getitem__(key)

    def __getitem__(self, key):
        ret = self._getitem(key)
        ret = self._writer(ret)
        return ret

    def _getitem(self, key):
        try:
            ret = self._patricia[key]
        except (KeyError, ValueError) as e:
            ret = None
        except TypeError, e:
            self._init_patricia()
            ret = self._getitem(key)
        return ret

    def _init_patricia(self):
        self._patricia = pytricia.PyTricia()

        for k, v in self._reader():
            self._patricia[k] = v

    def __getstate__(self):
        state = self._reader_raw()
        return state

    def __setstate__(self, state):
        self._reader_raw_cache = state
        self._init_patricia()
        del self._reader_raw_cache

    def _reader_content_convert(self, content):
        '''
        file content: blob -> blob

        will try to convert ip files got from http url source to local file,
        in following format, line by line
        <key>:<value>
        where key and value are both in following format
        v1|v2|v3|v4...
        for example
        ISP|PROV|ZONE:NET1|NET2|NET3
        IDC:IP1|IP2|IP3

        : and | are specified by _kv_separator and _vv_separator
        '''

        return content

    def _try_update_local_cache(self):
        http_datetime_fmt = '%a, %d %b %Y %H:%M:%S GMT'

        def gen_meta(headers):
            current = datetime.utcnow()
            try:
                datetime.strptime(headers['Last-Modified'], http_datetime_fmt)
            except (KeyError, ValueError):
                last_modified = current.strftime(http_datetime_fmt)
            else:
                last_modified = headers['Last-Modified']

            try:
                datetime.strptime(headers['Expires'], http_datetime_fmt)
            except (KeyError, ValueError):
                delta = timedelta(seconds=self._reader_cache_max_age)
                expires = (current + delta).strftime(http_datetime_fmt)
            else:
                expires = headers['Expires']

            meta = {
                'Last-Modified': last_modified,
                'Expires': expires,
            }
            return json.dumps(meta, indent=4)

        def write_to_local(content, meta):
            for p, c in ((self._reader_path, content),
                         (self._reader_meta, meta)):
                if c is None:
                    continue
                d = os.path.dirname(p)
                if not os.path.exists(d):
                    os.makedirs(d)
                with open(p, 'w') as f:
                    f.write(c)

        def download(url, **kwargs):
            try:
                r = requests.get(self._reader_url, **kwargs)
            except requests.exceptions.ConnectionError:
                self._has_network = False
            else:
                if r.status_code == 200:
                    content = self._reader_content_convert(r.content)
                else:
                    content = None
                meta = gen_meta(r.headers)
                write_to_local(content, meta)

        self._mutex.acquire()
        if (os.path.exists(self._reader_path)
                and os.path.exists(self._reader_meta)):

            # XXX: read meta as json
            with open(self._reader_meta) as f:
                meta = json.load(f)

            expires = datetime.strptime(meta['Expires'].rstrip(" GMT"),
                                        http_datetime_fmt.rstrip(" GMT"))
            if expires < datetime.utcnow():
                download(self._reader_url, verify=False,
                         timeout=self._reader_url_get_timeout,
                         headers={'If-Modified-Since': meta['Last-Modified']})

        else:
            download(self._reader_url, verify=False,
                     timeout=self._reader_url_get_timeout)

        self._mutex.release()

    def _reader_raw(self):
        '''
        _ -> [line] of the raw content

        read from several sources to get the raw content of ip files in
        following orders:
            1. self._reader_raw_cache
            2. self._reader_path on disk
            3. self._reader_url on the network
        '''

        if (self._reader_raw_cache is None
                and self._reader_url is None
                and not os.path.exists(self._reader_path)):
            raise IOError("unable to read from memory, disk and netkwork")

        if self._reader_raw_cache is not None:
            return self._reader_raw_cache

        if self._reader_url is not None:
            self._try_update_local_cache()

        with open(self._reader_path) as f:
            ret = f.read().strip('\n').split('\n')

        return ret

    def _reader(self):
        # -> [key, value]
        # called by _init_patricia
        raise NotImplementedError

    def _writer(self, value):
        # str: value -> dict()
        # called by __getitem__
        raise NotImplementedError


class HostIPResolver(IPResolver):

    def __init__(self):
        super(HostIPResolver, self).__init__()
        self._reader_path = '/tmp/ipresolver/geoip'
        self._reader_meta = '/tmp/ipresolver/geoip.meta'
        # XXX: this url doesn't look like well specified, use it with cautions
        self._reader_url = 'http://ipdb.qiyi.domain/download/latest/qishu'

    def _reader_content_convert(self, content):
        ''' plain text -> plain text (duplicate info merged) '''
        content = content.strip('\n').split('\n')
        ret = {}
        for entry in content:
            entry = entry.strip()
            net, isp = entry.split(';|', 1)
            try:
                ipaddr.IPNetwork(net)
            except ValueError:
                continue

            try:
                ret[isp].add(net)
            except KeyError:
                ret[isp] = set([net])

        lines = []
        for isp in ret:
            nets = self._vv_separator.join(list(ret[isp]))
            isp, zone = isp.split('|', 1)
            prov, _, _ = zone.partition('_')
            ispinfo = self._vv_separator.join([isp, prov, zone])

            line = self._kv_separator.join([ispinfo, nets])
            lines.append(line)

        return '\n'.join(lines)

    def _reader(self):
        for line in self._reader_raw():
            geo, nets = line.split(self._kv_separator, 1)
            for net in nets.split(self._vv_separator):
                if net:
                    yield net, geo

    def _writer(self, ispinfo):
        try:
            isp, prov, zone = ispinfo.split(self._vv_separator)
        except AttributeError:
            isp = prov = zone = self._not_found_msg
        return isp, prov, zone

class ServiceIPResolver(IPResolver):

    def __init__(self):
        super(ServiceIPResolver, self).__init__()
        self._reader_path = '/tmp/ipresolver/serviceip'
        self._reader_meta = '/tmp/ipresolver/serviceip.meta'
        self._reader_url = 'http://ipdb.qiyi.domain/download/ipresolver/boxinfowithidc'

    def _reader_content_convert(self, content):
        content = json.loads(content)
        ret = defaultdict(set)
        for entry in content:
            services = entry.get("new_service")
            if not services:
                continue

            box_ips = get_box_ips(entry)
            service_codes = []
            for service in services:
                if service.get("code"):
                    service_codes.append(service["code"])
            service_key = ",".join(service_codes)
            ret[service_key].update(box_ips)

        lines = []
        for service in ret:
            ips = self._vv_separator.join(list(ret[service]))
            line = self._kv_separator.join([service, ips])
            lines.append(line)
        return '\n'.join(lines)

    def _reader(self):
        for line in self._reader_raw():
            idc, ips = line.split(self._kv_separator, 1)
            for ip in ips.split(self._vv_separator):
                if ip:
                    yield '%s/32' % ip, idc

    def _writer(self, service):
        if service is not None:
            return service
        else:
            return self._not_found_msg



class IDCIPResolver(IPResolver):

    def __init__(self):
        super(IDCIPResolver, self).__init__()
        self._reader_path = '/tmp/ipresolver/idcip'
        self._reader_meta = '/tmp/ipresolver/idcip.meta'
        self._reader_url = 'http://ipdb.qiyi.domain/download/ipresolver/boxinfowithidc'

    def _reader_content_convert(self, content):
        ''' json -> plain text (duplicate info merged) '''
        content = json.loads(content)
        ret = {}
        for entry in content:
            idc = entry.get('IDC')
            if not idc:
                continue

            for k in ('public_address', 'private_address', 'virtual_address'):
                ips = entry.get(k)
                if not isinstance(ips, list):
                    continue

                for ip in ips:
                    try:
                        ipaddr.IPAddress(ip)
                    except ValueError:
                        continue

                    try:
                        ret[idc].add(ip)
                    except KeyError:
                        ret[idc] = set([ip])

        lines = []
        for idc in ret:
            ips = self._vv_separator.join(list(ret[idc]))
            line = self._kv_separator.join([idc, ips])
            lines.append(line)
        return '\n'.join(lines)

    def _reader(self):
        for line in self._reader_raw():
            idc, ips = line.split(self._kv_separator, 1)
            for ip in ips.split(self._vv_separator):
                if ip:
                    yield '%s/32' % ip, idc

    def _writer(self, idcname):
        if idcname is not None:
            return idcname
        else:
            return self._not_found_msg


class VIDCIPResolver(IPResolver):

    def __init__(self):
        super(VIDCIPResolver, self).__init__()
        self._reader_path = "/tmp/ipresolver/vidcip"
        self._reader_meta = "/tmp/ipresolver/vidcip.meta"
        self._reader_url = ((
            "https://portal.qiyi.domain/newportal?appkey=serverlist"
        ))

    def _reader_content_convert(self, content):
        ''' plain text -> plain text (duplicate info merged) '''
        content = content.strip('\n').split('\n')
        ret = {}
        for entry in content:
            entry = entry.strip()
            vidc, ips = entry.split('@m:', 1)
            ips = ips.split(';')

            for ip in ips:
                try:
                    ipaddr.IPAddress(ip)
                except ValueError:
                    continue

                try:
                    ret[vidc].add(ip)
                except KeyError:
                    ret[vidc] = set([ip])

        lines = []
        for vidc in ret:
            ips = self._vv_separator.join(list(ret[vidc]))
            line = self._kv_separator.join([vidc, ips])
            lines.append(line)

        return '\n'.join(lines)

    def _reader(self):
        for line in self._reader_raw():
            idc, ips = line.split(self._kv_separator, 1)
            for ip in ips.split(self._vv_separator):
                if ip:
                    yield '%s/32' % ip, idc

    def _writer(self, idcname):
        if idcname is not None:
            return idcname
        else:
            return self._not_found_msg

idc_resolver = IDCIPResolver()
vidc_resolver = VIDCIPResolver()
host_resolver = HostIPResolver()
service_resolver = ServiceIPResolver()

class HostIPResolverV2(object):
    def __init__(self):
        self.reload()

    def reload(self):
        self._patricia = pytricia.PyTricia()
        with open("/tmp/ipresolver/geoip") as f:
            for line in f:
                line = line.strip("\n")
                kks, subnets = line.split(":")
                for subnet in subnets.split("|"):
                    self._patricia[subnet] = kks.split("|")

    def __call__(self, ip):
        return self.resolve(ip)

    def __getitem__(self, ip):
        return self.resolve(ip)

    def resolve(self, ip):
        try:
            ret = self._patricia[ip]
        except:
            ret = None
        return ret

#host_resolver_v2 = HostIPResolverV2()

def main():
    def parse_args():
        parser = argparse.ArgumentParser()
        parser.add_argument("--idc",  nargs='+', help="resolve idc")
        parser.add_argument("--vidc", nargs='+', help="resolve vidc")
        parser.add_argument("--host", nargs='+', help="resolve host")
        return parser.parse_args()

    args = parse_args()

    if not args.idc and not args.vidc and not args.host:
        raise argparse.ArgumentTypeError("what to resolve?")

    output_fmt = '{0: >4}:    {1: ^15}    ->     {2: ^20}'

    if args.idc:
        for idc in args.idc:
            print output_fmt.format('idc', idc, idc_resolver(idc))
    if args.vidc:
        for vidc in args.vidc:
            print output_fmt.format('vidc', vidc, vidc_resolver(vidc))
    if args.host:
        for host in args.host:
            print output_fmt.format('host', host, host_resolver(host))

def get_box_ips(boxinfo):
    """
        Args:
            boxinfo: each boxinfo in `boxinfowithidc API` list
        Returns:
            result: boxinfo's ip set
    """
    result = set([])
    for k in ('public_address', 'private_address', 'virtual_address'):
        ips = boxinfo.get(k)
        if not isinstance(ips, list):
            continue

        for ip in ips:
            try:
                ipaddr.IPAddress(ip)
            except ValueError:
                continue
            result.add(ip)

    return result


if __name__ == '__main__':
    main()
