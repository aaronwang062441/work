#!/bin/env python

"""docstring"""

from dateutil.rrule import SECONDLY
from dateutil.rrule import rrule
from datetime import datetime

class DateUtils(object):
    """ Specify start / time and return a list
        time splits
    """
    def __init__(self, start, end, interval=300):
        "default interval is 300s "

        self.start = self._parse(start)
        self.end = self._parse(end)
        self.interval = interval

    def _parse(self, timestr):
        "parse string time as datetime type"

        if len(timestr) > 12:
            raise
        elif len(timestr) < 12:
            timestr = timestr.ljust(12, '0')

        return datetime.strptime(timestr, "%Y%m%d%H%M")

    def getSplits(self):
        "return splited time string"

        for split in rrule(SECONDLY, dtstart=self.start,
                           interval=self.interval, until=self.end):
            yield split.strftime('%Y%m%d%H%M')

if __name__ == '__main__':


    du = DateUtils('201501010000', '201501010100')

    for i in du.getSplits():

        print i
