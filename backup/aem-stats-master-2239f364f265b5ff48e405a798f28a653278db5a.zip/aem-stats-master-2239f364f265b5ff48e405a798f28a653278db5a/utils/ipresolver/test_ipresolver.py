#!/usr/bin/env python
import unittest
import pickle
import os
from ipresolver import (
    host_resolver,
    idc_resolver,
)
from exceptions import (
    AttributeError,
)


class HostResolverTestCase(unittest.TestCase):
    resolver = host_resolver
    msg_bytestr = resolver._non_find_msg
    non_bytestr = {
        'prov': msg_bytestr, 'zone': msg_bytestr, 'isp': msg_bytestr}
    msg_unicode = unicode(msg_bytestr)
    non_unicode = {
        u'prov': msg_unicode, u'zone': msg_unicode, u'isp': msg_unicode}

    test_data = {
        '1.0.32.1': {'prov': 'GuangDong', 'zone': 'GuangZhou', 'isp': 'CT'},
        '1.1.128.1': {'prov': 'TH', 'zone': msg_bytestr, 'isp': 'OVERSEA'},
        '14.17.96.1': {'prov': 'GuangDong', 'zone': 'FoShan_CY', 'isp': 'CT'},
        'aaa': non_bytestr,
        '99.99.99.999': non_bytestr,
        u'1.0.32.1': {
            u'prov': u'GuangDong', u'zone': u'GuangZhou', u'isp': u'CT'},
        u'1.1.128.1': {
            u'prov': u'TH', u'zone': msg_unicode, u'isp': u'OVERSEA'},
        u'14.17.96.1': {
            u'prov': u'GuangDong', u'zone': u'FoShan_CY', u'isp': u'CT'},
        u'aaa': non_unicode,
        u'99.99.99.999': non_unicode,
    }

    def test_host(self):
        for k, v in self.test_data.items():
            ret = self.resolver[k]
            self.assertEqual(ret, v)


class IDCResolverTestCase(unittest.TestCase):
    resolver = idc_resolver
    msg_bytestr = resolver._non_find_msg
    non_bytestr = {'idc': msg_bytestr}
    msg_unicode = unicode(msg_bytestr)
    non_unicode = {u'idc': msg_unicode}

    test_data = {
        '119.84.75.48': {'idc': 'chongqing_ct'},
        '120.209.132.84': {'idc': 'anhui_cmnet'},
        '120.209.132.255': non_bytestr,
        'qiyi.soooner.com': non_bytestr,
        u'119.84.75.48': {u'idc': u'chongqing_ct'},
        u'120.209.132.84': {u'idc': u'anhui_cmnet'},
        u'120.209.132.255': non_unicode,
        u'qiyi.soooner.com': non_unicode,
    }

    def test_host(self):
        for k, v in self.test_data.items():
            ret = self.resolver[k]
            self.assertEqual(ret, v)


class HostResolverPickleTestCase(HostResolverTestCase):
    def setUp(self):
        self.resolver = pickle.loads(pickle.dumps(host_resolver))

    def test_Host_pickle_frugality(self):
        self.assertEqual(self.resolver.__dict__.keys(), ['_patricia'])
        with self.assertRaises(AttributeError):
            self.resolver._reader_url
        with self.assertRaises(AttributeError):
            self.resolver._reader_path
        with self.assertRaises(AttributeError):
            self.resolver._reader_raw_content


class IDCResolverPickleTestCase(IDCResolverTestCase):
    def setUp(self):
        self.resolver = pickle.loads(pickle.dumps(self.resolver))

    def test_IDC_pickle_frugality(self):
        self.assertEqual(self.resolver.__dict__.keys(), ['_patricia'])
        with self.assertRaises(AttributeError):
            self.resolver._reader_url
        with self.assertRaises(AttributeError):
            self.resolver._reader_path
        with self.assertRaises(AttributeError):
            self.resolver._reader_raw_content


class HostResolverTempReaderPathTestCase(HostResolverTestCase):
    def setUp(self):
        if os.path.exists(self.resolver._reader_path):
            os.remove(self.resolver._reader_path)


class IDCResolverTempReaderPathTestCase(IDCResolverTestCase):
    def setUp(self):
        if os.path.exists(self.resolver._reader_path):
            os.remove(self.resolver._reader_path)


class HostResolverNoLocalFileTestCase(HostResolverTestCase):
    def setUp(self):
        if os.path.exists(self.resolver._reader_path):
            os.remove(self.resolver._reader_path)


class IDCResolverNoLocalFileTestCase(IDCResolverTestCase):
    def setUp(self):
        if os.path.exists(self.resolver._reader_path):
            os.remove(self.resolver._reader_path)


if __name__ == '__main__':
    unittest.main()
